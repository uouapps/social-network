<?php 

/*-------------------------------------------------------------*******************************---------------------------------------------------------
                                SB Merin's CPT portion start
---------------------------------------------------------------*******************************------------------------------------------------------- */



/*-------------------------------------------------------------------------
  START  SLIDER CPT FOR sb
------------------------------------------------------------------------- */

$slider  = new Cuztom_Post_Type( 'slider', array(
    "label" => 'Slider',
    "menu_position" => 6,     
    'has_archive' => true,
    'taxonomies'          => array('post_tag' ),     
    'supports' => array('title', 'editor','thumbnail')
  ) 
);


$slider->add_meta_box(

    'sb_slider',
    'Sb Slider Information',

  array(
          'bundle',

    array( 

        array(
          'name'          => 'slider_image',
          'label'         => 'Slider Image',
          'description'   => 'Upload your slider image',
          'type'          => 'image',
        ),

         array(
          'name'          => 'icon_image',
          'label'         => 'Icon Image',
          'description'   => 'Upload your icon imagen',
          'type'          => 'image',
        ),

        array(
            'name'        => 'title',
            'label'       => 'Title',
            'description' => 'Put the Image  Title',
            'type'        => 'textarea',

        ),

        array(
          'name'          => 'description',
          'label'         => 'Description',
          'description'   => 'Put the Image  Description',
          'type'          => 'textarea',
        ),


        array(
            'name'          => 'btn_name1',
            'label'         => 'Button Name 1',
            'description'   => 'put the button name',
            'type'          => 'text',
        ),

         array(
            'name'          => 'btn_link1',
            'label'         => 'Button Link 1',
            'description'   => 'put the button link address for button 1',
            'type'          => 'text',
        ),

        array(
            'name'          => 'btn_name2',
            'label'         => 'Button Name 2',
            'description'   => 'put the button name',
            'type'          => 'text',
        ),

        array(
            'name'          => 'btn_link2',
            'label'         => 'Button Link 2',
            'description'   => 'put the button link address for button 2',
            'type'          => 'text',
        ),

        array(
            'name'          => 'video_name',
            'label'         => 'Video Name',
            'description'   => 'Put the name of your video from media folder',
            'type'          => 'text',
        ),

        array(
            'name'          => 'slider_link1',
            'label'         => 'Slider Link 1',
            'description'   => 'Put the html for Slider link 1',
            'type'          => 'textarea',
        ),

        array(
            'name'          => 'slider_link2',
            'label'         => 'Slider Link 2',
            'description'   => 'Put the html for Slider link 2',
            'type'          => 'textarea',
        ),

        array(
            'name'          => 'slider_link3',
            'label'         => 'Slider Link 3',
            'description'   => 'Put the html for Slider link 3',
            'type'          => 'textarea',
        )

    )
  )
);



/*-------------------------------------------------------------------------
  END SLIDER CPT FOR sb
------------------------------------------------------------------------- */



/*-------------------------------------------------------------------------
  START sb COMPANY LOCATION POST TYPE
------------------------------------------------------------------------- */



  $sb_company_locations  = new Cuztom_Post_Type( 'company_location', array(
        "label" => 'Company Locations',
        "menu_position"   => 6,     
        'has_archive'     => true,
        'taxonomies'      => array('post_tag' ),     
        'supports'        => array('title', 'excerpt','thumbnail')
      ) 
    );




    $sb_company_locations->add_meta_box(

        'sb_company_location',
        'Company Agency Contact Information',

        array(
      
                array(
                    'name'          => 'map',
                    'label'         => 'map Shortcode',                    
                    'type'          => 'textarea',                   
                ),

                array(
                    'name'          => 'contact',
                    'label'         => 'Contact Form Shortcode',                    
                    'type'          => 'textarea',                   
                ),

               array(
                  'name'          => 'icon',
                  'label'         => 'Icon For Google Map',
                  'description'   => 'Insert icon that show on google map',
                  'type'          => 'image',
              )

        )
    );


    $sb_company_locations->add_meta_box(

      'sb_property_address',
      'Comany Agency Location on Google Map',

      array(

          array(
              'label' => __('Country Name ', 'simple-builder'),
              'name' => 'country_name',
              'type' => 'text',
              'desc' => __('Country', 'simple-builder')
          ),
          array(
              'label' => __('Region Name', 'simple-builder'),
              'name' => 'region_name',
              'type' => 'text',
              'desc' => __('Region', 'simple-builder')
          ),
          array(
              'label' => __('Address Name', 'simple-builder'),
              'name' => 'address_name',
              'type' => 'text',
              'desc' => __('Address', 'simple-builder')
          ),
          array(
              'label' => __('Zip Code of Region', 'simple-builder'),
              'name' => 'zip',
              'type' => 'text',
              'desc' => __('ZIP codes', 'simple-builder')
          ),
          array(
              'label' => 'map canvas',
              'name'  => 'map_canvas',
              'type' => 'hidden',

            ),
          array(
              'name'          => 'convert_zip',
              'label'         => 'Covert to zip code to latitude and longitude',
              'description'   => 'click checkbox to find result',
              'type'          => 'checkbox',
              'default_value' => 'off'
          ),
          array(
              'label' => __('Latitude', 'simple-builder'),
              'name' => 'lat',
              'type' => 'text',
              'std' => '0',
              'desc' => __('Latitude', 'simple-builder')
          ),
          array(
              'label' => __('Longitude', 'simple-builder'),
              'name' => 'lng',
              'type' => 'text',
              'std' => '0',
              'desc' => __('longitude', 'simple-builder')
          ),

        )

    );



/*-------------------------------------------------------------------------
  END sb COMPANY LOCATION POST TYPE
------------------------------------------------------------------------- */




/*-------------------------------------------------------------------------
  START SB PROGRESS POST TYPE
------------------------------------------------------------------------- */



  $sb_progress  = new Cuztom_Post_Type( 'sb_progress', array(
        "label" => 'SB PROGRESS',
        "menu_position"   => 6,     
        'has_archive'     => true,
        'taxonomies'      => array('post_tag' ),     
        'supports'        => array('title', 'excerpt','thumbnail')
      ) 
    );




    $sb_progress->add_meta_box(

        'sb_progress_bar',
        'Progress Bar Information',

        array(
      
                array(
                    'name'          => 'accordian_shortcode',
                    'label'         => 'Creative Accordian Shortcode',                    
                    'type'          => 'textarea',                   
                ),

                array(
                    'name'          => 'progress_shortcode',
                    'label'         => 'Progress Bar Shortcode',                    
                    'type'          => 'textarea',                   
                ),

        )
    );



/*-------------------------------------------------------------------------
  END sb PROGRESS POST TYPE
------------------------------------------------------------------------- */


/*-------------------------------------------------------------------------
  START SB PRICING POST TYPE
------------------------------------------------------------------------- */



  $sb_pricing  = new Cuztom_Post_Type( 'sb_pricing', array(
        "label" => 'SB PROGRESS',
        "menu_position"   => 6,     
        'has_archive'     => true,
        'taxonomies'      => array('post_tag' ),     
        'supports'        => array('title', 'excerpt','thumbnail')
      ) 
    );




    $sb_pricing->add_meta_box(

        'sb_pricing',
        'Pricing Table Information',

        array(
      
               
               array(
                    'name'          => 'column',
                    'label'         => 'Pricing column shortcode',                    
                    'type'          => 'textarea', 
                    // 'repeatable'    =>  'true'
                ),


                array(
                    'name'          => 'shortcode',
                    'label'         => 'Pricing Shortcode',                    
                    'type'          => 'textarea',                   
                ),


        )
    );



/*-------------------------------------------------------------------------
  END sb PRICING POST TYPE
------------------------------------------------------------------------- */




/*-------------------------------------------------------------*******************************---------------------------------------------------------
                                SB Merin's CPT portion end
---------------------------------------------------------------*******************************------------------------------------------------------- */

/*-------------------------------------------------------------*******************************---------------------------------------------------------
                                                                      SB portion by SHAAD
---------------------------------------------------------------*******************************------------------------------------------------------- */


/*-------------------------------------------------------------------------
  START construction Project POST TYPE
------------------------------------------------------------------------- */
 $sb_portfolio = register_cuztom_post_type( 'portfolio' , array(
      "label" => 'Portfolio',
      "menu_position"   => 8,     
      'has_archive'     => true,
      'menu_icon' => 'dashicons-admin-tools',
      'supports'        => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail')

  ));

 $sb_portfolio->add_taxonomy( 'portfolio_tag' );
/*-------------------------------------------------------------------------
  END construction Project POST TYPE
------------------------------------------------------------------------- */

/*-------------------------------------------------------------*******************************---------------------------------------------------------
                                                                  END SB portion by SHAAD
---------------------------------------------------------------*******************************------------------------------------------------------- */



/*-------------------------------------------------------------*******************************---------------------------------------------------------
                                SB CPT portion start
---------------------------------------------------------------*******************************------------------------------------------------------- */




/*-------------------------------------------------------------*******************************---------------------------------------------------------
                                SB CPT portion end
---------------------------------------------------------------*******************************------------------------------------------------------- */




/*-------------------------------------------------------------------------
  START TESTIMONIAL CPT FOR sb
------------------------------------------------------------------------- */

$testimonial  = new Cuztom_Post_Type( 'testimonial', array(
		"label" => 'Testimonials',
		"menu_position" => 6,     
		'has_archive' => true,
    'menu_icon' => 'dashicons-admin-tools',
		'taxonomies'          => array('post_tag' ),     
		'supports' => array('title', 'excerpt','thumbnail')
	) 
);


$testimonial->add_meta_box(

    'sb_testimonial',
    'Testimonial Author Information',

    array(

        array(

            'name' => 'author_name',
            'label' => 'Testimonial Author Name',
            'description' => 'Put the author name here',
            'type' => 'text'

        ),

        array(

            'name' => 'author_address',
            'label' => 'Testimonial Author Address',
            'description' => 'Put the author address here',
            'type' => 'text'

        ),

        array(

            'name' => 'author_designation',
            'label' => 'Testimonial Author Desigation',
            'description' => 'Put the author designation here',
            'type' => 'text'

        ),

        array(

            'name' => 'author_company',
            'label' => 'Testimonial Author Company',
            'description' => 'Put the author company here',
            'type' => 'text',
            

        ),

    )
);



/*-------------------------------------------------------------------------
  END TESTIMONIAL CPT FOR sb
------------------------------------------------------------------------- */


/*-------------------------------------------------------------------------
  START RESTAURANT About Feature CPT FOR sb
------------------------------------------------------------------------- */

$feature  = new Cuztom_Post_Type( 'feature', array(
    "label" => 'Features',
    "menu_position" => 6,     
    'has_archive' => true,
    'taxonomies'          => array('post_tag' ),     
    'supports' => array('title', 'excerpt','thumbnail')
  ) 
);


$feature->add_meta_box(

    'tons_of_feature',
    'Simple Builder Feature Icon For The Post',
    array(
        array(
            'name' => 'icon',
            'label' => '<div><button class="btn btn-primary" role="iconpicker"> Set Icon </button></div>',
            'description' => 'Provide The Icon for your Feature',
            'type' => 'text'
        ),
        array(
            'name' => 'icon',
            'label' => 'Set Your icon HTML for post',
            'description' => 'Provide The Icon for your Feature',
            'type' => 'textarea'
        ),
        // array(
        //     'name' => 'number',
        //     'label' => 'Input Your Number',
        //     'description' => 'Provide The number for your Feature',
        //     'type' => 'text'
        // ),
        // array(
        //     'name' => 'title',
        //     'label' => 'Set Your title for post',
        //     'description' => 'Provide The title for your Feature',
        //     'type' => 'text'
        // ),
    )
);



/*-------------------------------------------------------------------------
  END RESTAURANT About Feature  CPT FOR sb
------------------------------------------------------------------------- */


/*-------------------------------------------------------------------------
  START BLOCK POST TYPE
------------------------------------------------------------------------- */
  $sb_block  = new Cuztom_Post_Type( 'block', array(
      "label" => 'Block',
      "menu_position" => 7,     
      'has_archive' => true,
      'menu_icon' => 'dashicons-grid-view',
      'taxonomies'          => array('post_tag' ),     
      'supports' => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'trackbacks', 'revisions', 'custom-fields', 'page-attributes', 'post-formats', ),
     ) 
    );



/*-------------------------------------------------------------------------
  END BLOCK POST TYPE
------------------------------------------------------------------------- */



/*-------------------------------------------------------------------------
  START PAGE POST TYPE
------------------------------------------------------------------------- */



$sb_page = new Cuztom_Post_Type( 'page');


$company_info  = new Cuztom_Post_Type( 'company', array(
    "label" => 'Company Info',
    "menu_position"   => 6,     
    'has_archive'     => true,
    'taxonomies'      => array('post_tag' ),     
    'supports'        => array('title')
  ) 
);


$company_info->add_meta_box(

    'company_info_feature',
    'Simple Builder Company Information For The Post',
    array(
        array(
            'name' => 'icon',
            'label' => 'Set Your icon HTML for post',
            'description' => 'Provide The Icon for your Feature',
            'type' => 'textarea'
        ),
        array(
            'name' => 'number',
            'label' => 'Input Your Number',
            'description' => 'Provide The number for your Feature',
            'type' => 'text'
        ),
        array(
            'name' => 'title',
            'label' => 'Set Your title for post',
            'description' => 'Provide The title for your Feature',
            'type' => 'text'
        ),
    )
);


