<?php 
/*-------------------------------------------------------------*******************************---------------------------------------------------------
                                SB Merin's Shortcodes portion start
---------------------------------------------------------------*******************************------------------------------------------------------- */

/*-------------------------------------------------------------------------
  START SB SLIDER 1 SHORTCODE
------------------------------------------------------------------------- */

function sb_slider_one($atts , $content = null){

  extract(shortcode_atts( array('post_id'=>''), $atts ));

 $sb_result = '<div class="sb-slider-section default">
                       <div class="master-slider ms-skin-light-2 default-master-slider">'; 

$args = array(

  'post_type' => 'slider',
  'posts_per_page' => -1,

  );

$get_all_slider = get_posts($args);
// _log($get_all_slider);
$i=1;

if(isset($get_all_slider)&& !empty($get_all_slider)){
  foreach ($get_all_slider as $key => $value) {
// _log('mer');
    $slider_meta = get_post_meta($post_id, '_sb_slider', true);    
      // _log($slider_meta);
    
    if($i==1){

      if(isset($slider_meta)&& !empty($slider_meta)){
      foreach($slider_meta as $meta_key => $meta_value){

          if(isset($meta_value['_slider_image'])&& !empty($meta_value['_slider_image'])){
            $image_id1 = $meta_value['_slider_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $slider_img = sb_aq_resize( $large_image1, 1920, 960, true );
          }
          else{
            $slider_img ='';
          }

          if(isset($meta_value['_icon_image'])&& !empty($meta_value['_icon_image'])){
            $image_id1 = $meta_value['_icon_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $logo_img = sb_aq_resize( $large_image1, 208, 252, true );
          }
          else{
            $logo_img ='';
          }

          if(isset($meta_value['_title'])&& !empty($meta_value['_title'])){
            $title = $meta_value['_title'];
          }
          else{
            $title ='';
          }

          if(isset($meta_value['_description'])&& !empty($meta_value['_description'])){
            $description = $meta_value['_description'];
          }
          else{
            $description ='';
          }

          if(isset($meta_value['_btn_name1'])&& !empty($meta_value['_btn_name1'])){
            $btn_name1 = $meta_value['_btn_name1'];
          }
          else{
            $btn_name1 ='';
          }

          if(isset($meta_value['_btn_link1'])&& !empty($meta_value['_btn_link1'])){
            $btn_link1 = $meta_value['_btn_link1'];
          }
          else{
            $btn_link1 ='';
          }

          if(isset($meta_value['_btn_name2'])&& !empty($meta_value['_btn_name2'])){
            $btn_name2 = $meta_value['_btn_name2'];
          }
          else{
            $btn_name2 ='';
          }

          if(isset($meta_value['_btn_link2'])&& !empty($meta_value['_btn_link2'])){
            $btn_link2 = $meta_value['_btn_link2'];
          }
          else{
            $btn_link2 ='';
          }

          if(isset($meta_value['_video_name'])&& !empty($meta_value['_video_name'])){
            $video_name = $meta_value['_video_name'];
          }
          else{
            $video_name ='';
          }
          // _log($video_name);
      $sb_result .='<div class="ms-slide">';
    
      if(!empty($slider_img)){
        $sb_result .='<img src="'.SB_JS.'masterslider/blank.gif" data-src="'.$slider_img.'" alt=""/>';
      }

      if(!empty($video_name)){
        $sb_result .='<video data-autopause="false" data-mute="true" data-loop="true" data-fill-mode="fill">
                                  <source id="mp4" src="'.SB_VIDEO.$video_name.'" type="video/mp4"/>
                                </video>';
      }
        
        $sb_result .='<div class="ms-layer ms-caption text-center" data-origin="mc">';

      if(!empty($logo_img)){
        $sb_result .='<img class=" slider-logo-img" alt=""
                                  data-ease = "easeOutQuart"
                                  src="'.$logo_img.'"
                                />';
      }

      if(!empty($title)){
        $sb_result .= '<h1>'.$title.'</h1>';
      }

      if(!empty($description)){
        $sb_result .='<p class="text-uppercase">'.$description.'</p>';  
      }

      if(!empty($btn_name1)){
        $sb_result .= '<a class="btn btn-transparent mr10" href="'.$btn_link1.'">'.$btn_name1.'</a>';
      } 

      if(!empty($btn_name2)){
        $sb_result .= '<a class="btn btn-primary" href="'.$btn_link2.'">'.$btn_name2.'</a>';
      }
        $sb_result .='</div>';
        $sb_result .= '</div>';


        }
      }
      $i++;
    }
  }
}

  $sb_result .= '</div></div>';
  return $sb_result;
}
add_shortcode( 'sb_slider_one_shortcode', 'sb_slider_one' );


/*-------------------------------------------------------------------------
  END SB SLIDER 1 SHORTCODE
------------------------------------------------------------------------- */


/*-------------------------------------------------------------------------
  START SB SLIDER 2 SHORTCODE
------------------------------------------------------------------------- */

function sb_slider_two($atts , $content = null){

  extract(shortcode_atts( array('post_id'=>''), $atts ));

   // global $sb_option_data;  
   //_log($sb_option_data);
   // _log('merin');
 $sb_result = '<div class="sb-slider-section default">
                        <div class="master-slider ms-skin-black-1 default-master-slider">';
$args = array(

  'post_type' => 'slider',
  'posts_per_page' => -1,

  );

$get_all_slider = get_posts($args);
// _log($get_all_slider);
$i=1;

if(isset($get_all_slider)&& !empty($get_all_slider)){
  foreach ($get_all_slider as $key => $value) {
// _log('mer');
    $slider_meta = get_post_meta($post_id, '_sb_slider', true);    
      // _log($slider_meta);
    
    if($i==1){

      if(isset($slider_meta)&& !empty($slider_meta)){
      foreach($slider_meta as $meta_key => $meta_value){

          if(isset($meta_value['_slider_image'])&& !empty($meta_value['_slider_image'])){
            $image_id1 = $meta_value['_slider_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $slider_img = sb_aq_resize( $large_image1, 1920, 960, true );
          }
          else{
            $slider_img ='';
          }

          if(isset($meta_value['_icon_image'])&& !empty($meta_value['_icon_image'])){
            $image_id1 = $meta_value['_icon_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $logo_img = sb_aq_resize( $large_image1, 275, 276, true );
          }
          else{
            $logo_img ='';
          }

          if(isset($meta_value['_title'])&& !empty($meta_value['_title'])){
            $title = $meta_value['_title'];
          }
          else{
            $title ='';
          }

          if(isset($meta_value['_description'])&& !empty($meta_value['_description'])){
            $description = $meta_value['_description'];
          }
          else{
            $description ='';
          }

          if(isset($meta_value['_btn_name1'])&& !empty($meta_value['_btn_name1'])){
            $btn_name1 = $meta_value['_btn_name1'];
          }
          else{
            $btn_name1 ='';
          }

          if(isset($meta_value['_btn_link1'])&& !empty($meta_value['_btn_link1'])){
            $btn_link1 = $meta_value['_btn_link1'];
          }
          else{
            $btn_link1 ='';
          }

          if(isset($meta_value['_btn_name2'])&& !empty($meta_value['_btn_name2'])){
            $btn_name2 = $meta_value['_btn_name2'];
          }
          else{
            $btn_name2 ='';
          }

          if(isset($meta_value['_btn_link2'])&& !empty($meta_value['_btn_link2'])){
            $btn_link2 = $meta_value['_btn_link2'];
          }
          else{
            $btn_link2 ='';
          }

          if(isset($meta_value['_video_name'])&& !empty($meta_value['_video_name'])){
            $video_name = $meta_value['_video_name'];
          }
          else{
            $video_name ='';
          }
          // _log($video_name);
      $sb_result .='<div class="ms-slide">';
    
      if(!empty($slider_img)){
        $sb_result .='<img src="'.SB_JS.'masterslider/blank.gif" data-src="'.$slider_img.'" alt=""/>';
      }

      if(!empty($video_name)){
        $sb_result .='<video data-autopause="false" data-mute="true" data-loop="true" data-fill-mode="fill">
                                  <source id="mp4" src="'.SB_VIDEO.$video_name.'" type="video/mp4"/>
                                </video>';
      }
        
        $sb_result .='<div class="ms-layer ms-caption text-center" data-origin="mc">';

      if(!empty($logo_img)){
        $sb_result .='<img class=" slider-logo-img" alt=""
                                  data-ease = "easeOutQuart"
                                  src="'.$logo_img.'"
                                />';
      }

      if(!empty($title)){
        $sb_result .= '<h1>'.$title.'</h1>';
      }

      if(!empty($description)){
        $sb_result .='<p class="text-uppercase">'.$description.'</p>';  
      }

      if(!empty($btn_name1)){
        $sb_result .= '<a class="btn btn-transparent mr10" href="'.$btn_link1.'">'.$btn_name1.'</a>';
      } 

      if(!empty($btn_name2)){
        $sb_result .= '<a class="btn btn-primary" href="'.$btn_link2.'">'.$btn_name2.'</a>';
      }
        $sb_result .='</div>';
        $sb_result .= '</div>';


        }
      }
      $i++;
    }
  }
}

  $sb_result .= '</div></div>';
  return $sb_result;
}
add_shortcode( 'sb_slider_two_shortcode', 'sb_slider_two' );


/*-------------------------------------------------------------------------
  END SB SLIDER 2 SHORTCODE
------------------------------------------------------------------------- */


/*-------------------------------------------------------------------------
  START SB SLIDER 3 SHORTCODE
------------------------------------------------------------------------- */

function sb_slider_three($atts , $content = null){

  extract(shortcode_atts( array('post_id'=>''), $atts ));

   // global $sb_option_data;  
   //_log($sb_option_data);
   // _log('merin');
 $sb_result = '<div class="sb-slider-section default">
                        <div class="master-slider ms-skin-black-1 default-master-slider">';
$args = array(

  'post_type' => 'slider',
  'posts_per_page' => -1,

  );

$get_all_slider = get_posts($args);
// _log($get_all_slider);
$i=1;

if(isset($get_all_slider)&& !empty($get_all_slider)){
  foreach ($get_all_slider as $key => $value) {
// _log('mer');
    $slider_meta = get_post_meta($post_id, '_sb_slider', true);    
      // _log($slider_meta);
    
    if($i==1){

      if(isset($slider_meta)&& !empty($slider_meta)){
      foreach($slider_meta as $meta_key => $meta_value){

          if(isset($meta_value['_slider_image'])&& !empty($meta_value['_slider_image'])){
            $image_id1 = $meta_value['_slider_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $slider_img = sb_aq_resize( $large_image1, 1920, 960, true );
          }
          else{
            $slider_img ='';
          }

          if(isset($meta_value['_icon_image'])&& !empty($meta_value['_icon_image'])){
            $image_id1 = $meta_value['_icon_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $logo_img = sb_aq_resize( $large_image1, 208, 252, true );
          }
          else{
            $logo_img ='';
          }

          if(isset($meta_value['_title'])&& !empty($meta_value['_title'])){
            $title = $meta_value['_title'];
          }
          else{
            $title ='';
          }

          if(isset($meta_value['_description'])&& !empty($meta_value['_description'])){
            $description = $meta_value['_description'];
          }
          else{
            $description ='';
          }

          if(isset($meta_value['_btn_name1'])&& !empty($meta_value['_btn_name1'])){
            $btn_name1 = $meta_value['_btn_name1'];
          }
          else{
            $btn_name1 ='';
          }

          if(isset($meta_value['_btn_link1'])&& !empty($meta_value['_btn_link1'])){
            $btn_link1 = $meta_value['_btn_link1'];
          }
          else{
            $btn_link1 ='';
          }

          if(isset($meta_value['_btn_name2'])&& !empty($meta_value['_btn_name2'])){
            $btn_name2 = $meta_value['_btn_name2'];
          }
          else{
            $btn_name2 ='';
          }

          if(isset($meta_value['_btn_link2'])&& !empty($meta_value['_btn_link2'])){
            $btn_link2 = $meta_value['_btn_link2'];
          }
          else{
            $btn_link2 ='';
          }

          if(isset($meta_value['_video_name'])&& !empty($meta_value['_video_name'])){
            $video_name = $meta_value['_video_name'];
          }
          else{
            $video_name ='';
          }

          if(isset($meta_value['_slider_link1'])&& !empty($meta_value['_slider_link1'])){
            $slider_link1 = $meta_value['_slider_link1'];
          }
          else{
            $slider_link1 ='';
          }

          if(isset($meta_value['_slider_link2'])&& !empty($meta_value['_slider_link2'])){
            $slider_link2 = $meta_value['_slider_link2'];
          }
          else{
            $slider_link2 ='';
          }

          if(isset($meta_value['_slider_link3'])&& !empty($meta_value['_slider_link3'])){
            $slider_link3 = $meta_value['_slider_link3'];
          }
          else{
            $slider_link3 ='';
          }
          // _log($video_name);
      $sb_result .='<div class="ms-slide">';
    
      if(!empty($slider_img)){
        $sb_result .='<img src="'.SB_JS.'masterslider/blank.gif" data-src="'.$slider_img.'" alt="lorel impsum dolem"/>';
      }

      if(!empty($video_name)){
        $sb_result .='<video data-autopause="false" data-mute="true" data-loop="true" data-fill-mode="fill">
                                  <source id="mp4" src="'.SB_VIDEO.$video_name.'" type="video/mp4"/>
                                </video>';
      }
        
        $sb_result .='<div class="ms-layer ms-caption text-center" data-origin="mc">';
        $sb_result .='<ul class="list-unstyled slider-link-list">';

      if(!empty($slider_link1)){
        $sb_result .=$slider_link1;
      }

      if(!empty($slider_link2)){
        $sb_result .=$slider_link2;
      }

      if(!empty($slider_link3)){
        $sb_result .=$slider_link3;
      }

        $sb_result .='</ul>';
      if(!empty($logo_img)){
        $sb_result .='<img class=" slider-logo-img" alt=""
                                  data-ease = "easeOutQuart"
                                  src="'.$logo_img.'"
                                />';
      }

      if(!empty($title)){
        $sb_result .= '<h1>'.$title.'</h1>';
      }

      if(!empty($description)){
        $sb_result .='<p class="text-uppercase">'.$description.'</p>';  
      }

      if(!empty($btn_name1)){
        $sb_result .= '<a class="btn btn-transparent mr10" href="'.$btn_link1.'">'.$btn_name1.'</a>';
      } 

      if(!empty($btn_name2)){
        $sb_result .= '<a class="btn btn-primary" href="'.$btn_link2.'">'.$btn_name2.'</a>';
      }
        $sb_result .='</div>';
        $sb_result .= '</div>';


        }
      }
      $i++;
    }
  }
}

  $sb_result .= '</div></div>';
  return $sb_result;
}
add_shortcode( 'sb_slider_three_shortcode', 'sb_slider_three' );


/*-------------------------------------------------------------------------
  END SB SLIDER 3 SHORTCODE
------------------------------------------------------------------------- */


/*-------------------------------------------------------------------------
  START SB SLIDER 4 SHORTCODE
------------------------------------------------------------------------- */

function sb_slider_four($atts , $content = null){

  extract(shortcode_atts( array('post_id'=>''), $atts ));

   // global $sb_option_data;  
   //_log($sb_option_data);
   // _log('merin');
 $sb_result = '<div class="sb-slider-section default custom-bullet">
                        <div class="master-slider ms-skin-default secondary-master-slider">';
$args = array(

  'post_type' => 'slider',
  'posts_per_page' => -1,

  );

$get_all_slider = get_posts($args);
// _log($get_all_slider);
$i=1;

if(isset($get_all_slider)&& !empty($get_all_slider)){
  foreach ($get_all_slider as $key => $value) {
// _log('mer');
    $slider_meta = get_post_meta($post_id, '_sb_slider', true);    
      // _log($slider_meta);
    
    if($i==1){

      if(isset($slider_meta)&& !empty($slider_meta)){
      foreach($slider_meta as $meta_key => $meta_value){

          if(isset($meta_value['_slider_image'])&& !empty($meta_value['_slider_image'])){
            $image_id1 = $meta_value['_slider_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $slider_img = sb_aq_resize( $large_image1, 1920, 960, true );
          }
          else{
            $slider_img ='';
          }

          if(isset($meta_value['_icon_image'])&& !empty($meta_value['_icon_image'])){
            $image_id1 = $meta_value['_icon_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $logo_img = sb_aq_resize( $large_image1, 208, 252, true );
          }
          else{
            $logo_img ='';
          }

          if(isset($meta_value['_title'])&& !empty($meta_value['_title'])){
            $title = $meta_value['_title'];
          }
          else{
            $title ='';
          }

          if(isset($meta_value['_description'])&& !empty($meta_value['_description'])){
            $description = $meta_value['_description'];
          }
          else{
            $description ='';
          }

          if(isset($meta_value['_btn_name1'])&& !empty($meta_value['_btn_name1'])){
            $btn_name1 = $meta_value['_btn_name1'];
          }
          else{
            $btn_name1 ='';
          }

          if(isset($meta_value['_btn_link1'])&& !empty($meta_value['_btn_link1'])){
            $btn_link1 = $meta_value['_btn_link1'];
          }
          else{
            $btn_link1 ='';
          }

          if(isset($meta_value['_btn_name2'])&& !empty($meta_value['_btn_name2'])){
            $btn_name2 = $meta_value['_btn_name2'];
          }
          else{
            $btn_name2 ='';
          }

          if(isset($meta_value['_btn_link2'])&& !empty($meta_value['_btn_link2'])){
            $btn_link2 = $meta_value['_btn_link2'];
          }
          else{
            $btn_link2 ='';
          }

          if(isset($meta_value['_video_name'])&& !empty($meta_value['_video_name'])){
            $video_name = $meta_value['_video_name'];
          }
          else{
            $video_name ='';
          }

          if(isset($meta_value['_slider_link1'])&& !empty($meta_value['_slider_link1'])){
            $slider_link1 = $meta_value['_slider_link1'];
          }
          else{
            $slider_link1 ='';
          }

          if(isset($meta_value['_slider_link2'])&& !empty($meta_value['_slider_link2'])){
            $slider_link2 = $meta_value['_slider_link2'];
          }
          else{
            $slider_link2 ='';
          }

          if(isset($meta_value['_slider_link3'])&& !empty($meta_value['_slider_link3'])){
            $slider_link3 = $meta_value['_slider_link3'];
          }
          else{
            $slider_link3 ='';
          }
          // _log($video_name);
      $sb_result .='<div class="ms-slide">';
    
      if(!empty($slider_img)){
        $sb_result .='<img src="'.SB_JS.'masterslider/blank.gif" data-src="'.$slider_img.'" alt="lorel impsum dolem"/>';
      }

      if(!empty($video_name)){
        $sb_result .='<video data-autopause="false" data-mute="true" data-loop="true" data-fill-mode="fill">
                                  <source id="mp4" src="'.SB_VIDEO.$video_name.'" type="video/mp4"/>
                                </video>';
      }
        
        $sb_result .='<div class="ms-layer ms-caption text-center" data-origin="mc">';
 
      if(!empty($logo_img)){
        $sb_result .='<img class=" slider-logo-img" alt=""
                                  data-ease = "easeOutQuart"
                                  src="'.$logo_img.'"
                                />';
      }

      if(!empty($title)){
        $sb_result .= '<h1>'.$title.'</h1>';
      }

      if(!empty($description)){
        $sb_result .='<p class="text-uppercase">'.$description.'</p>';  
      }

        $sb_result .='<div class="slider-link-btn">';

      if(!empty($btn_name1)){
        $sb_result .= '<a class="btn btn-transparent mr10" href="'.$btn_link1.'">'.$btn_name1.'</a>';
      } 

      if(!empty($btn_name2)){
        $sb_result .= '<a class="btn btn-primary" href="'.$btn_link2.'">'.$btn_name2.'</a>';
      }
        $sb_result .='</div></div>';
        $sb_result .= '</div>';


        }
      }
      $i++;
    }
  }
}

  $sb_result .= '</div></div>';
  return $sb_result;
}
add_shortcode( 'sb_slider_four_shortcode', 'sb_slider_four' );


/*-------------------------------------------------------------------------
  END SB SLIDER 4 SHORTCODE
------------------------------------------------------------------------- */


/*-------------------------------------------------------------------------
  START SB SLIDER 5 SHORTCODE
------------------------------------------------------------------------- */

function sb_slider_five($atts , $content = null){

  extract(shortcode_atts( array('post_id'=>''), $atts ));

   // global $sb_option_data;  
   //_log($sb_option_data);
   // _log('merin');
 $sb_result = '<div class="sb-slider-section default dark-text">
                        <div class="master-slider ms-skin-default secondary-master-slider">';
$args = array(

  'post_type' => 'slider',
  'posts_per_page' => -1,

  );

$get_all_slider = get_posts($args);
// _log($get_all_slider);
$i=1;

if(isset($get_all_slider)&& !empty($get_all_slider)){
  foreach ($get_all_slider as $key => $value) {
// _log('mer');
    $slider_meta = get_post_meta($post_id, '_sb_slider', true);    
      // _log($slider_meta);
    
    if($i==1){

      if(isset($slider_meta)&& !empty($slider_meta)){
      foreach($slider_meta as $meta_key => $meta_value){

          if(isset($meta_value['_slider_image'])&& !empty($meta_value['_slider_image'])){
            $image_id1 = $meta_value['_slider_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $slider_img = sb_aq_resize( $large_image1, 1920, 960, true );
          }
          else{
            $slider_img ='';
          }

          if(isset($meta_value['_icon_image'])&& !empty($meta_value['_icon_image'])){
            $image_id1 = $meta_value['_icon_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $logo_img = sb_aq_resize( $large_image1, 208, 252, true );
          }
          else{
            $logo_img ='';
          }

          if(isset($meta_value['_title'])&& !empty($meta_value['_title'])){
            $title = $meta_value['_title'];
          }
          else{
            $title ='';
          }

          if(isset($meta_value['_description'])&& !empty($meta_value['_description'])){
            $description = $meta_value['_description'];
          }
          else{
            $description ='';
          }

          if(isset($meta_value['_btn_name1'])&& !empty($meta_value['_btn_name1'])){
            $btn_name1 = $meta_value['_btn_name1'];
          }
          else{
            $btn_name1 ='';
          }

          if(isset($meta_value['_btn_link1'])&& !empty($meta_value['_btn_link1'])){
            $btn_link1 = $meta_value['_btn_link1'];
          }
          else{
            $btn_link1 ='';
          }

          if(isset($meta_value['_btn_name2'])&& !empty($meta_value['_btn_name2'])){
            $btn_name2 = $meta_value['_btn_name2'];
          }
          else{
            $btn_name2 ='';
          }

          if(isset($meta_value['_btn_link2'])&& !empty($meta_value['_btn_link2'])){
            $btn_link2 = $meta_value['_btn_link2'];
          }
          else{
            $btn_link2 ='';
          }

          if(isset($meta_value['_video_name'])&& !empty($meta_value['_video_name'])){
            $video_name = $meta_value['_video_name'];
          }
          else{
            $video_name ='';
          }

          if(isset($meta_value['_slider_link1'])&& !empty($meta_value['_slider_link1'])){
            $slider_link1 = $meta_value['_slider_link1'];
          }
          else{
            $slider_link1 ='';
          }

          if(isset($meta_value['_slider_link2'])&& !empty($meta_value['_slider_link2'])){
            $slider_link2 = $meta_value['_slider_link2'];
          }
          else{
            $slider_link2 ='';
          }

          if(isset($meta_value['_slider_link3'])&& !empty($meta_value['_slider_link3'])){
            $slider_link3 = $meta_value['_slider_link3'];
          }
          else{
            $slider_link3 ='';
          }
          // _log($video_name);
      $sb_result .='<div class="ms-slide">';
    
      if(!empty($slider_img)){
        $sb_result .='<img src="'.SB_JS.'masterslider/blank.gif" data-src="'.$slider_img.'" alt="lorel impsum dolem"/>';
      }

      if(!empty($video_name)){
        $sb_result .='<video data-autopause="false" data-mute="true" data-loop="true" data-fill-mode="fill">
                                  <source id="mp4" src="'.SB_VIDEO.$video_name.'" type="video/mp4"/>
                                </video>';
      }
        
        $sb_result .='<div class="ms-layer ms-caption text-center" data-origin="mc">';
 
      if(!empty($logo_img)){
        $sb_result .='<img class=" slider-logo-img" alt=""
                                  data-ease = "easeOutQuart"
                                  src="'.$logo_img.'"
                                />';
      }

      if(!empty($title)){
        $sb_result .=  $title;
      }

      if(!empty($description)){
        $sb_result .=  $description;  
      }

        // $sb_result .='<div class="slider-link-btn">';

      if(!empty($btn_name1)){
        $sb_result .= '<a class="btn btn-transparent-invert mr10" href="'.$btn_link1.'">'.$btn_name1.'</a>';
      } 

      if(!empty($btn_name2)){
        $sb_result .= '<a class="btn btn-primary-second" href="'.$btn_link2.'">'.$btn_name2.'</a>';
      }
        $sb_result .='</div>';
        $sb_result .= '</div>';


        }
      }
      $i++;
    }
  }
}

  $sb_result .= '</div></div>';
  return $sb_result;
}
add_shortcode( 'sb_slider_five_shortcode', 'sb_slider_five' );


/*-------------------------------------------------------------------------
  END SB SLIDER 5 SHORTCODE
------------------------------------------------------------------------- */




/*-------------------------------------------------------------------------
  START SB SLIDER 6 SHORTCODE
------------------------------------------------------------------------- */

function sb_slider_six($atts , $content = null){

  extract(shortcode_atts( array('post_id'=>''), $atts ));

   // global $sb_option_data;  
   //_log($sb_option_data);
   // _log('merin');
 $sb_result = '<div class="sb-slider-section default">
                        <div class="master-slider ms-skin-default  secondary-master-slider">';
$args = array(

  'post_type' => 'slider',
  'posts_per_page' => -1,

  );

$get_all_slider = get_posts($args);
// _log($get_all_slider);
$i=1;

if(isset($get_all_slider)&& !empty($get_all_slider)){
  foreach ($get_all_slider as $key => $value) {
// _log('mer');
    $slider_meta = get_post_meta($post_id, '_sb_slider', true);    
      // _log($slider_meta);
    
    if($i==1){

      if(isset($slider_meta)&& !empty($slider_meta)){
      foreach($slider_meta as $meta_key => $meta_value){

          if(isset($meta_value['_slider_image'])&& !empty($meta_value['_slider_image'])){
            $image_id1 = $meta_value['_slider_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $slider_img = sb_aq_resize( $large_image1, 1920, 960, true );
          }
          else{
            $slider_img ='';
          }

          if(isset($meta_value['_icon_image'])&& !empty($meta_value['_icon_image'])){
            $image_id1 = $meta_value['_icon_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $logo_img = sb_aq_resize( $large_image1, 208, 252, true );
          }
          else{
            $logo_img ='';
          }

          if(isset($meta_value['_title'])&& !empty($meta_value['_title'])){
            $title = $meta_value['_title'];
          }
          else{
            $title ='';
          }

          if(isset($meta_value['_description'])&& !empty($meta_value['_description'])){
            $description = $meta_value['_description'];
          }
          else{
            $description ='';
          }

          if(isset($meta_value['_btn_name1'])&& !empty($meta_value['_btn_name1'])){
            $btn_name1 = $meta_value['_btn_name1'];
          }
          else{
            $btn_name1 ='';
          }

          if(isset($meta_value['_btn_link1'])&& !empty($meta_value['_btn_link1'])){
            $btn_link1 = $meta_value['_btn_link1'];
          }
          else{
            $btn_link1 ='';
          }

          if(isset($meta_value['_btn_name2'])&& !empty($meta_value['_btn_name2'])){
            $btn_name2 = $meta_value['_btn_name2'];
          }
          else{
            $btn_name2 ='';
          }

          if(isset($meta_value['_btn_link2'])&& !empty($meta_value['_btn_link2'])){
            $btn_link2 = $meta_value['_btn_link2'];
          }
          else{
            $btn_link2 ='';
          }

          if(isset($meta_value['_video_name'])&& !empty($meta_value['_video_name'])){
            $video_name = $meta_value['_video_name'];
          }
          else{
            $video_name ='';
          }

          if(isset($meta_value['_slider_link1'])&& !empty($meta_value['_slider_link1'])){
            $slider_link1 = $meta_value['_slider_link1'];
          }
          else{
            $slider_link1 ='';
          }

          if(isset($meta_value['_slider_link2'])&& !empty($meta_value['_slider_link2'])){
            $slider_link2 = $meta_value['_slider_link2'];
          }
          else{
            $slider_link2 ='';
          }

          if(isset($meta_value['_slider_link3'])&& !empty($meta_value['_slider_link3'])){
            $slider_link3 = $meta_value['_slider_link3'];
          }
          else{
            $slider_link3 ='';
          }
          // _log($video_name);
      $sb_result .='<div class="ms-slide">';
    
      if(!empty($slider_img)){
        $sb_result .='<img src="'.SB_JS.'masterslider/blank.gif" data-src="'.$slider_img.'" alt="lorel impsum dolem"/>';
      }

      if(!empty($video_name)){
        $sb_result .='<video data-autopause="false" data-mute="true" data-loop="true" data-fill-mode="fill">
                                  <source id="mp4" src="'.SB_VIDEO.$video_name.'" type="video/mp4"/>
                                </video>';
      }
        
        $sb_result .='<div class="ms-layer ms-caption text-center" data-origin="mc">';
        $sb_result .='<ul class="list-unstyled slider-link-list">';

      if(!empty($slider_link1)){
        $sb_result .=$slider_link1;
      }

      if(!empty($slider_link2)){
        $sb_result .=$slider_link2;
      }

      if(!empty($slider_link3)){
        $sb_result .=$slider_link3;
      }

        $sb_result .='</ul>';
      if(!empty($logo_img)){
        $sb_result .='<img class=" slider-logo-img" alt=""
                                  data-ease = "easeOutQuart"
                                  src="'.$logo_img.'"
                                />';
      }

      if(!empty($title)){
        $sb_result .= '<h1>'.$title.'</h1>';
      }

      if(!empty($description)){
        $sb_result .='<p class="text-uppercase">'.$description.'</p>';  
      }

      if(!empty($btn_name1)){
        $sb_result .= '<a class="btn btn-transparent mr10" href="'.$btn_link1.'">'.$btn_name1.'</a>';
      } 

      if(!empty($btn_name2)){
        $sb_result .= '<a class="btn btn-secondary" href="'.$btn_link2.'">'.$btn_name2.'</a>';
      }
        $sb_result .='</div>';
        $sb_result .= '</div>';


        }
      }
      $i++;
    }
  }
}

  $sb_result .= '</div></div>';
  return $sb_result;
}
add_shortcode( 'sb_slider_six_shortcode', 'sb_slider_six' );


/*-------------------------------------------------------------------------
  END SB SLIDER 6 SHORTCODE
------------------------------------------------------------------------- */



/*-------------------------------------------------------------------------
  START SB SLIDER 7 SHORTCODE
------------------------------------------------------------------------- */

function sb_slider_seven($atts , $content = null){

  extract(shortcode_atts( array('post_id'=>''), $atts ));

   // global $sb_option_data;  
   //_log($sb_option_data);
   // _log('merin');
 $sb_result = '<div class="sb-slider-section default">
                        <div class="master-slider ms-skin-default  app-master-slider">';
$args = array(

  'post_type' => 'slider',
  'posts_per_page' => -1,

  );

$get_all_slider = get_posts($args);
// _log($get_all_slider);
$i=1;

if(isset($get_all_slider)&& !empty($get_all_slider)){
  foreach ($get_all_slider as $key => $value) {
// _log('mer');
    $slider_meta = get_post_meta($post_id, '_sb_slider', true);    
      // _log($slider_meta);
    
    if($i==1){

      if(isset($slider_meta)&& !empty($slider_meta)){
      foreach($slider_meta as $meta_key => $meta_value){

          if(isset($meta_value['_slider_image'])&& !empty($meta_value['_slider_image'])){
            $image_id1 = $meta_value['_slider_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $slider_img = sb_aq_resize( $large_image1, 1920, 700, true );
          }
          else{
            $slider_img ='';
          }

          if(isset($meta_value['_icon_image'])&& !empty($meta_value['_icon_image'])){
            $image_id1 = $meta_value['_icon_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $logo_img = sb_aq_resize( $large_image1, 208, 252, true );
          }
          else{
            $logo_img ='';
          }

          if(isset($meta_value['_title'])&& !empty($meta_value['_title'])){
            $title = $meta_value['_title'];
          }
          else{
            $title ='';
          }

          if(isset($meta_value['_description'])&& !empty($meta_value['_description'])){
            $description = $meta_value['_description'];
          }
          else{
            $description ='';
          }

          if(isset($meta_value['_btn_name1'])&& !empty($meta_value['_btn_name1'])){
            $btn_name1 = $meta_value['_btn_name1'];
          }
          else{
            $btn_name1 ='';
          }

          if(isset($meta_value['_btn_link1'])&& !empty($meta_value['_btn_link1'])){
            $btn_link1 = $meta_value['_btn_link1'];
          }
          else{
            $btn_link1 ='';
          }

          if(isset($meta_value['_btn_name2'])&& !empty($meta_value['_btn_name2'])){
            $btn_name2 = $meta_value['_btn_name2'];
          }
          else{
            $btn_name2 ='';
          }

          if(isset($meta_value['_btn_link2'])&& !empty($meta_value['_btn_link2'])){
            $btn_link2 = $meta_value['_btn_link2'];
          }
          else{
            $btn_link2 ='';
          }

          if(isset($meta_value['_video_name'])&& !empty($meta_value['_video_name'])){
            $video_name = $meta_value['_video_name'];
          }
          else{
            $video_name ='';
          }

          if(isset($meta_value['_slider_link1'])&& !empty($meta_value['_slider_link1'])){
            $slider_link1 = $meta_value['_slider_link1'];
          }
          else{
            $slider_link1 ='';
          }

          if(isset($meta_value['_slider_link2'])&& !empty($meta_value['_slider_link2'])){
            $slider_link2 = $meta_value['_slider_link2'];
          }
          else{
            $slider_link2 ='';
          }

          if(isset($meta_value['_slider_link3'])&& !empty($meta_value['_slider_link3'])){
            $slider_link3 = $meta_value['_slider_link3'];
          }
          else{
            $slider_link3 ='';
          }
          // _log($video_name);
      $sb_result .='<div class="ms-slide">';
    
      if(!empty($slider_img)){
        $sb_result .='<img src="'.SB_JS.'masterslider/blank.gif" data-src="'.$slider_img.'" alt="lorel impsum dolem"/>';
      // _log($slider_img);
      }

      if(!empty($video_name)){
        $sb_result .='<video data-autopause="false" data-mute="true" data-loop="true" data-fill-mode="fill">
                                  <source id="mp4" src="'.SB_VIDEO.$video_name.'" type="video/mp4"/>
                                </video>';
      }
        
        $sb_result .='<div class="ms-layer ms-caption" data-origin="ml"><div class="container">';

      if(!empty($logo_img)){
        $sb_result .='<img class=" slider-logo-img" alt=""
                                  data-ease = "easeOutQuart"
                                  src="'.$logo_img.'"
                                />';
      }

      if(!empty($title)){
        $sb_result .= $title;
      }

      if(!empty($description)){
        $sb_result .='<p class="text-uppercase">'.$description.'</p>';  
      }

      if(!empty($btn_name1)){
        $sb_result .= '<a class="btn btn-transparent mr10" href="'.$btn_link1.'">'.$btn_name1.'</a>';
      } 

      if(!empty($btn_name2)){
        $sb_result .= '<a class="btn btn-primary" href="'.$btn_link2.'">'.$btn_name2.'</a>';
      }
        $sb_result .='</div></div>';
        $sb_result .= '</div>';


        }
      }
      $i++;
    }
  }
}

  $sb_result .= '</div></div>';
  return $sb_result;
}
add_shortcode( 'sb_slider_seven_shortcode', 'sb_slider_seven' );


/*-------------------------------------------------------------------------
  END SB SLIDER 7 SHORTCODE
------------------------------------------------------------------------- */



/*-------------------------------------------------------------------------
  START SB SLIDER 8 SHORTCODE
------------------------------------------------------------------------- */

function sb_slider_eight($atts , $content = null){

  extract(shortcode_atts( array('post_id'=>''), $atts ));

   // global $sb_option_data;  
   //_log($sb_option_data);
   // _log('merin');
 $sb_result = '<div class="sb-slider-section default">
                        <div class="master-slider ms-skin-default  app-master-slider">';
$args = array(

  'post_type' => 'slider',
  'posts_per_page' => -1,

  );

$get_all_slider = get_posts($args);
// _log($get_all_slider);
$i=1;

if(isset($get_all_slider)&& !empty($get_all_slider)){
  foreach ($get_all_slider as $key => $value) {
// _log('mer');
    $slider_meta = get_post_meta($post_id, '_sb_slider', true);    
      // _log($slider_meta);
    
    if($i==1){

      if(isset($slider_meta)&& !empty($slider_meta)){
      foreach($slider_meta as $meta_key => $meta_value){

          if(isset($meta_value['_slider_image'])&& !empty($meta_value['_slider_image'])){
            $image_id1 = $meta_value['_slider_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $slider_img = sb_aq_resize( $large_image1, 1920, 700, true );
          }
          else{
            $slider_img ='';
          }

          if(isset($meta_value['_icon_image'])&& !empty($meta_value['_icon_image'])){
            $image_id1 = $meta_value['_icon_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $logo_img = sb_aq_resize( $large_image1, 208, 252, true );
          }
          else{
            $logo_img ='';
          }

          if(isset($meta_value['_title'])&& !empty($meta_value['_title'])){
            $title = $meta_value['_title'];
          }
          else{
            $title ='';
          }

          if(isset($meta_value['_description'])&& !empty($meta_value['_description'])){
            $description = $meta_value['_description'];
          }
          else{
            $description ='';
          }

          if(isset($meta_value['_btn_name1'])&& !empty($meta_value['_btn_name1'])){
            $btn_name1 = $meta_value['_btn_name1'];
          }
          else{
            $btn_name1 ='';
          }

          if(isset($meta_value['_btn_link1'])&& !empty($meta_value['_btn_link1'])){
            $btn_link1 = $meta_value['_btn_link1'];
          }
          else{
            $btn_link1 ='';
          }

          if(isset($meta_value['_btn_name2'])&& !empty($meta_value['_btn_name2'])){
            $btn_name2 = $meta_value['_btn_name2'];
          }
          else{
            $btn_name2 ='';
          }

          if(isset($meta_value['_btn_link2'])&& !empty($meta_value['_btn_link2'])){
            $btn_link2 = $meta_value['_btn_link2'];
          }
          else{
            $btn_link2 ='';
          }

          if(isset($meta_value['_video_name'])&& !empty($meta_value['_video_name'])){
            $video_name = $meta_value['_video_name'];
          }
          else{
            $video_name ='';
          }

          if(isset($meta_value['_slider_link1'])&& !empty($meta_value['_slider_link1'])){
            $slider_link1 = $meta_value['_slider_link1'];
          }
          else{
            $slider_link1 ='';
          }

          if(isset($meta_value['_slider_link2'])&& !empty($meta_value['_slider_link2'])){
            $slider_link2 = $meta_value['_slider_link2'];
          }
          else{
            $slider_link2 ='';
          }

          if(isset($meta_value['_slider_link3'])&& !empty($meta_value['_slider_link3'])){
            $slider_link3 = $meta_value['_slider_link3'];
          }
          else{
            $slider_link3 ='';
          }
          // _log($video_name);
      $sb_result .='<div class="ms-slide">';
    
      if(!empty($slider_img)){
        $sb_result .='<img src="'.SB_JS.'masterslider/blank.gif" data-src="'.$slider_img.'" alt="lorel impsum dolem"/>';
      // _log($slider_img);
      }

      if(!empty($video_name)){
        $sb_result .='<video data-autopause="false" data-mute="true" data-loop="true" data-fill-mode="fill">
                                  <source id="mp4" src="'.SB_VIDEO.$video_name.'" type="video/mp4"/>
                                </video>';
      }
        
        $sb_result .='<div class="ms-layer ms-caption" data-origin="ml"><div class="container">';

      if(!empty($logo_img)){
        $sb_result .='<img class=" slider-logo-img" alt=""
                                  data-ease = "easeOutQuart"
                                  src="'.$logo_img.'"
                                />';
      }

      if(!empty($title)){
        $sb_result .= $title;
      }

      if(!empty($description)){
        $sb_result .='<p class="text-uppercase">'.$description.'</p>';  
      }

      if(!empty($btn_name1)){
        $sb_result .= '<a class="btn btn-transparent mr10" href="'.$btn_link1.'">'.$btn_name1.'</a>';
      } 

      if(!empty($btn_name2)){
        $sb_result .= '<a class="btn btn-primary" href="'.$btn_link2.'">'.$btn_name2.'</a>';
      }
        $sb_result .='</div></div>';
        $sb_result .= '</div>';


        }
      }
      $i++;
    }
  }
}

  $sb_result .= '</div></div>';
  return $sb_result;
}
add_shortcode( 'sb_slider_eight_shortcode', 'sb_slider_eight' );


/*-------------------------------------------------------------------------
  END SB SLIDER 8 SHORTCODE
------------------------------------------------------------------------- */



/*-------------------------------------------------------------------------
  START SB SLIDER 9 SHORTCODE
------------------------------------------------------------------------- */

function sb_slider_nine($atts , $content = null){

  extract(shortcode_atts( array('post_id'=>''), $atts ));

   // global $sb_option_data;  
   //_log($sb_option_data);
   // _log('merin');
 $sb_result = '<div class="sb-slider-section default">
                        <div class="master-slider ms-skin-default  app-master-slider">';
$args = array(

  'post_type' => 'slider',
  'posts_per_page' => -1,

  );

$get_all_slider = get_posts($args);
// _log($get_all_slider);
$i=1;

if(isset($get_all_slider)&& !empty($get_all_slider)){
  foreach ($get_all_slider as $key => $value) {
// _log('mer');
    $slider_meta = get_post_meta($post_id, '_sb_slider', true);    
      // _log($slider_meta);
    
    if($i==1){

      if(isset($slider_meta)&& !empty($slider_meta)){
      foreach($slider_meta as $meta_key => $meta_value){

          if(isset($meta_value['_slider_image'])&& !empty($meta_value['_slider_image'])){
            $image_id1 = $meta_value['_slider_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $slider_img = sb_aq_resize( $large_image1, 1920, 700, true );
          }
          else{
            $slider_img ='';
          }

          if(isset($meta_value['_icon_image'])&& !empty($meta_value['_icon_image'])){
            $image_id1 = $meta_value['_icon_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $logo_img = sb_aq_resize( $large_image1, 208, 252, true );
          }
          else{
            $logo_img ='';
          }

          if(isset($meta_value['_title'])&& !empty($meta_value['_title'])){
            $title = $meta_value['_title'];
          }
          else{
            $title ='';
          }

          if(isset($meta_value['_description'])&& !empty($meta_value['_description'])){
            $description = $meta_value['_description'];
          }
          else{
            $description ='';
          }

          if(isset($meta_value['_btn_name1'])&& !empty($meta_value['_btn_name1'])){
            $btn_name1 = $meta_value['_btn_name1'];
          }
          else{
            $btn_name1 ='';
          }

          if(isset($meta_value['_btn_link1'])&& !empty($meta_value['_btn_link1'])){
            $btn_link1 = $meta_value['_btn_link1'];
          }
          else{
            $btn_link1 ='';
          }

          if(isset($meta_value['_btn_name2'])&& !empty($meta_value['_btn_name2'])){
            $btn_name2 = $meta_value['_btn_name2'];
          }
          else{
            $btn_name2 ='';
          }

          if(isset($meta_value['_btn_link2'])&& !empty($meta_value['_btn_link2'])){
            $btn_link2 = $meta_value['_btn_link2'];
          }
          else{
            $btn_link2 ='';
          }

          if(isset($meta_value['_video_name'])&& !empty($meta_value['_video_name'])){
            $video_name = $meta_value['_video_name'];
          }
          else{
            $video_name ='';
          }

          if(isset($meta_value['_slider_link1'])&& !empty($meta_value['_slider_link1'])){
            $slider_link1 = $meta_value['_slider_link1'];
          }
          else{
            $slider_link1 ='';
          }

          if(isset($meta_value['_slider_link2'])&& !empty($meta_value['_slider_link2'])){
            $slider_link2 = $meta_value['_slider_link2'];
          }
          else{
            $slider_link2 ='';
          }

          if(isset($meta_value['_slider_link3'])&& !empty($meta_value['_slider_link3'])){
            $slider_link3 = $meta_value['_slider_link3'];
          }
          else{
            $slider_link3 ='';
          }
          // _log($video_name);
      $sb_result .='<div class="ms-slide">';
    
      if(!empty($slider_img)){
        $sb_result .='<img src="'.SB_JS.'masterslider/blank.gif" data-src="'.$slider_img.'" alt="lorel impsum dolem"/>';
      // _log($slider_img);
      }

      if(!empty($video_name)){
        $sb_result .='<video data-autopause="false" data-mute="true" data-loop="true" data-fill-mode="fill">
                                  <source id="mp4" src="'.SB_VIDEO.$video_name.'" type="video/mp4"/>
                                </video>';
      }
        
        $sb_result .='<div class="ms-layer ms-caption" data-origin="ml">
                              <div class="container">';

      if(!empty($logo_img)){
        $sb_result .='<img class=" slider-logo-img" alt=""
                                  data-ease = "easeOutQuart"
                                  src="'.$logo_img.'"
                                />';
      }

      if(!empty($title)){
        $sb_result .= $title;
      }

      if(!empty($description)){
        $sb_result .='<p class="text-uppercase long-text">'.$description.'</p>';  
      }

      if(!empty($btn_name1)){
        $sb_result .= '<a class="btn btn-transparent mr10" href="'.$btn_link1.'">'.$btn_name1.'</a>';
      } 

      if(!empty($btn_name2)){
        $sb_result .= '<a class="btn btn-primary" href="'.$btn_link2.'">'.$btn_name2.'</a>';
      }
        $sb_result .='</div></div>';
        $sb_result .= '</div>';


        }
      }
      $i++;
    }
  }
}

  $sb_result .= '</div></div>';
  return $sb_result;
}
add_shortcode( 'sb_slider_nine_shortcode', 'sb_slider_nine' );


/*-------------------------------------------------------------------------
  END SB SLIDER 9 SHORTCODE
------------------------------------------------------------------------- */



/*-------------------------------------------------------------------------
  START SB SLIDER 10 SHORTCODE
------------------------------------------------------------------------- */

function sb_slider_ten($atts , $content = null){

  extract(shortcode_atts( array('post_id'=>''), $atts ));

   // global $sb_option_data;  
   //_log($sb_option_data);
   // _log('merin');
 $sb_result = '<div class="sb-slider-section default">
                        <div class="master-slider ms-skin-default  secondary-master-slider">';
$args = array(

  'post_type' => 'slider',
  'posts_per_page' => -1,

  );

$get_all_slider = get_posts($args);
// _log($get_all_slider);
$i=1;

if(isset($get_all_slider)&& !empty($get_all_slider)){
  foreach ($get_all_slider as $key => $value) {
// _log('mer');
    $slider_meta = get_post_meta($post_id, '_sb_slider', true);    
      // _log($slider_meta);
    
    if($i==1){

      if(isset($slider_meta)&& !empty($slider_meta)){
      foreach($slider_meta as $meta_key => $meta_value){

          if(isset($meta_value['_slider_image'])&& !empty($meta_value['_slider_image'])){
            $image_id1 = $meta_value['_slider_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $slider_img = sb_aq_resize( $large_image1, 1920, 700, true );
          }
          else{
            $slider_img ='';
          }

          if(isset($meta_value['_icon_image'])&& !empty($meta_value['_icon_image'])){
            $image_id1 = $meta_value['_icon_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $logo_img = sb_aq_resize( $large_image1, 1008, 312, true );
          }
          else{
            $logo_img ='';
          }

          if(isset($meta_value['_title'])&& !empty($meta_value['_title'])){
            $title = $meta_value['_title'];
          }
          else{
            $title ='';
          }

          if(isset($meta_value['_description'])&& !empty($meta_value['_description'])){
            $description = $meta_value['_description'];
          }
          else{
            $description ='';
          }

          if(isset($meta_value['_btn_name1'])&& !empty($meta_value['_btn_name1'])){
            $btn_name1 = $meta_value['_btn_name1'];
          }
          else{
            $btn_name1 ='';
          }

          if(isset($meta_value['_btn_link1'])&& !empty($meta_value['_btn_link1'])){
            $btn_link1 = $meta_value['_btn_link1'];
          }
          else{
            $btn_link1 ='';
          }

          if(isset($meta_value['_btn_name2'])&& !empty($meta_value['_btn_name2'])){
            $btn_name2 = $meta_value['_btn_name2'];
          }
          else{
            $btn_name2 ='';
          }

          if(isset($meta_value['_btn_link2'])&& !empty($meta_value['_btn_link2'])){
            $btn_link2 = $meta_value['_btn_link2'];
          }
          else{
            $btn_link2 ='';
          }

          if(isset($meta_value['_video_name'])&& !empty($meta_value['_video_name'])){
            $video_name = $meta_value['_video_name'];
          }
          else{
            $video_name ='';
          }

          if(isset($meta_value['_slider_link1'])&& !empty($meta_value['_slider_link1'])){
            $slider_link1 = $meta_value['_slider_link1'];
          }
          else{
            $slider_link1 ='';
          }

          if(isset($meta_value['_slider_link2'])&& !empty($meta_value['_slider_link2'])){
            $slider_link2 = $meta_value['_slider_link2'];
          }
          else{
            $slider_link2 ='';
          }

          if(isset($meta_value['_slider_link3'])&& !empty($meta_value['_slider_link3'])){
            $slider_link3 = $meta_value['_slider_link3'];
          }
          else{
            $slider_link3 ='';
          }
          // _log($video_name);
      $sb_result .='<div class="ms-slide">';
    
      if(!empty($slider_img)){
        $sb_result .='<img src="'.SB_JS.'masterslider/blank.gif" data-src="'.$slider_img.'" alt="lorel impsum dolem"/>';
      // _log($slider_img);
      }

      if(!empty($video_name)){
        $sb_result .='<video data-autopause="false" data-mute="true" data-loop="true" data-fill-mode="fill">
                                  <source id="mp4" src="'.SB_VIDEO.$video_name.'" type="video/mp4"/>
                                </video>';
      }
        
        $sb_result .='<div class="ms-layer ms-caption text-center" data-origin="mc">';

      if(!empty($logo_img)){
        $sb_result .='<img class="browser-big-logo" alt=""
                data-ease = "easeOutQuart"
                src="'.$logo_img.'"
              />';
      }

      if(!empty($title)){
        $sb_result .= $title;
      }

      if(!empty($description)){
        $sb_result .='<p class="text-uppercase long-text">'.$description.'</p>';  
      }

      if(!empty($btn_name1)){
        $sb_result .= '<a class="btn btn-transparent mr10" href="'.$btn_link1.'">'.$btn_name1.'</a>';
      } 

      if(!empty($btn_name2)){
        $sb_result .= '<a class="btn btn-primary" href="'.$btn_link2.'">'.$btn_name2.'</a>';
      }
        $sb_result .='</div>';
        $sb_result .= '</div>';


        }
      }
      $i++;
    }
  }
}

  $sb_result .= '</div></div>';
  return $sb_result;
}
add_shortcode( 'sb_slider_ten_shortcode', 'sb_slider_ten' );


/*-------------------------------------------------------------------------
  END SB SLIDER 10 SHORTCODE
------------------------------------------------------------------------- */



/*-------------------------------------------------------------------------
  START SB SLIDER 11 SHORTCODE
------------------------------------------------------------------------- */

function sb_slider_eleven($atts , $content = null){

  extract(shortcode_atts( array('post_id'=>''), $atts ));

   // global $sb_option_data;  
   //_log($sb_option_data);
   // _log('merin');
 $sb_result = '<div class="sb-slider-section default">
                        <div class="master-slider ms-skin-default  app-master-slider-secondary">';
$args = array(

  'post_type' => 'slider',
  'posts_per_page' => -1,

  );

$get_all_slider = get_posts($args);
// _log($get_all_slider);
$i=1;

if(isset($get_all_slider)&& !empty($get_all_slider)){
  foreach ($get_all_slider as $key => $value) {
// _log('mer');
    $slider_meta = get_post_meta($post_id, '_sb_slider', true);    
      // _log($slider_meta);
    
    if($i==1){

      if(isset($slider_meta)&& !empty($slider_meta)){
      foreach($slider_meta as $meta_key => $meta_value){

          if(isset($meta_value['_slider_image'])&& !empty($meta_value['_slider_image'])){
            $image_id1 = $meta_value['_slider_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $slider_img = sb_aq_resize( $large_image1, 1920, 700, true );
          }
          else{
            $slider_img ='';
          }

          if(isset($meta_value['_icon_image'])&& !empty($meta_value['_icon_image'])){
            $image_id1 = $meta_value['_icon_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $logo_img = sb_aq_resize( $large_image1, 1008, 312, true );
          }
          else{
            $logo_img ='';
          }

          if(isset($meta_value['_title'])&& !empty($meta_value['_title'])){
            $title = $meta_value['_title'];
          }
          else{
            $title ='';
          }

          if(isset($meta_value['_description'])&& !empty($meta_value['_description'])){
            $description = $meta_value['_description'];
          }
          else{
            $description ='';
          }

          if(isset($meta_value['_btn_name1'])&& !empty($meta_value['_btn_name1'])){
            $btn_name1 = $meta_value['_btn_name1'];
          }
          else{
            $btn_name1 ='';
          }

          if(isset($meta_value['_btn_link1'])&& !empty($meta_value['_btn_link1'])){
            $btn_link1 = $meta_value['_btn_link1'];
          }
          else{
            $btn_link1 ='';
          }

          if(isset($meta_value['_btn_name2'])&& !empty($meta_value['_btn_name2'])){
            $btn_name2 = $meta_value['_btn_name2'];
          }
          else{
            $btn_name2 ='';
          }

          if(isset($meta_value['_btn_link2'])&& !empty($meta_value['_btn_link2'])){
            $btn_link2 = $meta_value['_btn_link2'];
          }
          else{
            $btn_link2 ='';
          }

          if(isset($meta_value['_video_name'])&& !empty($meta_value['_video_name'])){
            $video_name = $meta_value['_video_name'];
          }
          else{
            $video_name ='';
          }

          if(isset($meta_value['_slider_link1'])&& !empty($meta_value['_slider_link1'])){
            $slider_link1 = $meta_value['_slider_link1'];
          }
          else{
            $slider_link1 ='';
          }

          if(isset($meta_value['_slider_link2'])&& !empty($meta_value['_slider_link2'])){
            $slider_link2 = $meta_value['_slider_link2'];
          }
          else{
            $slider_link2 ='';
          }

          if(isset($meta_value['_slider_link3'])&& !empty($meta_value['_slider_link3'])){
            $slider_link3 = $meta_value['_slider_link3'];
          }
          else{
            $slider_link3 ='';
          }
          // _log($video_name);
      $sb_result .='<div class="ms-slide">';
    
      if(!empty($slider_img)){
        $sb_result .='<img src="'.SB_JS.'masterslider/blank.gif" data-src="'.$slider_img.'" alt="lorel impsum dolem"/>';
      // _log($slider_img);
      }

      if(!empty($video_name)){
        $sb_result .='<video data-autopause="false" data-mute="true" data-loop="true" data-fill-mode="fill">
                                  <source id="mp4" src="'.SB_VIDEO.$video_name.'" type="video/mp4"/>
                                </video>';
      }
        
        $sb_result .='<div class="ms-layer ms-caption" data-origin="ml" >
                                <div class="container">';

      if(!empty($logo_img)){
        $sb_result .='<img class="browser-big-logo" alt=""
                data-ease = "easeOutQuart"
                src="'.$logo_img.'"
              />';
      }

      if(!empty($title)){
        $sb_result .= $title;
      }

      if(!empty($description)){
        $sb_result .=$description;  
      }

      if(!empty($btn_name1)){
        $sb_result .= '<a class="btn btn-transparent mr10" href="'.$btn_link1.'">'.$btn_name1.'</a>';
      } 

      if(!empty($btn_name2)){
        $sb_result .= '<a class="btn btn-primary" href="'.$btn_link2.'">'.$btn_name2.'</a>';
      }
        $sb_result .='</div></div>';
        $sb_result .= '</div>';


        }
      }
      $i++;
    }
  }
}

  $sb_result .= '</div></div>';
  return $sb_result;
}
add_shortcode( 'sb_slider_eleven_shortcode', 'sb_slider_eleven' );


/*-------------------------------------------------------------------------
  END SB SLIDER 11 SHORTCODE
------------------------------------------------------------------------- */



/*-------------------------------------------------------------------------
  START SB SLIDER 12 SHORTCODE
------------------------------------------------------------------------- */

function sb_slider_twelve($atts , $content = null){

  extract(shortcode_atts( array('post_id'=>''), $atts ));

   // global $sb_option_data;  
   //_log($sb_option_data);
   // _log('merin');
 $sb_result = '<div class="sb-slider-section default">
                        <div class="master-slider ms-skin-default  small-height-slider with-custom-bullet">';
$args = array(

  'post_type' => 'slider',
  'posts_per_page' => -1,

  );

$get_all_slider = get_posts($args);
// _log($get_all_slider);
$i=1;

if(isset($get_all_slider)&& !empty($get_all_slider)){
  foreach ($get_all_slider as $key => $value) {
// _log('mer');
    $slider_meta = get_post_meta($post_id, '_sb_slider', true);    
      // _log($slider_meta);
    
    if($i==1){

      if(isset($slider_meta)&& !empty($slider_meta)){
      foreach($slider_meta as $meta_key => $meta_value){

          if(isset($meta_value['_slider_image'])&& !empty($meta_value['_slider_image'])){
            $image_id1 = $meta_value['_slider_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $slider_img = sb_aq_resize( $large_image1, 1920, 483, true );
          }
          else{
            $slider_img ='';
          }

          if(isset($meta_value['_icon_image'])&& !empty($meta_value['_icon_image'])){
            $image_id1 = $meta_value['_icon_image']; 
            $large_image1 = wp_get_attachment_url( $image_id1 ,'full');  
            $logo_img = sb_aq_resize( $large_image1, 446, 103, true );
          }
          else{
            $logo_img ='';
          }

          if(isset($meta_value['_title'])&& !empty($meta_value['_title'])){
            $title = $meta_value['_title'];
          }
          else{
            $title ='';
          }

          if(isset($meta_value['_description'])&& !empty($meta_value['_description'])){
            $description = $meta_value['_description'];
          }
          else{
            $description ='';
          }

          if(isset($meta_value['_btn_name1'])&& !empty($meta_value['_btn_name1'])){
            $btn_name1 = $meta_value['_btn_name1'];
          }
          else{
            $btn_name1 ='';
          }

          if(isset($meta_value['_btn_link1'])&& !empty($meta_value['_btn_link1'])){
            $btn_link1 = $meta_value['_btn_link1'];
          }
          else{
            $btn_link1 ='';
          }

          if(isset($meta_value['_btn_name2'])&& !empty($meta_value['_btn_name2'])){
            $btn_name2 = $meta_value['_btn_name2'];
          }
          else{
            $btn_name2 ='';
          }

          if(isset($meta_value['_btn_link2'])&& !empty($meta_value['_btn_link2'])){
            $btn_link2 = $meta_value['_btn_link2'];
          }
          else{
            $btn_link2 ='';
          }

          if(isset($meta_value['_video_name'])&& !empty($meta_value['_video_name'])){
            $video_name = $meta_value['_video_name'];
          }
          else{
            $video_name ='';
          }

          if(isset($meta_value['_slider_link1'])&& !empty($meta_value['_slider_link1'])){
            $slider_link1 = $meta_value['_slider_link1'];
          }
          else{
            $slider_link1 ='';
          }

          if(isset($meta_value['_slider_link2'])&& !empty($meta_value['_slider_link2'])){
            $slider_link2 = $meta_value['_slider_link2'];
          }
          else{
            $slider_link2 ='';
          }

          if(isset($meta_value['_slider_link3'])&& !empty($meta_value['_slider_link3'])){
            $slider_link3 = $meta_value['_slider_link3'];
          }
          else{
            $slider_link3 ='';
          }
          // _log($video_name);
      $sb_result .='<div class="ms-slide">';
    
      if(!empty($slider_img)){
        $sb_result .='<img src="'.SB_JS.'masterslider/blank.gif" data-src="'.$slider_img.'" alt="lorel impsum dolem"/>';
      // _log($slider_img);
      }

      if(!empty($video_name)){
        $sb_result .='<video data-autopause="false" data-mute="true" data-loop="true" data-fill-mode="fill">
                                  <source id="mp4" src="'.SB_VIDEO.$video_name.'" type="video/mp4"/>
                                </video>';
      }
        
        $sb_result .='<div class="ms-layer ms-caption" data-origin="mc" >
                                <div class="container">
                                <div class="corporate-slider-text">';

      if(!empty($logo_img)){
        $sb_result .='<img class="cor-logo" src="'.$logo_img.'" alt="">';
      }

      if(!empty($title)){
        $sb_result .= $title;
      }

      if(!empty($description)){
        $sb_result .=$description;  
      }

      if(!empty($btn_name1)){
        $sb_result .= '<a class="btn btn-transparent mr10" href="'.$btn_link1.'">'.$btn_name1.'</a>';
      } 

      if(!empty($btn_name2)){
        $sb_result .= '<a class="btn btn-primary" href="'.$btn_link2.'">'.$btn_name2.'</a>';
      }
        $sb_result .='</div></div></div>';
        $sb_result .= '</div>';


        }
      }
      $i++;
    }
  }
}

  $sb_result .= '</div></div>';
  return $sb_result;
}
add_shortcode( 'sb_slider_twelve_shortcode', 'sb_slider_twelve' );


/*-------------------------------------------------------------------------
  END SB SLIDER 12 SHORTCODE
------------------------------------------------------------------------- */


/*-------------------------------------------------------------------------
  START SB COPYWRITER WELCOME BLOCK SHORTCODE
------------------------------------------------------------------------- */

function sb_welcome_block($atts , $content = null){

  extract(shortcode_atts( array('primary_title'=>'','sub_title'=>'','welcome_des'=>'','bg_img'=>'','sign_img'=>'','btn_name'=>'','btn_link'=>''), $atts ));

  if(isset($bg_img)&&!empty($bg_img)){
      $result ='<div class="uou-demo-block style=background: url("'.$bg_img.'") top center no-repeat; pb50" >';
      }

  else{
      $result ='<div class="uou-demo-block copywrite-bg-image pb50" >';
    }

      $result .='<div class="container">';

    if(isset($primary_title)&&!empty($primary_title)){
      $result .='<h2 class="block-title left">'.$primary_title.'</h2>';
    }

    if(isset($sub_title)&&!empty($sub_title)){
      $result .='<p class="block-secondary-title-m left">'.$sub_title.'</p>';
    }

    $result .='</div>';

    $result .='<div class="container">';

    if(isset($welcome_des)){
    $result .= '<p class="small-width-text">'.$welcome_des.'</p>';
    }

    if(isset($sign_img)){
    $result .='<img class="sign" src="'.SB_IMAGE.$sign_img.'" alt="">';
    }

    if(isset($btn_name)){
    $result .='<a href="http://'.$btn_link.'" class="btn btn-transparent-primary mt20">'.$btn_name.'</a>';
    }

    $result .='</div>
              </div>';

  return $result;  
  
}

add_shortcode( 'sb_welcome_block_shortcode', 'sb_welcome_block' );

/*-------------------------------------------------------------------------
 END SB COPYWRITER WELCOME BLOCK SHORTCODE
------------------------------------------------------------------------- */


/*-------------------------------------------------------------------------
  START SB COPYWRITER MAP BLOCK SHORTCODE
------------------------------------------------------------------------- */

function sb_copywriter_map_block($atts , $content = null){

  extract(shortcode_atts( array(), $atts ));


   $sb_result ='<div id="contact-map" style="width:100%; height: 300px;"></div>';


    return $sb_result;
}
add_shortcode( 'sb_copywriter_map_block_shortcode', 'sb_copywriter_map_block' );

/*-------------------------------------------------------------------------
 END SB COPYWRITER MAP BLOCK SHORTCODE
------------------------------------------------------------------------- */



/*-------------------------------------------------------------------------
  START SB COPYWRITER CONTACT BLOCK SHORTCODE
------------------------------------------------------------------------- */

function sb_copywriter_contact_block($atts , $content = null){

  extract(shortcode_atts( array('title'=>'','post_id'=>''), $atts ));

  $args = array(

  'post_type' => 'company_location',
  'posts_per_page' => -1,

  );

$get_all_location = get_posts($args);
// _log($get_all_location);
$i=1;


if(isset($get_all_location)&& !empty($get_all_location)){
  foreach ($get_all_location as $key => $value) {
    if($i==1){
// _log('mer');
    $all_post_meta = get_post_custom( $post_id);
    // _log($all_post_meta);
  // $location_meta = get_post_meta(79, '_sb_company_location', true); 
  // _log($location_meta);

  $result  ='<div class="uou-demo-block">';

if(isset($title)&&!empty($title)){
  $result .='<h2 class="block-title invert">'.$title.'</h2>';
}
    
  $result .='<p class="block-secondary-title-m">
                '.$value->post_title.'
              </p>'; 


if(isset($all_post_meta['_sb_company_location_map'][0])&&!empty($all_post_meta['_sb_company_location_map'][0])){
  $result .='<div class="uou-map-section mb60">
                <div class="uou-block-12a">
                 <div class="map-container">';
  $result .=do_shortcode($all_post_meta['_sb_company_location_map'][0]);
  $result .='</div>
            </div> 
           </div>';
}

  $result .='<div class="container">
              <div class="row">

                <div class="col-md-12">
                  <div class="demo-contact-form invert">';

if(isset($all_post_meta['_sb_company_location_contact'][0])&&!empty($all_post_meta['_sb_company_location_contact'][0])){
  $result .=do_shortcode($all_post_meta['_sb_company_location_contact'][0]);
}


 $result .='</div>
          </div>
        </div>
      </div>
  </div>';
 
 $i++; 
}
  }
}

    return $result;
}
add_shortcode( 'sb_copywriter_contact_block_shortcode', 'sb_copywriter_contact_block' );

/*-------------------------------------------------------------------------
 END SB COPYWRITER CONTACT BLOCK SHORTCODE
------------------------------------------------------------------------- */



/*-------------------------------------------------------------------------
  START SB CORPORATE CONTACT BLOCK SHORTCODE
------------------------------------------------------------------------- */

function sb_corporate_contact_block($atts , $content = null){

  extract(shortcode_atts( array('title'=>'','bg_img'=>'','post_id'=>''), $atts ));

  $args = array(

  'post_type' => 'company_location',
  'posts_per_page' => -1,

  );

$get_all_location = get_posts($args);
// _log($get_all_location);
$i=1;


if(isset($get_all_location)&& !empty($get_all_location)){
  foreach ($get_all_location as $key => $value) {
    if($i==1){
// _log('mer');
    $all_post_meta = get_post_custom( $post_id);
if(isset($bg_img)&&!empty($bg_img)){
  $result ='<div class="uou-demo-block has-bg-image" data-bg-image="'.SB_IMAGE.$bg_img.'">';
  }

if(isset($title)&&!empty($title)){
  $result .='<h2 class="block-title invert">'.$title.'</h2>';
}
    
  $result .='<p class="block-secondary-title-m">
                '.$value->post_title.'
              </p>'; 

  $result .='<div class="container">
              <div class="row">';

  $result .='<div class="col-md-6">
              <div class="address">
                <h2>'.$value->post_excerpt.'</h2>
              </div>
            </div>';

  $result .='<div class="col-md-6">
              <div class="demo-contact-form invert">';

if(isset($all_post_meta['_sb_company_location_contact'][0])&&!empty($all_post_meta['_sb_company_location_contact'][0])){
  $result .=do_shortcode($all_post_meta['_sb_company_location_contact'][0]);
}

 $result .='</div>
          </div>
        </div>
      </div>
  </div>';


if(isset($all_post_meta['_sb_company_location_map'][0])&&!empty($all_post_meta['_sb_company_location_map'][0])){
  $result .='<div class="uou-map-section">
                <div class="uou-block-12a">
                 <div class="map-container">';
  $result .=do_shortcode($all_post_meta['_sb_company_location_map'][0]);
  $result .='</div>
            </div> 
           </div>';}
 
 $i++; 
}
  }
}

    return $result;
}
add_shortcode( 'sb_corporate_contact_block_shortcode', 'sb_corporate_contact_block' );

/*-------------------------------------------------------------------------
 END SB CORPORATE CONTACT BLOCK SHORTCODE
------------------------------------------------------------------------- */



/*-------------------------------------------------------------------------
  START SB CREATIVE CONTACT BLOCK SHORTCODE
------------------------------------------------------------------------- */

function sb_creative_contact_block($atts , $content = null){

  extract(shortcode_atts( array('title'=>'','bg_img'=>'','post_id'=>''), $atts ));

  $args = array(

  'post_type' => 'company_location',
  'posts_per_page' => -1,

  );

$get_all_location = get_posts($args);
// _log($get_all_location);
$i=1;


if(isset($get_all_location)&& !empty($get_all_location)){
  foreach ($get_all_location as $key => $value) {
    if($i==1){
// _log('mer');
    $all_post_meta = get_post_custom( $post_id);
if(isset($bg_img)&&!empty($bg_img)){
  $result ='<div class="uou-demo-block has-bg-image" data-bg-image="'.SB_IMAGE.$bg_img.'" data-bg-color="000" data-bg-opacity=".20">';
  }

if(isset($title)&&!empty($title)){
  $result .='<h1 class="block-title">'.$title.'</h1>';
}
    
  $result .='<p class="block-secondary-title invert">
                '.$value->post_title.'
              </p>'; 

  $result .='<div class="container">';

  $result .='<div class="demo-contact-form">';

if(isset($all_post_meta['_sb_company_location_contact'][0])&&!empty($all_post_meta['_sb_company_location_contact'][0])){
  $result .=do_shortcode($all_post_meta['_sb_company_location_contact'][0]);
}

 $result .='</div>
          </div>
        </div>';


if(isset($all_post_meta['_sb_company_location_map'][0])&&!empty($all_post_meta['_sb_company_location_map'][0])){
  $result .='<div class="uou-map-section">
                <div class="uou-block-12a">
                 <div class="map-container">';
  $result .=do_shortcode($all_post_meta['_sb_company_location_map'][0]);
  $result .='</div>
            </div> 
           </div>';
         }
 
 $i++; 
}
  }
}

    return $result;
}
add_shortcode( 'sb_creative_contact_block_shortcode', 'sb_creative_contact_block' );

/*-------------------------------------------------------------------------
 END SB CREATIVE CONTACT BLOCK SHORTCODE
------------------------------------------------------------------------- */



/*-------------------------------------------------------------------------
  START SB CREATIVE ACCORDIAN BLOCK SHORTCODE
------------------------------------------------------------------------- */

function sb_creative_accordian_block($atts , $content = null){

  extract(shortcode_atts( array('title'=>'','des'=>'','class'=>''), $atts ));

  $result ='<div class="content-main">';

if(isset($title)&&!empty($title)){
   $result .='<h6><a class="toggle-btn '.$class.'" href="#"></a>'.$title.'</h6>';
}
  $result .='<div class="content-hidden '.$class.'">';

if(isset($des)&&!empty($des)){
  $result .='<p>'.$des.'</p>';
}
  $result .='</div>
          </div>';

  
    return $result;
}
add_shortcode( 'sb_creative_accordian', 'sb_creative_accordian_block' );

/*-------------------------------------------------------------------------
 END SB CREATIVE ACCORDIAN BLOCK SHORTCODE
------------------------------------------------------------------------- */


/*-------------------------------------------------------------------------
  START SB CREATIVE PROGRESS BLOCK SHORTCODE
------------------------------------------------------------------------- */

function sb_creative_progress_block($atts , $content = null){

  extract(shortcode_atts( array('title'=>'','class_text'=>'','value'=>''), $atts ));

  $result ='<div class="uou-progressbar-single">';

if(isset($title)&&!empty($title)){
  $result .='<h6>'.$title.'</h6>';
}
  $result .='<span class="main-bar">';
if(isset($class_text)&&!empty($class_text)){
  $result .='<span class="'.$class_text.'"></span>';
}
if(isset($value)&&!empty($value)){
  $result .='<b class="progress-percent">'.$value.'%</b>';
}
  $result .='</span>
          </div>';



  
    return $result;
}
add_shortcode( 'sb_creative_progress', 'sb_creative_progress_block' );

/*-------------------------------------------------------------------------
 END SB CREATIVE PROGRESS BLOCK SHORTCODE
------------------------------------------------------------------------- */



/*-------------------------------------------------------------------------
  START SB CREATIVE TEXT PROGRESS BLOCK SHORTCODE
------------------------------------------------------------------------- */

function sb_creative_text_progress_block($atts , $content = null){

  extract(shortcode_atts( array('post_id'=>''), $atts ));

  $args = array(

  'post_type' => 'sb_progress',
  'posts_per_page' => -1,

  );

$get_all_location = get_posts($args);
// _log($get_all_location);
$i=1;


if(isset($get_all_location)&& !empty($get_all_location)){
  foreach ($get_all_location as $key => $value) {
    if($i==1){
// _log('mer');
    $all_post_meta = get_post_custom( $post_id);

  $result ='<div class="uou-demo-block">
              <div class="container">
                <div class="row">
                  <div class="col-md-5">
                    <div class="uou-toggle-content">';

if(isset($all_post_meta['_sb_progress_bar_accordian_shortcode'][0])&&!empty($all_post_meta['_sb_progress_bar_accordian_shortcode'][0])){
  $result .=do_shortcode($all_post_meta['_sb_progress_bar_accordian_shortcode'][0]);
}

  $result .='</div>
            </div>
          <div class="col-md-7">';

if(isset($all_post_meta['_sb_progress_bar_progress_shortcode'][0])&&!empty($all_post_meta['_sb_progress_bar_progress_shortcode'][0])){
  $result .=do_shortcode($all_post_meta['_sb_progress_bar_progress_shortcode'][0]);
}

  $result .='</div>
            </div>
          </div> 
        </div>';

  $i++;

    }
  }
}
  
    return $result;
}
add_shortcode( 'sb_creative_text_progress', 'sb_creative_text_progress_block' );

/*-------------------------------------------------------------------------
 END SB CREATIVE TEXT PROGRESS BLOCK SHORTCODE
------------------------------------------------------------------------- */



/*-------------------------------------------------------------------------
  START SB CORPORATE  BLOCK SHORTCODE
------------------------------------------------------------------------- */

function sb_corporate_progress_block($atts , $content = null){

  extract(shortcode_atts( array('title'=>'','class_text'=>'','value'=>''), $atts ));

  $result ='<div class="col-md-2">
          <div class="round-counter-single">';
if(isset($class_text)&&!empty($class_text)){      
  $result .='<div class="'.$class_text.'">';
}

if(isset($value)&&!empty($value)){
  $result .='<span>'.$value.'<b>%</b></span>';
}
  $result .='<div class="slice">
              <div class="bar"></div>
              <div class="fill"></div>
          </div>
      </div>';
if(isset($title)&&!empty($title)){
  $result .='<h6>'.$title.'</h6>';
}
      
  $result .='</div>
            </div>';

    return $result;
}
add_shortcode( 'sb_corporate_progress', 'sb_corporate_progress_block' );

/*-------------------------------------------------------------------------
 END SB CORPORATE  BLOCK SHORTCODE
------------------------------------------------------------------------- */



/*-------------------------------------------------------------------------
  START SB CORPORATE TEXT PROGRESS BLOCK SHORTCODE
------------------------------------------------------------------------- */

function sb_corporate_text_progress_block($atts , $content = null){

  extract(shortcode_atts( array('title'=>'','des'=>'','bg_image'=>'','post_id'=>''), $atts ));

  $args = array(

  'post_type' => 'sb_progress',
  'posts_per_page' => -1,

  );

$get_all_location = get_posts($args);
// _log($get_all_location);
$i=1;


if(isset($get_all_location)&& !empty($get_all_location)){
  foreach ($get_all_location as $key => $value) {
    if($i==1){
// _log('mer');
    $all_post_meta = get_post_custom( $post_id);

  $result ='<div class="uou-demo-block tertiary">
              <div class="container">';
if(isset($title)&&!empty($title)){
  $result .='<h2 class="block-title left invert">'.$title.'</h2>';
}
 
if(isset($des)&&!empty($des)){ 
  $result .='<p class="block-secondary-title-m left">'.$des.'</p>';
}

  $result .='</div>
        <div class="clearfix">
          <div class="container">
            <div class="row">';

if(isset($all_post_meta['_sb_progress_bar_progress_shortcode'][0])&&!empty($all_post_meta['_sb_progress_bar_progress_shortcode'][0])){
  $result .=do_shortcode($all_post_meta['_sb_progress_bar_progress_shortcode'][0]);
}

  $result .='<div class="col-md-4">
                <div class="demo-img-custom">';
if(isset($bg_image)&&!empty($bg_image)){
  $result .='<img src="'.SB_IMAGE.$bg_image.'" alt="">';
}
                
  $result .='</div>
          </div>
        </div>
      </div> 
    </div> 
  </div>';

$i++;

    }
  }
}
  
    return $result;
}
add_shortcode( 'sb_corporate_text_progress', 'sb_corporate_text_progress_block' );

/*-------------------------------------------------------------------------
 END SB CORPORATE TEXT PROGRESS BLOCK SHORTCODE
------------------------------------------------------------------------- */



/*-------------------------------------------------------------------------
  START SB CORPORATE PRICING TABLE SHORTCODE
------------------------------------------------------------------------- */

function sb_corporate_pricing_block($atts , $content = null){

  extract(shortcode_atts( array('title'=>'','des'=>'','bg_image'=>'','post_id'=>''), $atts ));

  $args = array(

  'post_type' => 'sb_pricing',
  'posts_per_page' => -1,

  );

$get_all_location = get_posts($args);
// _log($get_all_location);
$i=1;


if(isset($get_all_location)&& !empty($get_all_location)){
  foreach ($get_all_location as $key => $value) {
    if($i==1){
// _log('mer');
    $all_post_meta = get_post_custom( $post_id);

  $result =' <div class="uou-demo-block zero-pb">';

if(isset($title)&&!empty($title)){
  $result .='<h2 class="block-title">'.$title.'</h2>';
}
 
if(isset($des)&&!empty($des)){ 
  $result .='<p class="block-secondary-title-m">'.$des.'</p>';
}

  $result .=' <div class="container">
                <div class="row">';

if(isset($all_post_meta['_sb_pricing_shortcode'][0])&&!empty($all_post_meta['_sb_pricing_shortcode'][0])){
  $result .=do_shortcode($all_post_meta['_sb_pricing_shortcode'][0]);
}
                
  $result .='</div>
          </div>
        </div>';

$i++;

    }
  }
}
  
    return $result;
}

add_shortcode( 'sb_corporate_pricing', 'sb_corporate_pricing_block' );


/*-------------------------------------------------------------------------
 END SB CORPORATE PRICING TABLE BLOCK SHORTCODE
------------------------------------------------------------------------- */


/*-------------------------------------------------------------------------
  START SB Title SHORTCODE
------------------------------------------------------------------------- */

function sb_title_block($atts , $content = null){

  extract(shortcode_atts( array('title'=>''), $atts ));

  $result ='<section class="demo-section">';

if(isset($title)&&!empty($title)){
  $result .='<h6 class="demo-section-title container">'.$title.'</h6>';
}
  
  $result .='</section>';

    return $result;
}

add_shortcode( 'sb_title_block_shortcode', 'sb_title_block' );


/*-------------------------------------------------------------------------
 END SB CORPORATE PRICING TABLE BLOCK SHORTCODE
------------------------------------------------------------------------- */


/*-------------------------------------------------------------------------
  START SB CREATIVE Mobile Feature SHORTCODE
------------------------------------------------------------------------- */

function sb_creative_mobile_block($atts , $content = null){

  extract(shortcode_atts( array('bg_img'=>'','mobile_img'=>''), $atts ));

if(isset($bg_img)&&!empty($bg_img)){
  $result ='<div class="uou-demo-block has-bg-image" data-bg-image="'.SB_IMAGE.$bg_img.'">';
}

  $result .='<div class="container">
      <div class="row">
        <div class="col-md-4 col-md-push-4 text-center">';

if(isset($mobile_img)&&!empty($mobile_img)){
  $result .='<img src="'.SB_IMAGE.$mobile_img.'" class="mobile-pic" alt="">';
}
  
  $result .='</div>';

  $args = array(

  'post_type' => 'feature',
  'posts_per_page' => -1,

  );

$get_all_location = get_posts($args);
// _log($get_all_location);
$i=1;
$n=3;

  $result .='<div class="col-md-4 col-md-pull-4 text-right">
          <ul class="list-icon-large inverse">';

if(isset($get_all_location)&& !empty($get_all_location)){
  foreach ($get_all_location as $key => $value) {
    if($i<=$n){
// _log('mer');
    $all_post_meta = get_post_custom( $value->ID);

  $result .='<li>';

if(isset($all_post_meta['_tons_of_feature_icon'][0])&&!empty($all_post_meta['_tons_of_feature_icon'][0])){
  $result .=$all_post_meta['_tons_of_feature_icon'][0];
}
  $result .='<h6>'.$value->post_title.'</h6>';
  $result .=$value->post_excerpt;
  $result .='</li>';

  $i++;

    }
  }
}

  $result .='</ul>
          </div>';
  $result .='<div class="col-md-4">
              <ul class="list-icon-large left">';
$i=1;
$j=0;
if(isset($get_all_location)&& !empty($get_all_location)){
  foreach ($get_all_location as $key => $value) {
    $j++;
    if($j>$n){
    if($i<=$n){
// _log('mer');
    $all_post_meta = get_post_custom( $value->ID);

  $result .='<li>';

if(isset($all_post_meta['_tons_of_feature_icon'][0])&&!empty($all_post_meta['_tons_of_feature_icon'][0])){
  $result .=$all_post_meta['_tons_of_feature_icon'][0];
}
  $result .='<h6>'.$value->post_title.'</h6>';
  $result .=$value->post_excerpt;
  $result .='</li>';

  $i++;

      }
    }
  }
}

  $result .='</ul>
          </div>';

  $result .='</div>
          </div>
         </div>';


    return $result;
}

add_shortcode( 'sb_mobile_block_shortcode', 'sb_creative_mobile_block' );


/*-------------------------------------------------------------------------
 END SB CREATIVE Mobile Feature BLOCK SHORTCODE
------------------------------------------------------------------------- */






/*-------------------------------------------------------------*******************************---------------------------------------------------------
                                SB Merin's Shortcodes portion end
---------------------------------------------------------------*******************************------------------------------------------------------- */


/***********************************************************************************
|                       START sb BLOCK SHOETCODES                           |                                              |
|                                                                                  |
***********************************************************************************/



/*-------------------------------------------------------------------------
  START UOU-BLOCK-5C SECTION SHORTCODE
------------------------------------------------------------------------- */


function sb_uou_block_5c_testimonial_section($atts , $content = null){
  

  extract(shortcode_atts( array('no_of_testimonial_show' => ''), $atts ));

  $testimonial_count = 0;

  $output = '<section class="demo-section">
              <div class="uou-block-5c">
                <div class="container">
                  <div class="flexslider">
                    <ul class="slides">';

  $args = array(

    'post_type' => 'testimonial',
    // 'posts_per_page' => -1,
    );


  $get_all_testimonial = get_posts($args);  
  // _log($get_all_testimonial);   

if(isset($get_all_testimonial)&& !empty($get_all_testimonial)):   
  foreach ($get_all_testimonial as $key => $value) {

    $all_post_meta = get_post_custom( $value->ID );

    $output .= '<li>
                  <blockquote>';
    // _log($output);

    $output .= $value->post_excerpt;
    $output .= '<footer><cite>'.$all_post_meta['_sb_testimonial_author_name'][0].'</cite>';
    $output .= $all_post_meta['_sb_testimonial_author_designation'][0];
    $output .= ', <a href="#">'.$all_post_meta['_sb_testimonial_author_company'][0].'</a>.
                  </footer>
                </blockquote>
              </li>';

    $testimonial_count++;  

    if(intval($testimonial_count) === intval($no_of_testimonial_show)) break;
    
  }
endif;

  
  $output .=   '</ul>
              </div>
            </div> 
          </div>
        </section>';

  return $output;


}



add_shortcode( 'sb_uou_block_5c_testimonial_section', 'sb_uou_block_5c_testimonial_section' );

/*-------------------------------------------------------------------------
  END UOU-BLOCK-5C SECTION SHORTCODE
------------------------------------------------------------------------- */





/*-------------------------------------------------------------------------
  START UOU-BLOCK-5D SECTION SHORTCODE
------------------------------------------------------------------------- */


function sb_uou_block_5d_section($atts , $content = null){
  

  extract(shortcode_atts( array('no_of_testimonial_show' => ''), $atts ));

  $testimonial_count = 0;

  $output = '<section class="demo-section">
              <div class="container">
                <div class="row">';

  $args = array(

    'post_type' => 'testimonial',
    'posts_per_page' => -1,

    );


  $get_all_testimonial = get_posts($args);  
$i=1;
if(isset($get_all_testimonial)&& !empty($get_all_testimonial)):   
  foreach ($get_all_testimonial as $key => $value) {



    $all_post_meta = get_post_custom( $value->ID );
    



if($i==1){
    $output .= '<div class="col-md-4">
                  <div class="uou-block-5d secondary">
                    <blockquote>
                      <div>';

    $i--;

    $output .= $value->post_excerpt;
    $output .= '</div>';
    $output .= '<footer>';

    if(isset($all_post_meta['_thumbnail_id'][0])&& !empty($all_post_meta['_thumbnail_id'][0])){    
    $image_id =  wp_get_attachment_image_src( $all_post_meta['_thumbnail_id'][0] );
    $output .='<img src="'.$image_id[0].'" alt="">';
    }
    $output .= '<cite class="h6">'.$all_post_meta['_sb_testimonial_author_name'][0].'</cite>';
    $output .= '<a href="#">'.$all_post_meta['_sb_testimonial_author_company'][0].'</a>
                  </footer>
                </blockquote>
              </div>
            </div>';
}

elseif($i==0){
    $output .= '<div class="col-md-4">
                  <div class="uou-block-5d">
                    <blockquote>
                      <div>';
    // _log('merin');
    $i++;

    $output .= $value->post_excerpt;
    $output .= '</div>';
    $output .= '<footer>';

    if(isset($all_post_meta['_thumbnail_id'][0])&& !empty($all_post_meta['_thumbnail_id'][0])){    
    $image_id =  wp_get_attachment_image_src( $all_post_meta['_thumbnail_id'][0] );
    $output .='<img src="'.$image_id[0].'" alt="">';
    } 

    $output .= '<cite class="h6">'.$all_post_meta['_sb_testimonial_author_name'][0].'</cite>';
    $output .= '<a href="#">'.$all_post_meta['_sb_testimonial_author_company'][0].'</a>
                  </footer>
                </blockquote>
              </div>
            </div>';
}


    $testimonial_count++;  

    if(intval($testimonial_count) === intval($no_of_testimonial_show)) break;
    
  }
endif;

  
  $output .= '</div> 
          </div>
        </section>';

  return $output;


}



add_shortcode( 'sb_uou_block_5d_testimonial_section', 'sb_uou_block_5d_section' );

/*-------------------------------------------------------------------------
  END UOU-BLOCK-5D SECTION SHORTCODE
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
 END RESTAURANT About The Company SHORTCODE
------------------------------------------------------------------------- */
/*-------------------------------------------------------------------------
  START sb BLOG POST UOU BLOCK 7D LEFT SHORTCODES
------------------------------------------------------------------------- */


function sb_blog_post_block_7d_left_section($atts , $content = null){
  

  extract(shortcode_atts( array('no_of_post_to_show' => ''), $atts ));

  $post_count = 0;

  $args = array(

    'post_type' => 'post',
    'posts_per_page' => -1,

    );

  $result ='<section class="demo-section">
              <h3 class="text-center">Recent Blog Posts</h3>
              <div class="container">
                <div class="row">
                  <div class="col-sm-6">
                    <ul class="uou-block-7d">';

  $get_all_post = get_posts($args);  
   // _log($get_all_gallery);
  // $i=1;

if(isset($get_all_post)&& !empty($get_all_post)):
 foreach ($get_all_post as $key => $value) {

    $all_post_meta = get_post_custom( $value->ID );

  $result .='<li>';

  $posted_time = human_time_diff( get_the_time('U',$value->ID), current_time('timestamp') );

  $result .='<span class="time-ago">'.$posted_time.' ago</span>';

  $result .='<h5><a href="'.get_permalink($value->ID).'">'.$value->post_title.'</a></h5>
          </li>';

    $post_count++;  
    if(intval($post_count) === intval($no_of_post_to_show)) break;
  // $result .='<br>';
  }
endif;

 $post_count = 0;

  $result .='</ul> 
        </div>';
      // <!-- end .uou-block-7d -->

  $result .='<div class="col-sm-6">
        <ul class="uou-block-7d">';

if(isset($get_all_post)&& !empty($get_all_post)):
 foreach ($get_all_post as $key => $value) {

    $all_post_meta = get_post_custom( $value->ID );

  $result .='<li>';

  $posted_time = human_time_diff( get_the_time('U',$value->ID), current_time('timestamp') );

  $result .='<span class="time-ago">'.$posted_time.' ago</span>';

  $result .='<h5><a href="'.get_permalink($value->ID).'">'.$value->post_title.'</a></h5>
              <p>'.$value->post_content.'</p></li>';

    $post_count++;  
    if(intval($post_count) === intval($no_of_post_to_show)) break;
  // $result .='<br>';
  }
endif;


  $result .= '</ul>
            </div>
          </div>
        </div>
      </section>';

  return $result;


}



add_shortcode( 'sb_blog_post_7d_left_shortcode', 'sb_blog_post_block_7d_left_section' );

/*-------------------------------------------------------------------------
  END sb BLOG POST UOU BLOCK 7D LEFT SECONDARY SHORTCODE
------------------------------------------------------------------------- */



/*-------------------------------------------------------------------------
  START sb BLOG POST UOU BLOCK 7E LEFT SHORTCODES
------------------------------------------------------------------------- */


function sb_blog_post_block_7e_left_section($atts , $content = null){
  

  extract(shortcode_atts( array('no_of_post_to_show' => ''), $atts ));

  $post_count = 0;

  $args = array(

    'post_type' => 'post',
    'posts_per_page' => -1,

    );

  $result ='<section class="demo-section">
              <h3 class="text-center">Recent Blog Posts</h3>
              <div class="container">';

  $get_all_post = get_posts($args);  
   // _log($get_all_gallery);
  // $i=1;

 $post_count = 0;

if(isset($get_all_post)&& !empty($get_all_post)):
 foreach ($get_all_post as $key => $value) {

    $all_post_meta = get_post_custom( $value->ID );

  $result .='<article class="uou-block-7e">
              <div class="meta">';

  $posted_time = human_time_diff( get_the_time('U',$value->ID), current_time('timestamp') );

  $category = get_the_category($value->ID);
  $comments = wp_count_comments( $value->ID );
    // _log($comments);

  $result .='<span class="time-ago">'.$posted_time.' ago</span>';

  $result .='<span class="category">Posted in: <a href="'.get_permalink($value->ID).'">'.$category[0]->name.'</a></span>';
  $result .='<a href="'.get_permalink($value->ID).'" class="comments">'.$comments->approved.' Comments</a>
            </div>';

  $result .='<h1><a href="'.get_permalink($value->ID).'">'.$value->post_title.'</a></h1>
              <p>'.$value->post_content.'</p>';

  $result .='<a href="'.get_permalink($value->ID).'" class="btn btn-primary">Read More</a>
            </article>'; 

    $post_count++;  
    if(intval($post_count) === intval($no_of_post_to_show)) break;
  // $result .='<br>';
  }
endif;


  $result .= '</div>
      </section>';
  return $result;
}
add_shortcode( 'sb_blog_post_7e_left_shortcode', 'sb_blog_post_block_7e_left_section' );

/*-------------------------------------------------------------------------
  END sb BLOG POST UOU BLOCK 7E LEFT SECONDARY SHORTCODE
------------------------------------------------------------------------- */




/*-------------------------------------------------------------------------
  START sb BLOG POST UOU BLOCK 7f LEFT SHORTCODES
------------------------------------------------------------------------- */


function sb_blog_post_block_7f_left_section($atts , $content = null){
  

  extract(shortcode_atts( array('no_of_post_to_show' => ''), $atts ));

  $post_count = 0;

  $args = array(

    'post_type' => 'post',
    'posts_per_page' => -1,

    );

  $result ='<section class="demo-section">
              <h3 class="text-center">Recent Blog Posts</h3>
              <div class="container">';

  $get_all_post = get_posts($args);  
   // _log($get_all_gallery);
  // $i=1;

 $post_count = 0;

if(isset($get_all_post)&& !empty($get_all_post)):
 foreach ($get_all_post as $key => $value) {

    $all_post_meta = get_post_custom( $value->ID );

  $result .='<article class="uou-block-7f">';

  if(isset($all_post_meta['_thumbnail_id'][0])&& !empty($all_post_meta['_thumbnail_id'][0])){

    // $image_id = wp_get_attachment_image_src($all_post_meta['_thumbnail_id'][0]); 
    // _log($image_id);
    $image_id = $all_post_meta['_thumbnail_id'][0];  
    $large_image = wp_get_attachment_url( $image_id ,'full');  
    $resize = sb_aq_resize( $large_image, 200, 200, true ); 

  $result .='<img src="'.$resize.'" alt="" class="thumb">';
  }

  
  $result .='<div class="meta">';

  $posted_time = human_time_diff( get_the_time('U',$value->ID), current_time('timestamp') );

  $category = get_the_category($value->ID);
  $comments = wp_count_comments( $value->ID );
    // _log($comments);

  $result .='<span class="time-ago">'.$posted_time.' ago</span>';

  $result .='<span class="category">Posted in: <a href="'.get_permalink($value->ID).'">'.$category[0]->name.'</a></span>';
  $result .='<a href="'.get_permalink($value->ID).'" class="comments">'.$comments->approved.' Comments</a>
            </div>';

  $result .='<h1><a href="'.get_permalink($value->ID).'">'.$value->post_title.'</a></h1>
              <p>'.$value->post_content.'</p>';

  $result .='<a href="'.get_permalink($value->ID).'" class="btn btn-primary">Read More</a>
            </article>'; 

    $post_count++;  
    if(intval($post_count) === intval($no_of_post_to_show)) break;
  // $result .='<br>';
  }
endif;


  $result .= '</div></section>';

  return $result;


}



add_shortcode( 'sb_blog_post_7f_left_shortcode', 'sb_blog_post_block_7f_left_section' );

/*-------------------------------------------------------------------------
  END sb BLOG POST UOU BLOCK 7F LEFT SECONDARY SHORTCODE
------------------------------------------------------------------------- */




/*-------------------------------------------------------------------------
  START sb BLOG POST UOU BLOCK 7G LEFT SHORTCODES
------------------------------------------------------------------------- */


function sb_blog_post_block_7g_left_section($atts , $content = null){
  

  extract(shortcode_atts( array('no_of_post_to_show' => '','badge_color' => '','badge_title' => ''), $atts ));

  $post_count = 0;

  $args = array(

    'post_type' => 'post',
    'posts_per_page' => -1,

    );

  $result ='<section class="demo-section">
             <h3 class="text-center">Recent Blog Posts</h3>
              <div class="container">
                <div class="row">';

  $get_all_post = get_posts($args);  
   // _log($get_all_gallery);
  // $i=1;

 $post_count = 0;

if(isset($get_all_post)&& !empty($get_all_post)):
 foreach ($get_all_post as $key => $value) {

    $all_post_meta = get_post_custom( $value->ID );

  $result .='<div class="col-sm-4">
              <article class="uou-block-7g" data-badge-color="'.$badge_color.'">';

  if(isset($all_post_meta['_thumbnail_id'][0])&& !empty($all_post_meta['_thumbnail_id'][0])){

    // $image_id = wp_get_attachment_image_src($all_post_meta['_thumbnail_id'][0]); 
    // _log($image_id);
    $image_id = $all_post_meta['_thumbnail_id'][0];  
    $large_image = wp_get_attachment_url( $image_id ,'full');  
    $resize = sb_aq_resize( $large_image, 1200, 715, true ); 

  $result .='<img class="image" src="'.$resize.'" alt="">';
  }

  $result .='<span class="badge">'.$badge_title.'</span>';
  $result .='<div class="content">';

  $posted_time = get_the_date($format,$value->ID);

  $result .='<span class="date">'.$posted_time.'</span>';

  $result .='<h1>'.$value->post_title.'</h1>
              <p>'.$value->post_content.'</p>';

  $result .='</div>
           </article>
          </div>';

    $post_count++;  
    if(intval($post_count) === intval($no_of_post_to_show)) break;
  // $result .='<br>';
  }
endif;
  $result .= '</div></div></section>';
  return $result;
}
add_shortcode( 'sb_blog_post_7g_left_shortcode', 'sb_blog_post_block_7g_left_section' );

/*-------------------------------------------------------------------------
  END sb BLOG POST UOU BLOCK 7G LEFT SECONDARY SHORTCODE
------------------------------------------------------------------------- */



/*-------------------------------------------------------------------------
  START sb BLOG POST UOU BLOCK 7h LEFT SHORTCODES
------------------------------------------------------------------------- */


function sb_blog_post_block_7h_left_section($atts , $content = null){
  

  extract(shortcode_atts( array('no_of_post_to_show' => ''), $atts ));

  $post_count = 0;

  $args = array(

    'post_type' => 'post',
    'posts_per_page' => -1,

    );

  $result ='<section class="demo-section">
            <h3 class="text-center">Recent Blog Posts</h3>
              <div class="container">
                <div class="uou-block-7h">
                  <div class="flexslider">
                    <ul class="slides">';

  $get_all_post = get_posts($args);  
   // _log($get_all_gallery);
  // $i=1;

 $post_count = 0;

if(isset($get_all_post)&& !empty($get_all_post)):
 foreach ($get_all_post as $key => $value) {

    $all_post_meta = get_post_custom( $value->ID );

  $result .='<li>';

  if(isset($all_post_meta['_thumbnail_id'][0])&& !empty($all_post_meta['_thumbnail_id'][0])){

    // $image_id = wp_get_attachment_image_src($all_post_meta['_thumbnail_id'][0]); 
    // _log($image_id);
    $image_id = $all_post_meta['_thumbnail_id'][0];  
    $large_image = wp_get_attachment_url( $image_id ,'full');  
    $resize = sb_aq_resize( $large_image, 1200, 715, true ); 

  $result .='<img src="'.$resize.'" alt="">';
  }

  $result .='<div class="caption">
              <div class="css-table">
                <div class="css-table-cell">';

  $posted_time = human_time_diff( get_the_time('U',$value->ID), current_time('timestamp') );

  $result .='<span class="time-ago">'.$posted_time.' ago</span>';

  $result .='<h3><a href="'.get_permalink($value->ID).'">'.$value->post_title.'</a></h3>';
  
  $result .='</div>
           </div>
          </div>
         </li>';

    $post_count++;  
    if(intval($post_count) === intval($no_of_post_to_show)) break;
  // $result .='<br>';
  }
endif;
  $result .= '</ul></div></div></div></section>';
  return $result;
}
add_shortcode( 'sb_blog_post_7h_left_shortcode', 'sb_blog_post_block_7h_left_section' );

/*-------------------------------------------------------------------------
  END sb BLOG POST UOU BLOCK 7h LEFT SECONDARY SHORTCODE
------------------------------------------------------------------------- */


/* ******************************************------------------------------------------------------------------------- *****************************************************
                                            Simple BUilder SHORTCODES by SHAAD SHORTCODES
*********************************************------------------------------------------------------------------------- ******************************************************/

/*-------------------------------------------------------------------------
  START SB Pages Banner SHORTCODE
------------------------------------------------------------------------- */
function sb_construction_page_banner($atts, $content = null) {
  extract(shortcode_atts(array('bg_img' => '',  'title' => ''), $atts));

$construction_page_banner = '<div class="breadecrumb"> 
                             <div class="uou-block-3c secondary  has-bg-image" data-bg-image="'.SB_IMAGE.$bg_img.'">
                              <div class="container">
                                <h1>'.$title.'</h1>';
$construction_page_banner .= '</div>
                             </div> 
                          </div>';

  return $construction_page_banner;
}
add_shortcode('sb_page_front_banner', 'sb_construction_page_banner');



  /*-------------------------------------------------------------------------
  END SB Pages Banner SHORTCODE
------------------------------------------------------------------------- */


/*-------------------------------------------------------------------------
  START SB PORTFOLIO SECTION SHORTCODE
------------------------------------------------------------------------- */

function SB_construction_our_recent_works($atts, $content = null) {

$simple_builder_portfolio = '<div class="uou-portfolio full-width">
                              <section id="portfolio" class="portfolio">
                                <div class="">
                              <div class="clearfix"></div>';
                                          $args = array(
                                              'orderby'           => 'name', 
                                              'order'             => 'ASC',
                                              'fields'            => 'all',       
                                          ); 

                                          if(taxonomy_exists('portfolio_tag')){
                                            $terms = get_terms('portfolio_tag', $args);
                                          }

                                          
$simple_builder_portfolio .= '<ul class="filters col-lg-12 col-md-12 col-sm-12 col-xs-12">';


      $simple_builder_portfolio .= '<li><a href="#" class="btn active" data-filter="">All Works</a></li>';
        if(isset($terms) && !empty($terms)){
          foreach($terms as $key => $value) { 
            $simple_builder_portfolio .='<li><a href="#" class="btn" data-filter=".'.$value->slug.'">'.$value->name.'</a></li>';
          } 
        }
        
  
$simple_builder_portfolio .= '</ul>';

$simple_builder_portfolio .= ' <div class="clearfix"></div>
                                  <div class="portfolio-filters-content">';
            if(isset($terms) && !empty($terms)){

              
              foreach($terms as $key => $value) { 

                $args = array(
                  'post_type' => 'portfolio',
                  'tax_query' => array(
                    array(
                      'taxonomy' => 'portfolio_tag',
                      'field'    => 'slug',
                      'terms'    => $value->slug,
                    ),
                  ),
                );

                $query = get_posts( $args );


                if(isset($query) && !empty($query)){
                  foreach ($query as $key => $posts) {
                    $simple_builder_portfolio .= '<article class="'.$value->slug.'">';


                    if ( has_post_thumbnail($posts->ID) ) {

                          $image_id =  get_post_thumbnail_id( $posts->ID );
                          $large_image = wp_get_attachment_url( $image_id ,'full');  
                          $resize = sb_aq_resize( $large_image, 640, 360, true );
                          
                        $simple_builder_portfolio .= '<a href="'.$resize.'" class="swipebox" title="'.$value->slug.'">';
                        $simple_builder_portfolio .= '<img src="'.$resize.'" alt="" class="work img-responsive">';
                        $simple_builder_portfolio .= '<span class="overlay">
                                                        <i class="fa fa-plus"></i>
                                                        <b class="title"><strong>Photo Session</strong>'.$value->slug.'</b>
                                                      </span>';
                        $simple_builder_portfolio .= '</a>';
                      }
                    $simple_builder_portfolio .= '</article>';
                  }
                }
    }
  }           
  $simple_builder_portfolio .= '</div>';
  $simple_builder_portfolio .= '
                        </div>
                      </section>
                    </div>';
return $simple_builder_portfolio;                                  
}
add_shortcode('SB_portfolio','SB_construction_our_recent_works');  

/*-------------------------------------------------------------------------
  END SB PORTFOLIO SECTION SHORTCODE
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
  START Construction Our Team SHORTCODE
------------------------------------------------------------------------- */

function simple_builder_author_shortcodes( $atts, $content = null ) {
  extract(shortcode_atts( array( 'no_of_partner_show' => '', 'title' => '' ), $atts));
  global $sb_option_data;
  $partners_count = 0;
  $construction_team_result = '<h6 class="demo-section-title container">'.$title.'</h6>';
                                
  $construction_team_result .= '<div class="container pb30">
                                  <div class="row">';

if( isset($sb_option_data['sb-our-partners']) && !empty($sb_option_data['sb-our-partners']) ) {
    foreach ($sb_option_data['sb-our-partners'] as $key => $value) {
      if($partners_count === intval($no_of_partner_show)) break;
          if( !empty($value['image']) && !empty($value['title']) && !empty($value['url']) && !empty($value['description']) ){
          $construction_team_result .= '<div class="col-sm-4"> <div class="uou-block-6a"><img src="'.$value['image'].'" alt="">';
          $construction_team_result .= '<h6> '.$value['title'].' <span>'.$value['url'].'</span></h6>';
          $construction_team_result .= '<p>'.$value['description'].'</p>';
          $construction_team_result .= '<ul class="social-icons">';
          // Social section
          if($sb_option_data['sb-social-profile']){
           
                if(isset($sb_option_data['sb-facebook-profile']) && !empty($sb_option_data['sb-facebook-profile']))  {
                    $construction_team_result .= '<li><a href="http://' .$sb_option_data['sb-facebook-profile'] .'"><i class="fa fa-facebook"></i></a></li>';
                  }

               if(isset($sb_option_data['sb-twitter-profile']) && !empty($sb_option_data['sb-twitter-profile']))  {
                $construction_team_result .= '<li><a  href="http://'. $sb_option_data['sb-twitter-profile'] .'"><i class="fa fa-twitter"></i></a></li>';
                }

               if(isset($sb_option_data['sb-google-profile']) && !empty($sb_option_data['sb-google-profile']))  {
                $construction_team_result .= '<li><a  href="http://' .$sb_option_data['sb-google-profile'].'"><i class="fa fa-google"></i></a></li>';
                }
               if(isset($sb_option_data['sb-linkedin-profile']) && !empty($sb_option_data['sb-linkedin-profile']))  {
                $construction_team_result .= '<li><a  href="http://' .$sb_option_data['sb-linkedin-profile'].'"><i class="fa fa-linkedin"></i></a></li>';
                }
              }

            $construction_team_result .= '</ul></div></div>';                              
        }
    $partners_count++;
    }
}
          //$construction_team_result .= '</div></div>';

  $construction_team_result .='</div></div>';
  return $construction_team_result;
}


add_shortcode('sb_our_team', 'simple_builder_author_shortcodes');


/*-------------------------------------------------------------------------
  END Construction Our Team SHORTCODE
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
  START Construction Our Team SHORTCODE (design 2)
------------------------------------------------------------------------- */

function simple_builder_author_shortcodes_two( $atts, $content = null ) {
  extract(shortcode_atts( array( 'no_of_partner_show' => '', 'title' => '' ), $atts));
  global $sb_option_data;
  $partners_count = 0;
  $construction_team_result = '<h6 class="demo-section-title container">'.$title.'</h6>';
                                
  $construction_team_result .= '<div class="container pb30">
                                  <div class="row">';

if( isset($sb_option_data['sb-our-partners']) && !empty($sb_option_data['sb-our-partners']) ) {
    foreach ($sb_option_data['sb-our-partners'] as $key => $value) {
      if($partners_count === intval($no_of_partner_show)) break;
          if( !empty($value['image']) && !empty($value['title']) && !empty($value['url']) && !empty($value['description']) ){
          $construction_team_result .= '<div class="col-sm-4"> <div class="uou-block-6a rounded"><img src="'.$value['image'].'" alt="">';
          $construction_team_result .= '<h6> '.$value['title'].' <span>'.$value['url'].'</span></h6>';
          $construction_team_result .= '<p>'.$value['description'].'</p>';
          $construction_team_result .= '<ul class="social-icons">';
          // Social section
          if($sb_option_data['sb-social-profile']){
           
                if(isset($sb_option_data['sb-facebook-profile']) && !empty($sb_option_data['sb-facebook-profile']))  {
                    $construction_team_result .= '<li><a href="http://' .$sb_option_data['sb-facebook-profile'] .'"><i class="fa fa-facebook"></i></a></li>';
                  }

               if(isset($sb_option_data['sb-twitter-profile']) && !empty($sb_option_data['sb-twitter-profile']))  {
                $construction_team_result .= '<li><a  href="http://'. $sb_option_data['sb-twitter-profile'] .'"><i class="fa fa-twitter"></i></a></li>';
                }

               if(isset($sb_option_data['sb-google-profile']) && !empty($sb_option_data['sb-google-profile']))  {
                $construction_team_result .= '<li><a  href="http://' .$sb_option_data['sb-google-profile'].'"><i class="fa fa-google"></i></a></li>';
                }
               if(isset($sb_option_data['sb-linkedin-profile']) && !empty($sb_option_data['sb-linkedin-profile']))  {
                $construction_team_result .= '<li><a  href="http://' .$sb_option_data['sb-linkedin-profile'].'"><i class="fa fa-linkedin"></i></a></li>';
                }
              }
                      $construction_team_result .= '</ul></div></div>';                               
        }
    $partners_count++;
    }
}
          //$construction_team_result .= '</div></div>';

  $construction_team_result .='</div></div>';
  return $construction_team_result;
}


add_shortcode('sb_our_team_two', 'simple_builder_author_shortcodes_two');

/*-------------------------------------------------------------------------
  END Construction Our Team SHORTCODE (design 2)
------------------------------------------------------------------------- */
/*-------------------------------------------------------------------------
  END Construction Our Team SHORTCODE (design 3)
------------------------------------------------------------------------- */
function simple_builder_author_shortcodes_three( $atts, $content = null ) {
  extract(shortcode_atts( array( 'no_of_partner_show' => '' ), $atts));
  global $sb_option_data;
  $partners_count = 0;
  // $construction_team_result = $title;
                                
  $construction_team_result = '  <div class="uou-demo-block tertiary">
                                    <div class="container">
                                      <div class="row">';

if( isset($sb_option_data['sb-our-partners']) && !empty($sb_option_data['sb-our-partners']) ) {
    foreach ($sb_option_data['sb-our-partners'] as $key => $value) {
      if($partners_count === intval($no_of_partner_show)) break;
          if( !empty($value['image']) && !empty($value['title']) && !empty($value['url']) && !empty($value['description']) ){
          $construction_team_result .= '<div class="col-sm-6">
                                            <div class="uou-block-6b secondary">
                                              <img src="'.$value['image'].'" alt="">';
          $construction_team_result .= '<ul class="social-icons">';
          // Social section
          if($sb_option_data['sb-social-profile']){
           
                if(isset($sb_option_data['sb-facebook-profile']) && !empty($sb_option_data['sb-facebook-profile']))  {
                    $construction_team_result .= '<li><a href="http://' .$sb_option_data['sb-facebook-profile'] .'"><i class="fa fa-facebook"></i></a></li>';
                  }

               if(isset($sb_option_data['sb-twitter-profile']) && !empty($sb_option_data['sb-twitter-profile']))  {
                $construction_team_result .= '<li><a  href="http://'. $sb_option_data['sb-twitter-profile'] .'"><i class="fa fa-twitter"></i></a></li>';
                }

               if(isset($sb_option_data['sb-google-profile']) && !empty($sb_option_data['sb-google-profile']))  {
                $construction_team_result .= '<li><a  href="http://' .$sb_option_data['sb-google-profile'].'"><i class="fa fa-google"></i></a></li>';
                }
               if(isset($sb_option_data['sb-linkedin-profile']) && !empty($sb_option_data['sb-linkedin-profile']))  {
                $construction_team_result .= '<li><a  href="http://' .$sb_option_data['sb-linkedin-profile'].'"><i class="fa fa-linkedin"></i></a></li>';
                }
              }
         $construction_team_result .= '</ul>';
          $construction_team_result .= '<div class="content">';
          $construction_team_result .= '<h6> '.$value['title'].'<span>Founder &amp;'.$value['url'].'</span></h6>';
          $construction_team_result .= '<p>'.$value['description'].'</p>';
         $construction_team_result .='</div></div></div>'; 

        }
    $partners_count++;
    }
}
          //$construction_team_result .= '</div></div>';

  $construction_team_result .='</div></div></div>';
  return $construction_team_result;
}


add_shortcode('sb_our_team_three', 'simple_builder_author_shortcodes_three');
/*-------------------------------------------------------------------------
  END Construction Our Team SHORTCODE (design 3)
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
  END Construction Our Team SHORTCODE (design 4)
------------------------------------------------------------------------- */
function simple_builder_author_shortcodes_four( $atts, $content = null ) {
  extract(shortcode_atts( array( 'no_of_partner_show' => '' ), $atts));
  global $sb_option_data;
  $partners_count = 0;
  // $construction_team_result = $title;
                                
  $construction_team_result = '<div class="uou-demo-block tertiary"> <div class="container">
                                  <div class="row">';

if( isset($sb_option_data['sb-our-partners']) && !empty($sb_option_data['sb-our-partners']) ) {
    foreach ($sb_option_data['sb-our-partners'] as $key => $value) {
      if($partners_count === intval($no_of_partner_show)) break;
          if( !empty($value['image']) && !empty($value['title']) && !empty($value['url']) && !empty($value['description']) ){
          $construction_team_result .= '<div class="col-sm-6"> 
                                            <div class="uou-block-6b">
                                              <img src="'.$value['image'].'" alt="">';
          $construction_team_result .= '<ul class="social-icons">';
          // Social section
          if($sb_option_data['sb-social-profile']){
           
                if(isset($sb_option_data['sb-facebook-profile']) && !empty($sb_option_data['sb-facebook-profile']))  {
                    $construction_team_result .= '<li><a href="http://' .$sb_option_data['sb-facebook-profile'] .'"><i class="fa fa-facebook"></i></a></li>';
                  }

               if(isset($sb_option_data['sb-twitter-profile']) && !empty($sb_option_data['sb-twitter-profile']))  {
                $construction_team_result .= '<li><a  href="http://'. $sb_option_data['sb-twitter-profile'] .'"><i class="fa fa-twitter"></i></a></li>';
                }

               if(isset($sb_option_data['sb-google-profile']) && !empty($sb_option_data['sb-google-profile']))  {
                $construction_team_result .= '<li><a  href="http://' .$sb_option_data['sb-google-profile'].'"><i class="fa fa-google"></i></a></li>';
                }
               if(isset($sb_option_data['sb-linkedin-profile']) && !empty($sb_option_data['sb-linkedin-profile']))  {
                $construction_team_result .= '<li><a  href="http://' .$sb_option_data['sb-linkedin-profile'].'"><i class="fa fa-linkedin"></i></a></li>';
                }
              }
          $construction_team_result .= '</ul>';
          $construction_team_result .= '<div class="content">';
          $construction_team_result .= '<h6> '.$value['title'].'<span>Founder &amp;'.$value['url'].'</span></h6>';
          $construction_team_result .= '<p>'.$value['description'].'</p>';
         $construction_team_result .='</div>
                                    </div> </div>';                               
        }
    $partners_count++;
    }
}
          //$construction_team_result .= '</div></div>';

  $construction_team_result .='</div></div></div>';
  return $construction_team_result;
}


add_shortcode('sb_our_team_four', 'simple_builder_author_shortcodes_four');
/*-------------------------------------------------------------------------
  END Construction Our Team SHORTCODE (design 3)
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
 START  Construction Testimonial Footer Banner  SHORTCODE
------------------------------------------------------------------------- */
function simple_builder_banner_section($atts , $content = null){

  extract(shortcode_atts( array('banner_des' => '','name' =>'' , 'title' => '', 'bg_image' => ''), $atts ));

   global $sb_option_data; 

if(isset($sb_option_data['sb-construction-testimonial-footer-banner-image']['url'])&&!empty($sb_option_data['sb-construction-testimonial-footer-banner-image']['url']))
   $bg_image = $sb_option_data['sb-construction-testimonial-footer-banner-image']['url'];
  
  $result = '<div class="uou-block-5a has-bg-image" data-bg-image= "'.$bg_image.'" data-bg-color="000" data-bg-opacity=".20">';

  $result.= '<div class="container">
                <blockquote>
                  <p>"'.$banner_des.'"</p>
                  <footer><cite>'.$name.'</cite></footer>
                </blockquote>
            </div>
          </div>';    
  return $result;
}

add_shortcode( 'sb_testimonial_banner', 'simple_builder_banner_section' );

/*-------------------------------------------------------------------------
  End RESTAURANT Testimonial Footer Banner  SHORTCODE
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
  START SB TESTIMONIAL SECTION SHORTCODE
------------------------------------------------------------------------- */


function simple_builder_testimonial_section($atts , $content = null){
  

  extract(shortcode_atts( array('no_of_testimonial_show' => ''), $atts ));

  $testimonial_count = 0;

  $output = '<div class="uou-demo-block">
              <div class="uou-block-5b">
                <div class="container">';

  $args = array(
    'post_type' => 'testimonial',
    'posts_per_page' => 3,
    'order' => 'ASC'
    );

  $args2 = array("first","second","third");
  $class = 0;

  $get_all_testimonial = get_posts($args);  
  // _log($get_all_testimonial);  
  if(isset($get_all_testimonial) && !empty($get_all_testimonial)) :
  foreach ($get_all_testimonial as $key => $value) {

    $all_post_meta = get_post_custom( $value->ID );

    if($class==0){
      $active_class='active';
    }
    else{
      $active_class='';
    }
    $output .= '<blockquote class="'.$args2[$class].' '.$active_class.'">';
    // _log($output);

    $output .=  $value->post_excerpt;
    if(isset($all_post_meta['_sb_testimonial_author_name'][0]) && !empty($all_post_meta['_sb_testimonial_author_name'][0])) {
    $output .= '<footer><cite><a href="#">'.$all_post_meta['_sb_testimonial_author_name'][0].'</a></cite></footer>
                </blockquote>';
    }
    $testimonial_count++;
    $class++;    
    if(intval($testimonial_count) === intval($no_of_testimonial_show)) break;    
  }
  endif;

  $output .= '<ul class="tabs">';
  $class = 0;

 foreach ($get_all_testimonial as $key => $value) {

  if($class==0){
      $active_class='active';
    }
    else{
      $active_class='';
    }

    $all_post_meta = get_post_custom( $value->ID );
    $image_id =  wp_get_attachment_image_src( $all_post_meta['_thumbnail_id'][0] );

    if(isset($image_id[0]) && !empty($image_id[0])) {
    $output .= '<li data-target="'.$args2[$class].'" class="'.$active_class.'"> 
                 <img src="'.$image_id[0].'" alt="">';
               }

    if(isset($all_post_meta['_sb_testimonial_author_name'][0]) && !empty($all_post_meta['_sb_testimonial_author_name'][0])) {
    $output .= ' <h6>'.$all_post_meta['_sb_testimonial_author_name'][0].'</h6>';
  }
  if(isset($all_post_meta['_sb_testimonial_author_company'][0]) && !empty($all_post_meta['_sb_testimonial_author_company'][0])) {
  $output .= '<a href="#">'.$all_post_meta['_sb_testimonial_author_company'][0].'</a>
                </li>'; }

    $testimonial_count++;   
    $class++; 
    if(intval($testimonial_count) === intval($no_of_testimonial_show)) break; 
  }
  $output .=   '</ul>
              </div>
            </div>
          </div>';
        
  return $output;

}

add_shortcode( 'sb_testimonial', 'simple_builder_testimonial_section' );


/*-------------------------------------------------------------------------
  END SB TESTIMONIAL SECTION SHORTCODE
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
  START UOU-BLOCK-5C SECTION SHORTCODE
------------------------------------------------------------------------- */


function sb_uou_block_5c_section($atts , $content = null){
  extract(shortcode_atts( array('no_of_testimonial_show' => ''), $atts ));
  $testimonial_count = 0;
  $output = ' <div class="uou-block-5c">
                <div class="container">
                  <div class="flexslider">
                    <ul class="slides">';
  $args = array(
    'post_type' => 'testimonial',
    'posts_per_page' => -1,
    );
  $get_all_testimonial = get_posts($args);  
  // _log($get_all_testimonial);   
if(isset($get_all_testimonial)&& !empty($get_all_testimonial)):   
  foreach ($get_all_testimonial as $key => $value) {
    $all_post_meta = get_post_custom( $value->ID );
    $output .= '<li>
                  <blockquote>';
    // _log($output)
    $output .= $value->post_excerpt;
    $output .= '<footer><cite>'.$all_post_meta['_sb_testimonial_author_name'][0].'</cite>';
    $output .= $all_post_meta['_sb_testimonial_author_designation'][0];
    $output .= 'Founder &amp; CEO, <a href="#">'.$all_post_meta['_sb_testimonial_author_company'][0].'</a>.
                  </footer>
                </blockquote>
              </li>';
    $testimonial_count++;  
    if(intval($testimonial_count) === intval($no_of_testimonial_show)) break;
  }
endif;
  $output .=   '</ul>
              </div>
            </div> 
          </div>';
  return $output;
}
add_shortcode( 'sb_uou_block_5c_testimonial_section', 'sb_uou_block_5c_section' );

/*-------------------------------------------------------------------------
  END UOU-BLOCK-5C SECTION SHORTCODE
------------------------------------------------------------------------- */
/*-------------------------------------------------------------------------
  START CONSTRUCTION TESTIMONIAL (SERVICE) SECTION SHORTCODE
------------------------------------------------------------------------- */

function sb_service_testimonial_shortcode($atts, $content = null) {
  extract(shortcode_atts(array( 'no_service_testimonial' => '', "title" => '', "sub_title" => ''),$atts));
 
  global $sb_option_data;
  $testimonial_count = 0;


  $sb_construction_service_testimonial = '
                                                    <div class = "uou-demo-block">
                                                      <h2 class="block-title"> '.$title.'</h2> 
                                                      <p class = "block-secondary-title-m"> '.$sub_title.' </p>
                                                    

                                                    <div class="container">
                                                      <div class="row">';

  if( isset($sb_option_data['sb-service-testimonials']) && !empty($sb_option_data['sb-service-testimonials']) ) {
    foreach ($sb_option_data['sb-service-testimonials'] as $key => $value) {
      if($testimonial_count === intval($no_service_testimonial)) break;
          if(!empty($value['image'])){
          $sb_construction_service_testimonial .= '<div class="col-sm-4"> 
                                                            <div class="uou-block-5d secondary">
                                                              <blockquote>';
          //$construction_team_result .= '<h6> '.$value['title'].' <span>'.$value['url'].'</span></h6>';
          $sb_construction_service_testimonial .= '<div> <p>'.$value['description'].'</p> </div>';
          $sb_construction_service_testimonial .= '<footer>
                                            <img src="'.$value['image'].'" alt="">
                                            <cite class="h6">'.$value['title'].'</cite>
                                            <a href=""> '.$value['url'].' </a>

                                          </footer>
                                      </blockquote>'; 
                                      // _log($value['url']);
         $sb_construction_service_testimonial .= '</div></div>';                       
        }
          $testimonial_count++;
  }
}
  $sb_construction_service_testimonial .= '</div></div></div>';                                               
  return $sb_construction_service_testimonial;                                                   
}
add_shortcode('sb_service_testimonial','sb_service_testimonial_shortcode');

/*-------------------------------------------------------------------------
  END CONSTRUCTION TESTIMONIAL (SERVICE) SECTION SHORTCODE
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
  START sb BLOG POST UOU BLOCK 7B SHORTCODES
------------------------------------------------------------------------- */

function sb_blog_post_block_7b_section($atts , $content = null){
  

  extract(shortcode_atts( array('no_of_post_to_show' => ''), $atts ));

  $post_count = 0;

  $args = array(

    'post_type' => 'post',
    'posts_per_page' => -1,

    );

  $result ='<section class="demo-section">';

  $get_all_post = get_posts($args);  
   // _log($get_all_gallery);
  $i=1;

if(isset($get_all_post)&& !empty($get_all_post)):
 foreach ($get_all_post as $key => $value) {

    $all_post_meta = get_post_custom( $value->ID );


if($i==1){
  $result .='<div class="container"> <article class="uou-block-7b">
              <div class="css-table">';
 
if(isset($all_post_meta['_thumbnail_id'][0])&& !empty($all_post_meta['_thumbnail_id'][0])){

    // $image_id = wp_get_attachment_image_src($all_post_meta['_thumbnail_id'][0]); 
    // _log($image_id);
    $image_id = $all_post_meta['_thumbnail_id'][0];  
    $large_image = wp_get_attachment_url( $image_id ,'full');  
    $resize = sb_aq_resize( $large_image, 585, 330, true ); 

  $result .='<div class="css-table-cell image has-bg-image" data-bg-image="'.$resize.'">
        <img class="hidden-image" src="'.$resize.'" alt="">
      </div>';
  }

  $posted_time = human_time_diff( get_the_time('U',$value->ID), current_time('timestamp') );

  $result .='<div class="css-table-cell content">
                <span class="time-ago">'.$posted_time.' ago</span>';

  $result .='<h1>'.$value->post_title.'</h1><p>'.$value->post_content.'</p>';

  $result .='<a href="'.get_permalink($value->ID).'" class="btn btn-primary">Read More</a>
      </div>
    </div>
  </article> </div> <br>'; 
  // <!-- end .uou-block-7b -->
  $i--;
}

elseif($i==0){
   $result .='<div class="container"> <article class="uou-block-7b">
              <div class="css-table">';
  
  $posted_time = human_time_diff(get_the_time('U',$value->ID), current_time('timestamp') );

  $result .='<div class="css-table-cell content">
                <span class="time-ago">'.$posted_time.' ago</span>';

  $result .='<h1>'.$value->post_title.'</h1><p>'.$value->post_content.'</p>';

  $result .='<a href="'.get_permalink($value->ID).'" class="btn btn-primary">Read More</a>';
   
  $result .='</div>';

if(isset($all_post_meta['_thumbnail_id'][0])&& !empty($all_post_meta['_thumbnail_id'][0])){
    $image_id = $all_post_meta['_thumbnail_id'][0];  
    $large_image = wp_get_attachment_url( $image_id ,'full');  
    $resize = sb_aq_resize( $large_image, 585, 330, true ); 

  $result .='<div class="css-table-cell image has-bg-image" data-bg-image="'.$resize.'">
        <img class="hidden-image" src="'.$resize.'" alt="">
      </div>';
  }

  $result .='</div>
  </article> </div>'; 
  // <!-- end .uou-block-7b -->
  $i++;

}

    // _log($i);
    $post_count++;  
    if(intval($post_count) === intval($no_of_post_to_show)) break;
  // $result .='<br>';
  }
endif;
$result .= '</section>';
  return $result;
}
add_shortcode( 'sb_blog_post_7b_shortcode', 'sb_blog_post_block_7b_section' );



/*-------------------------------------------------------------------------
  END sb BLOG POST UOU BLOCK 7B SHORTCODE
------------------------------------------------------------------------- */
/*-------------------------------------------------------------------------
  START sb BLOG POST UOU BLOCK 7B SECONDARY SHORTCODES
------------------------------------------------------------------------- */
function simple_builder_blog_post_block_7b_secondary_section($atts , $content = null){
  

  extract(shortcode_atts( array('no_of_post_to_show' => ''), $atts ));

  $post_count = 0;

  $args = array(

    'post_type' => 'post',
    'posts_per_page' => -1,

    );
  $result ='<section class="demo-section">';
  $get_all_post = get_posts($args);  
   // _log($get_all_gallery);
  $i=1;
if(isset($get_all_post)&& !empty($get_all_post)):
 foreach ($get_all_post as $key => $value) {
    $all_post_meta = get_post_custom( $value->ID );
if($i==1){
  $result .='<div class="container">
              <article class="uou-block-7b secondary">
              <div class="css-table">';
if(isset($all_post_meta['_thumbnail_id'][0])&& !empty($all_post_meta['_thumbnail_id'][0])){
    // $image_id = wp_get_attachment_image_src($all_post_meta['_thumbnail_id'][0]); 
    // _log($image_id);
    $image_id = $all_post_meta['_thumbnail_id'][0];  
    $large_image = wp_get_attachment_url( $image_id ,'full');  
    $resize = sb_aq_resize( $large_image, 585, 330, true ); 
  $result .='<div class="css-table-cell image has-bg-image" data-bg-image="'.$resize.'">
        <img class="hidden-image" src="'.$resize.'" alt="">
      </div>';
  }
  $posted_time = human_time_diff( get_the_time('U',$value->ID), current_time('timestamp') );
  $result .='<div class="css-table-cell content">
                <span class="time-ago">'.$posted_time.' ago</span>';
  $result .='<h1>'.$value->post_title.'</h1><p>'.$value->post_content.'</p>';
  $result .='<a href="'.get_permalink($value->ID).'" class="btn btn-primary">Read More</a>
      </div>
    </div>
  </article>
  </div> <br>'; 
  // <!-- end .uou-block-7b -->
  $i--;
}
elseif($i==0){
   $result .='<div class="container"><article class="uou-block-7b secondary">
              <div class="css-table">';
  $posted_time = human_time_diff(get_the_time('U',$value->ID), current_time('timestamp') );
  $result .='<div class="css-table-cell content">
                <span class="time-ago">'.$posted_time.' ago</span>';
  $result .='<h1>'.$value->post_title.'</h1><p>'.$value->post_content.'</p>';
  $result .='<a href="'.get_permalink($value->ID).'" class="btn btn-primary">Read More</a>';
  $result .='</div>';
if(isset($all_post_meta['_thumbnail_id'][0])&& !empty($all_post_meta['_thumbnail_id'][0])){
    $image_id = $all_post_meta['_thumbnail_id'][0];  
    $large_image = wp_get_attachment_url( $image_id ,'full');  
    $resize = sb_aq_resize( $large_image, 585, 330, true ); 
  $result .='<div class="css-table-cell image has-bg-image" data-bg-image="'.$resize.'">
        <img class="hidden-image" src="'.$resize.'" alt="">
      </div>';
  }
  $result .='</div>
  </article>
  </div>'; 
  // <!-- end .uou-block-7b -->
  $i++;
}
    // _log($i);
    $post_count++;  
    if(intval($post_count) === intval($no_of_post_to_show)) break;
  // $result .='<br>';
  }
endif;
  $result .= '</section>';
  return $result;
}
add_shortcode( 'sb_blog_post_7b_secondary_shortcode', 'simple_builder_blog_post_block_7b_secondary_section' );

/*-------------------------------------------------------------------------
  END sb BLOG POST UOU BLOCK 7B SECONDARY SHORTCODE
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
 Start sb Construction Recent Blog-Post  SHORTCODE
------------------------------------------------------------------------- */

function simple_builder_recent_blog_post( $params ) {
extract( shortcode_atts( array (
    'excerpt' => 290,
    'readmore' => 'yes',
    'readmoretext' => '...Read more'
), $params ) );

  $args = array(

    'post_type' => 'post',
    'posts_per_page' => 3,

    );

$latest_posts = get_posts($args);
$result = '
          <div class="uou-demo-block">
            <div class="container">
              <div class="row">
                <h2 class = "block-title">Blog</h2>
                  <p class = "block-secondary-title-m"> Check my latest writing </p>
              </div>
            </div>
            <div class="container">
                <div class="row">';


$count = count($latest_posts);
foreach ($latest_posts as $key => $latest_post) {
  $post_link = get_permalink( $latest_post->ID );
  $date = mysql2date(get_option('date_format'), $latest_post->post_date);

  $all_post_meta = get_post_custom( $latest_post->ID );

  if(isset($all_post_meta['_thumbnail_id'][0]) && !empty($all_post_meta['_thumbnail_id'][0])) {
  $image_id = $all_post_meta['_thumbnail_id'][0];  
  $large_image = wp_get_attachment_url( $image_id ,'full');  
  $resize = sb_aq_resize( $large_image, 270, 190, true );
  }

  $result .= '<div class="col-sm-4"> 
               <article class="uou-block-7c">';
  // POST THUMBNAIL
  if (get_the_post_thumbnail( $latest_post->ID, 'image' )) {
      $result .= '<img class="image" src="'.$resize.'" alt="">';
      $result .= '<span class="date">'.$date. '</span>';
  }
  // POST BODY
  $result .= '<h1>' . $latest_post->post_title . '</h1>';
  if ( $latest_post->post_excerpt ) {
      $result .= '<p>' . $latest_post->post_excerpt . '</p>';
  }
  else {
      $limit = $excerpt;
      $my_text = substr($latest_post->post_content, 0, $limit);
      $pos = strrpos($my_text, " ");
      $my_post_text = substr($my_text, 0, ($pos ? $pos : -1)) . "...";
      $read = "";
  if($readmore == 'yes'){
    $read = '<a href="' . $post_link. '">'.$readmoretext.'</a>';
  }
      $result .= '<p>' . strip_tags($my_post_text) . $read . '</p>';
  }


  $result .= '</article>
            </div>';
}
$result .= '</div>
          </div>
        </div>
      ';


return $result;
}
add_shortcode( "sb_recent_posts", "simple_builder_recent_blog_post" );

/*-------------------------------------------------------------------------
 Start sb Construction Recent Blog-Post  SHORTCODE
------------------------------------------------------------------------- */
function simple_builder_blog_post_section($atts , $content = null){
  

  extract(shortcode_atts( array('no_of_post_to_show' => ''), $atts ));

  $post_count = 0;

  $args = array(

    'post_type' => 'post',
    'posts_per_page' => 3,

    );

  $result ='<section class="demo-section">
              <div class="container">';

  $get_all_post = get_posts($args);  
   // _log($get_all_gallery);
  // $i=1;

 $post_count = 0;

if(isset($get_all_post)&& !empty($get_all_post)):
 foreach ($get_all_post as $key => $value) {

    $all_post_meta = get_post_custom( $value->ID );

  $result .='<article class="uou-block-7f">';

  if(isset($all_post_meta['_thumbnail_id'][0])&& !empty($all_post_meta['_thumbnail_id'][0])){

    // $image_id = wp_get_attachment_image_src($all_post_meta['_thumbnail_id'][0]); 
    // _log($image_id);
    $image_id = $all_post_meta['_thumbnail_id'][0];  
    $large_image = wp_get_attachment_url( $image_id ,'full');  
    $resize = sb_aq_resize( $large_image, 200, 200, true ); 

  $result .='<img src="'.$resize.'" alt="" class="thumb">';
  }


  
  $result .='<div class="meta">';

  $posted_time = human_time_diff( get_the_time('U',$value->ID), current_time('timestamp') );

  $category = get_the_category($value->ID);
  $comments = wp_count_comments( $value->ID );
    // _log($comments);

  $result .='<span class="time-ago">'.$posted_time.' ago</span>';

  $result .='<span class="category">Posted in: <a href="'.get_permalink($value->ID).'">'.$category[0]->name.'</a></span>';
  $result .='<a href="'.get_permalink($value->ID).'" class="comments">'.$comments->approved.' Comments</a>
            </div>';

  $result .='<h1><a href="'.get_permalink($value->ID).'">'.$value->post_title.'</a></h1>
              <p>'.$value->post_content.'</p>';

  $result .='<a href="'.get_permalink($value->ID).'" class="btn btn-primary">Read More</a>
            </article>'; 
    $post_count++;  
    if(intval($post_count) === intval($no_of_post_to_show)) break;
  // $result .='<br>';
  }
endif;
  $result .= '</div></section>';
  return $result;
}
add_shortcode( 'sb_blog_post_shortcode', 'simple_builder_blog_post_section' );


/*-------------------------------------------------------------------------
 Start sb Construction Recent Blog-Post  SHORTCODE without image
------------------------------------------------------------------------- */

function simple_builder_blog_post_withou_image_section($atts , $content = null){
  

  extract(shortcode_atts( array('no_of_post_to_show' => ''), $atts ));

  $post_count = 0;

  $args = array(

    'post_type' => 'post',
    'posts_per_page' => 3,

    );

  $result ='<section class="demo-section">
              <div class="container">';

  $get_all_post = get_posts($args);  
   // _log($get_all_gallery);
  // $i=1;

 $post_count = 0;

if(isset($get_all_post)&& !empty($get_all_post)):
 foreach ($get_all_post as $key => $value) {

    $all_post_meta = get_post_custom( $value->ID );

  $result .='<article class="uou-block-7e">';
  
  $result .='<div class="meta">';

  $posted_time = human_time_diff( get_the_time('U',$value->ID), current_time('timestamp') );

  $category = get_the_category($value->ID);
  $comments = wp_count_comments( $value->ID );
    // _log($comments);

  $result .='<span class="time-ago">'.$posted_time.' ago</span>';

  $result .='<span class="category">Posted in: <a href="'.get_permalink($value->ID).'">'.$category[0]->name.'</a></span>';
  $result .='<a href="'.get_permalink($value->ID).'" class="comments">'.$comments->approved.' Comments</a>
            </div>';

  $result .='<h1><a href="'.get_permalink($value->ID).'">'.$value->post_title.'</a></h1>
              <p>'.$value->post_content.'</p>';

  $result .='<a href="'.get_permalink($value->ID).'" class="btn btn-primary">Read More</a>
            </article>'; 
    $post_count++;  
    if(intval($post_count) === intval($no_of_post_to_show)) break;
  // $result .='<br>';
  }
endif;
  $result .= '</div></section>';
  return $result;
}
add_shortcode( 'sb_blog_post_7e_shortcode', 'simple_builder_blog_post_withou_image_section' );

// ********************************************* 
 //             Message Button Shortcodes
// ********************************************* 

function sb_message_button_shortcodes($atts , $content = null){
  extract(shortcode_atts( array('message' => '', 'button_des1' => '', 'button_des2' => '' ,'link1' => '', 'link2' => ''), $atts ));
  $sb_result = '<div class="uou-cta secondary">
                  <div class="container">
                    <div class="row">
                      <div class="col-sm-7">';
  $sb_result .= '<p>'.$message.'</p></div>';
  $sb_result .= '<div class="col-sm-5 text-right">
                  <a class="btn btn-transparent" href="'.$link1.'">'.$button_des1.'</a>
                  <a class="btn btn-primary" href="'.$link2.'">'.$button_des2.'</a>
                </div>';
  $sb_result .= '</div> </div> </div>';

  return $sb_result;
}
add_shortcode( 'sb_message_button', 'sb_message_button_shortcodes' );



/*-------------------------------------------------------------------------
 START Construction Header Slider  SHORTCODE
------------------------------------------------------------------------- */

function sb_home_image(){
   global $sb_option_data;  
   //_log($sb_option_data);
 $sb_result = '<div class="uou-demo-block zero-pb">
                        <h1 class="block-title">Work</h1>
                          <p class="block-secondary-title"> Check out some of our work </p>
                            <div class="uou-portfolio full-width">
                              <section id="portfolio" class="portfolio">
                                <div class="">
                                  <div class="clearfix"></div>
                                  <div class="portfolio-filters-content">'; 

  if(isset($sb_option_data['sb-construction-header-slider']) && !empty($sb_option_data['sb-construction-header-slider'])){
    foreach ($sb_option_data['sb-construction-header-slider'] as $key => $value) {
      if(!empty($value['image']) && !empty($value['title']) && !empty($value['description']) ){
          $resize = sb_aq_resize($value['image'], 640, 360, true);
          $sb_result .='<article class="development design">';
          $sb_result .='<a href="'.$resize.'" class="swipebox">';
          $sb_result .='<img src="'.$resize.'" alt="" class="work img-responsive">';

          $sb_result .= ' <span class="overlay"><i class="fa fa-plus"></i><b class="title"><strong>'.$value['title'].'</strong>'.$value['description'].'</b>';
          // $sb_result .= '<a class="btn btn-warning" href="' . get_permalink() . '">Find Out More</a>';
          $sb_result .='</span>';

          $sb_result .= '</a></article>';
        }
      }
    }
  $sb_result .= '</div></div></section></div></div>';
  return $sb_result;
}
add_shortcode( 'sb_home_image_shortcode', 'sb_home_image' );


/*-------------------------------------------------------------------------
 END Construction Header Slider  SHORTCODE
------------------------------------------------------------------------- */


// ********************************************* ********************************************* ********************************************* ********************************************* 
 //                                     HOME PAGE CORPORATE
// ********************************************* ********************************************* ********************************************* ********************************************* 

function sb_message_button_shortcodes_white($atts , $content = null){
  extract(shortcode_atts( array('message' => '', 'link1' => '', 'link2' => '', 'button_des1' => '', 'button_des2' => ''), $atts ));
  $sb_result = '<div class = "pt40 pb40">
                <div class="uou-cta tratiary">
                  <div class="container">
                    <div class="row">
                      <div class="col-sm-7">';
  $sb_result .= '<p>'.$message.'</p></div>';

  $sb_result .= '<div class="col-sm-5 text-right">
                  <a class="btn btn-transparent-primary" href="'.$link1.'">'.$button_des1.'</a>
                  <a class="btn btn-secondary" href="'.$link2.'">'.$button_des2.'</a>
                </div>';
  $sb_result .= '</div> </div> </div> </div>';

  return $sb_result;
}
add_shortcode( 'sb_white_message_button', 'sb_message_button_shortcodes_white' );


/*-------------------------------------------------------------------------
  START Construction Tons of Feature SHORTCODE
------------------------------------------------------------------------- */
function sb_message_button_shortcodes_white_border($atts , $content = null){
  extract(shortcode_atts( array('message' => '', 'link1' => '', 'link2' => '', 'button_des1' => '', 'button_des2' => ''), $atts ));
  $sb_result = '<div class = "pt40 pb40">
                  <div class="container">
                    <div class="uou-cta default">
                      <div class="row">
                        <div class="col-sm-7">';
  $sb_result .= '<p>'.$message.'</p></div>';

  $sb_result .= '<div class="col-sm-5 text-right">
                  <a class="btn btn-transparent-primary" href="'.$link1.'">'.$button_des1.'</a>
                  <a class="btn btn-secondary" href="'.$link2.'">'.$button_des2.'</a>
                </div>';
  $sb_result .= '</div> </div> </div> </div>';

  return $sb_result;
}
add_shortcode( 'sb_white_message_button_border', 'sb_message_button_shortcodes_white_border' );

/*-------------------------------------------------------------------------
  START Construction Tons of Feature SHORTCODE
------------------------------------------------------------------------- */

// ********************************************* ********************************************* ********************************************* ********************************************* 
 //                                     HOME PAGE Copy Write
// ********************************************* ********************************************* ********************************************* ********************************************* 

/*-------------------------------------------------------------------------
  START Construction Tons of Feature SHORTCODE
------------------------------------------------------------------------- */
function sb_message_button_shortcodes_copywrite_page($atts , $content = null){
  extract(shortcode_atts( array('message' => '', 'link1' => '', 'link2' => '', 'button_des1' => '', 'button_des2' => ''), $atts ));
  $sb_result = '<div class="uou-cta primary">
                  <div class="container">
                    <div class="row">
                      <div class="col-sm-7">';
  $sb_result .= '<p>'.$message.'</p></div>';

  $sb_result .= '<div class="col-sm-5 text-right">
                  <a class="btn btn-transparent" href="'.$link1.'">'.$button_des1.'</a>
                  <a class="btn btn-secondary" href="'.$link2.'">'.$button_des2.'</a>
                </div>';
  $sb_result .= '</div> </div> </div>';

  return $sb_result;
}
add_shortcode( 'sb_message_button_copywrite', 'sb_message_button_shortcodes_copywrite_page' );

/*-------------------------------------------------------------------------
  START Construction Tons of Feature SHORTCODE
------------------------------------------------------------------------- */
/*-------------------------------------------------------------------------
  START UOU-BLOCK-5C SECTION SHORTCODE
------------------------------------------------------------------------- */

function simple_builder_copywriter_page_testimonial($atts , $content = null){
  extract(shortcode_atts( array('no_of_testimonial_show' => '', 'bg_img' => ''), $atts ));
  $testimonial_count = 0;
  $output = '<div class="uou-demo-block has-bg-image" data-bg-image="'.SB_IMAGE.$bg_img.'">
              <div class="uou-block-5c pb40">
                <div class="container">
                  <div class="flexslider">
                    <ul class="slides">';
  $args = array(
    'post_type' => 'testimonial',
    'posts_per_page' => -1,
    );
  $get_all_testimonial = get_posts($args);  
  // _log($get_all_testimonial);   
if(isset($get_all_testimonial)&& !empty($get_all_testimonial)):   
  foreach ($get_all_testimonial as $key => $value) {
    $all_post_meta = get_post_custom( $value->ID );
    $output .= '<li>
                  <blockquote>';
    // _log($output);
    $output .= $value->post_excerpt;
    $output .= '<footer><cite>'.$all_post_meta['_sb_testimonial_author_name'][0].'</cite>';
    $output .= $all_post_meta['_sb_testimonial_author_designation'][0];
    $output .= ', <a href="#">'.$all_post_meta['_sb_testimonial_author_company'][0].'</a>.
                  </footer>
                </blockquote>
              </li>';
    $testimonial_count++;  
    if(intval($testimonial_count) === intval($no_of_testimonial_show)) break;
  }
endif;
  $output .=   '</ul>
              </div>
            </div> 
          </div>
        </div>';
  return $output;
}
add_shortcode( 'sb_copywriter_testimonial_section', 'simple_builder_copywriter_page_testimonial' );

/*-------------------------------------------------------------------------
  END UOU-BLOCK-5C SECTION SHORTCODE
------------------------------------------------------------------------- */

function simple_builder_copywriter_page_twitter_testimonial($atts , $content = null){
  extract(shortcode_atts( array('no_of_testimonial_show' => '', 'bg_img' => ''), $atts ));
  $testimonial_count = 0;
  $output = '<div class="uou-block-5a uou-twitter-content has-bg-image" data-bg-image="'.SB_IMAGE.$bg_img.'" data-bg-color="000" data-bg-opacity=".20">
                <div class="container">
                  <blockquote>
                    <div class="flexslider default-slider">
                      <ul class="slides">';

  $args = array(

    'post_type' => 'testimonial',
    'posts_per_page' => -1,

    );


  $get_all_testimonial = get_posts($args);  
  // _log($get_all_testimonial);   

if(isset($get_all_testimonial)&& !empty($get_all_testimonial)):   
  foreach ($get_all_testimonial as $key => $value) {

    $all_post_meta = get_post_custom( $value->ID );

    $output .= '<li class="">';
    // _log($output);

    $output .= $value->post_excerpt;
    $output .= '<a href=""> '.$all_post_meta['_sb_testimonial_author_company'][0].'  </a> 
                  <div class="twitt-details"> 
                    <p> '.$all_post_meta['_sb_testimonial_author_name'][0].'</p>';
    $output .= $all_post_meta['_sb_testimonial_author_designation'][0];
    $output .= '<span>'. date('Y-m-d') .'</span>
              </div>
            </li>';
    $testimonial_count++;  
    if(intval($testimonial_count) === intval($no_of_testimonial_show)) break;
  }
endif;
  $output .=   '</ul>
              </div>
            </blockquote>
          </div> 
        </div>';
  return $output;
}
add_shortcode( 'sb_copywriter_testimonial_section_twitter', 'simple_builder_copywriter_page_twitter_testimonial' );
 
// ************************** ************************** ************************** ************************** **************************

function simplebuilder_copywriter_counter_shortcode($atts , $content = null){

  extract(shortcode_atts( array('no_of_info_show' => '', 'bg_img' => ''), $atts ));

  $testimonial_count = 0;

  $output = '<div class="uou-demo-block has-bg-image" data-bg-image="'.SB_IMAGE.$bg_img.'">
                <div class="container">
                  <div class="row">';

$args = array(
    'post_type' => 'company',
    'post_status' => 'publish',
    'posts_per_page' => -1,
);

  $get_all_testimonial = get_posts($args);  
  // _log($get_all_testimonial);   

if(isset($get_all_testimonial)&& !empty($get_all_testimonial)):   
  foreach ($get_all_testimonial as $key => $value) {

    $all_post_meta = get_post_custom( $value->ID );

    $output .= '<div class="col-md-3">                              
                  <div class="uou-icon-counter">';
    // _log($output);

    $output .= $all_post_meta['_company_info_feature_icon'][0];
    $output .= '<h4>' . $all_post_meta['_company_info_feature_number'][0] . '</h4>';
    $output .= '<p>'.$all_post_meta['_company_info_feature_title'][0] . '</p>';
    $output .= '</div> 
              </div>';
    $testimonial_count++;  
    if(intval($testimonial_count) === intval($no_of_info_show)) break;
  }
endif;
  $output .='</div>
          </div> 
        </div>';
  return $output;
}
add_shortcode( 'sb_copywriter_counter_shortcode', 'simplebuilder_copywriter_counter_shortcode' );

// ************************************ ************************************ ************************************ ************************************
function sb_tons_of_feature($atts , $content = null){

  extract(shortcode_atts( array('no_of_info_show' => ''), $atts ));

  $testimonial_count = 0;

  $output = '<div class="uou-demo-block">
                <h1 class="block-title">HeY!</h1>
                    <p class="block-secondary-title">
                      We are Simple Builder, your new business partner
                    </p>
                <div class="container">
                  <div class="row">';

  $args = array(
      'post_type' => 'feature',
      'post_status' => 'publish',
      'posts_per_page' => -1,
      'excerpt' => 150,
      'readmore' => 'yes',
      'readmoretext' => 'Read more'
  );

  $get_all_testimonial = get_posts($args);  
  // _log($get_all_testimonial);   

if(isset($get_all_testimonial)&& !empty($get_all_testimonial)):   
  foreach ($get_all_testimonial as $key => $value) {

    $all_post_meta = get_post_custom( $value->ID );

    $output .= '<div class="col-sm-3">
                  <div class="uou-block-8d">';

    $output .= $all_post_meta['_tons_of_feature_icon'][0];
    $output .= '<h5>' . $value->post_title . '</h5>';
    $output .=  $value->post_excerpt;
    $output .= '</div> 
              </div>';
    $testimonial_count++;  
    if(intval($testimonial_count) === intval($no_of_info_show)) break;
  }
endif;
  $output .='</div>
          </div> 
        </div>';
  return $output;
}
add_shortcode( 'sb_tof_shortcode', 'sb_tons_of_feature' );

// ************************************ ************************************ ************************************ ************************************

function sb_tons_of_feature_corporate($atts , $content = null){

  extract(shortcode_atts( array('no_of_info_show' => ''), $atts ));

  $testimonial_count = 0;

  $output = '<div class="uou-demo-block">
                  <h2 class="block-title">What We Do</h2>
                  <p class="block-secondary-title-m">
                    Check our main Activities
                  </p>

                  <div class="uou-service-square">
                    <div class="container">
                      <div class="row">';

  $args = array(
      'post_type' => 'feature',
      'post_status' => 'publish',
      'posts_per_page' => -1,
      'excerpt' => 150,
      'readmore' => 'yes',
      'readmoretext' => 'Read more'
  );

  $get_all_testimonial = get_posts($args);  
  // _log($get_all_testimonial);   

if(isset($get_all_testimonial)&& !empty($get_all_testimonial)):   
  foreach ($get_all_testimonial as $key => $value) {

    $all_post_meta = get_post_custom( $value->ID );

    $output .= '<div class="col-sm-3">
                  <div class="uou-block-service-new">';

    $output .= $all_post_meta['_tons_of_feature_icon'][0];
    $output .= '<h6>' . $value->post_title . '</h6>';
    $output .= '<p>'. $value->post_excerpt . '</p>';
    $output .= '</div> 
              </div>';
    $testimonial_count++;  
    if(intval($testimonial_count) === intval($no_of_info_show)) break;
  }
endif;
  $output .='</div>
          </div>
        </div> 
      </div>';
  return $output;
}
add_shortcode( 'sb_tof_corporate_shortcode', 'sb_tons_of_feature_corporate' );
