<?php

/*--------------------------------------------------------------------------
| 																			|																			|
|		 [START MERIN'S Medico Visual Composer Shortcode] 			|
|																			|																			|
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
 START Visual Composer SB Slider One  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'slider_one_with_visual' );

function slider_one_with_visual() {
   vc_map( array(
      "name" => __( "SB Slider One", "sb" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_slider_one_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "SB Slider Shortcodes", "sb"), // in which tab it will appeared? there are several tabs: content, social etc.
       // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
       // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
      "params" => array(
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Slider Post Id", "sb" ),
            "param_name" => "post_id",
            "value" => __( "309", "sb" ),
            "description" => __( "Enter Your Slider Post Id.", "sb" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer SB Slider One  SHORTCODE
------------------------------------------------------------------------- */


/*-------------------------------------------------------------------------
 START Visual Composer SB Slider Two  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'slider_two_with_visual' );

function slider_two_with_visual() {
   vc_map( array(
      "name" => __( "SB Slider Two", "sb" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_slider_two_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "SB Slider Shortcodes", "sb"), // in which tab it will appeared? there are several tabs: content, social etc.
       // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
       // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
      "params" => array(
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Slider Post Id", "sb" ),
            "param_name" => "post_id",
            "value" => __( "309", "sb" ),
            "description" => __( "Enter Your Slider Post Id.", "sb" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer SB Slider Two  SHORTCODE
------------------------------------------------------------------------- */


/*-------------------------------------------------------------------------
 START Visual Composer SB Slider Three  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'slider_three_with_visual' );

function slider_three_with_visual() {
   vc_map( array(
      "name" => __( "SB Slider Three", "sb" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_slider_three_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "SB Slider Shortcodes", "sb"), // in which tab it will appeared? there are several tabs: content, social etc.
       // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
       // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
      "params" => array(
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Slider Post Id", "sb" ),
            "param_name" => "post_id",
            "value" => __( "311", "sb" ),
            "description" => __( "Enter Your Slider Post Id.", "sb" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer SB Slider Three  SHORTCODE
------------------------------------------------------------------------- */


/*-------------------------------------------------------------------------
 START Visual Composer SB Slider Four  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'slider_four_with_visual' );

function slider_four_with_visual() {
   vc_map( array(
      "name" => __( "SB Slider Four", "sb" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_slider_four_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "SB Slider Shortcodes", "sb"), // in which tab it will appeared? there are several tabs: content, social etc.
       // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
       // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
      "params" => array(
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Slider Post Id", "sb" ),
            "param_name" => "post_id",
            "value" => __( "312", "sb" ),
            "description" => __( "Enter Your Slider Post Id.", "sb" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer SB Slider Four  SHORTCODE
------------------------------------------------------------------------- */   


/*-------------------------------------------------------------------------
 START Visual Composer SB Slider Five  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'slider_five_with_visual' );

function slider_five_with_visual() {
   vc_map( array(
      "name" => __( "SB Slider Five", "sb" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_slider_five_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "SB Slider Shortcodes", "sb"), // in which tab it will appeared? there are several tabs: content, social etc.
       // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
       // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
      "params" => array(
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Slider Post Id", "sb" ),
            "param_name" => "post_id",
            "value" => __( "313", "sb" ),
            "description" => __( "Enter Your Slider Post Id.", "sb" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer SB Slider Five  SHORTCODE
------------------------------------------------------------------------- */   


/*-------------------------------------------------------------------------
 START Visual Composer SB Slider Six  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'slider_six_with_visual' );

function slider_six_with_visual() {
   vc_map( array(
      "name" => __( "SB Slider Six", "sb" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_slider_six_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "SB Slider Shortcodes", "sb"), // in which tab it will appeared? there are several tabs: content, social etc.
       // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
       // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
      "params" => array(
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Slider Post Id", "sb" ),
            "param_name" => "post_id",
            "value" => __( "314", "sb" ),
            "description" => __( "Enter Your Slider Post Id.", "sb" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer SB Slider six  SHORTCODE
------------------------------------------------------------------------- */   



/*-------------------------------------------------------------------------
 START Visual Composer SB Slider Seven  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'slider_seven_with_visual' );

function slider_seven_with_visual() {
   vc_map( array(
      "name" => __( "SB Slider Seven", "sb" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_slider_seven_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "SB Slider Shortcodes", "sb"), // in which tab it will appeared? there are several tabs: content, social etc.
       // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
       // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
      "params" => array(
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Slider Post Id", "sb" ),
            "param_name" => "post_id",
            "value" => __( "315", "sb" ),
            "description" => __( "Enter Your Slider Post Id.", "sb" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer SB Slider Seven  SHORTCODE
------------------------------------------------------------------------- */  


/*-------------------------------------------------------------------------
 START Visual Composer SB Slider Eight  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'slider_eight_with_visual' );

function slider_eight_with_visual() {
   vc_map( array(
      "name" => __( "SB Slider Eight", "sb" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_slider_eight_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "SB Slider Shortcodes", "sb"), // in which tab it will appeared? there are several tabs: content, social etc.
       // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
       // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
      "params" => array(
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Slider Post Id", "sb" ),
            "param_name" => "post_id",
            "value" => __( "316", "sb" ),
            "description" => __( "Enter Your Slider Post Id.", "sb" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer SB Slider Eight  SHORTCODE
------------------------------------------------------------------------- */  


/*-------------------------------------------------------------------------
 START Visual Composer SB Slider Nine  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'slider_nine_with_visual' );

function slider_nine_with_visual() {
   vc_map( array(
      "name" => __( "SB Slider Nine", "sb" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_slider_nine_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "SB Slider Shortcodes", "sb"), // in which tab it will appeared? there are several tabs: content, social etc.
       // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
       // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
      "params" => array(
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Slider Post Id", "sb" ),
            "param_name" => "post_id",
            "value" => __( "317", "sb" ),
            "description" => __( "Enter Your Slider Post Id.", "sb" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer SB Slider Nine  SHORTCODE
------------------------------------------------------------------------- */  


/*-------------------------------------------------------------------------
 START Visual Composer SB Slider ten  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'slider_ten_with_visual' );

function slider_ten_with_visual() {
   vc_map( array(
      "name" => __( "SB Slider Ten", "sb" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_slider_ten_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "SB Slider Shortcodes", "sb"), // in which tab it will appeared? there are several tabs: content, social etc.
       // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
       // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
      "params" => array(
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Slider Post Id", "sb" ),
            "param_name" => "post_id",
            "value" => __( "318", "sb" ),
            "description" => __( "Enter Your Slider Post Id.", "sb" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer SB Slider ten  SHORTCODE
------------------------------------------------------------------------- */ 


/*-------------------------------------------------------------------------
 START Visual Composer SB Slider Eleven  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'slider_eleven_with_visual' );

function slider_eleven_with_visual() {
   vc_map( array(
      "name" => __( "SB Slider Eleven", "sb" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_slider_eleven_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "SB Slider Shortcodes", "sb"), // in which tab it will appeared? there are several tabs: content, social etc.
       // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
       // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
      "params" => array(
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Slider Post Id", "sb" ),
            "param_name" => "post_id",
            "value" => __( "319", "sb" ),
            "description" => __( "Enter Your Slider Post Id.", "sb" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer SB Slider Eleven  SHORTCODE
------------------------------------------------------------------------- */  


/*-------------------------------------------------------------------------
 START Visual Composer SB Slider Twelve SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'slider_twelve_with_visual' );

function slider_twelve_with_visual() {
   vc_map( array(
      "name" => __( "SB Slider Twelve", "sb" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_slider_twelve_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "SB Slider Shortcodes", "sb"), // in which tab it will appeared? there are several tabs: content, social etc.
       // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
       // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
      "params" => array(
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Slider Post Id", "sb" ),
            "param_name" => "post_id",
            "value" => __( "320", "sb" ),
            "description" => __( "Enter Your Slider Post Id.", "sb" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer SB Slider Twelve  SHORTCODE
------------------------------------------------------------------------- */  



/*-------------------------------------------------------------------------
 START Visual Composer Corporate Contact  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'corporate_contact_with_visual' );

function corporate_contact_with_visual() {
   vc_map( array(
      "name" => __( "SB Corporate Contact With Map", "sb" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_corporate_contact_block_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "SB Shortcodes", "sb"), // in which tab it will appeared? there are several tabs: content, social etc.
       // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
       // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
      "params" => array(
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Contact Title", "sb" ),
            "param_name" => "title",
            "value" => __( "Contact", "sb" ),
            "description" => __( "Enter Your Contact Title.", "sb" )
         ),

         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Background Image", "sb" ),
            "param_name" => "bg_img",
            "value" => __( "corprat-bg-2.png", "sb" ),
            "description" => __( "Enter The name of your background image from asset img folder.", "sb" )
         ),

         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Contact Post Id", "sb" ),
            "param_name" => "post_id",
            "value" => __( "290", "sb" ),
            "description" => __( "Enter Your Contact Post Id.", "sb" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer Corporate Contact  SHORTCODE
------------------------------------------------------------------------- */    



/*-------------------------------------------------------------------------
 START Visual Composer Copywrite Contact  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'copywrite_contact_with_visual' );

function copywrite_contact_with_visual() {
   vc_map( array(
      "name" => __( "SB CopyWriter Contact With Map", "sb" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_copywriter_contact_block_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "SB Shortcodes", "sb"), // in which tab it will appeared? there are several tabs: content, social etc.
       // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
       // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
      "params" => array(
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Contact Title", "sb" ),
            "param_name" => "title",
            "value" => __( "Contact", "sb" ),
            "description" => __( "Enter Your Contact Title.", "sb" )
         ),

         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Contact Post Id", "sb" ),
            "param_name" => "post_id",
            "value" => __( "290", "sb" ),
            "description" => __( "Enter Your Contact Post Id.", "sb" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer Copywrite Contact  SHORTCODE
------------------------------------------------------------------------- */  



/*-------------------------------------------------------------------------
 START Visual Composer Creative Contact  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'creative_contact_with_visual' );

function creative_contact_with_visual() {
   vc_map( array(
      "name" => __( "SB Creative Contact With Map", "sb" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_creative_contact_block_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "SB Shortcodes", "sb"), // in which tab it will appeared? there are several tabs: content, social etc.
       // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
       // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
      "params" => array(
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Contact Title", "sb" ),
            "param_name" => "title",
            "value" => __( "Contact", "sb" ),
            "description" => __( "Enter Your Contact Title.", "sb" )
         ),

         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Background Image", "sb" ),
            "param_name" => "bg_img",
            "value" => __( "contact-bg.jpg", "sb" ),
            "description" => __( "Enter The name of your background image from asset img folder.", "sb" )
         ),

         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Contact Post Id", "sb" ),
            "param_name" => "post_id",
            "value" => __( "290", "sb" ),
            "description" => __( "Enter Your Contact Post Id.", "sb" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer Creative Contact  SHORTCODE
------------------------------------------------------------------------- */  


/*-------------------------------------------------------------------------
 START Visual Composer Creative Progress Bar  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'creative_progress_with_visual' );

function creative_progress_with_visual() {
   vc_map( array(
      "name" => __( "SB Creative Prrogress Bar", "sb" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_creative_text_progress ", // name of the shortcode. 
      "class" => "",
      "category" => __( "SB Shortcodes", "sb"), // in which tab it will appeared? there are several tabs: content, social etc.
       // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
       // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
      "params" => array(

         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Contact Post Id", "sb" ),
            "param_name" => "post_id",
            "value" => __( "322", "sb" ),
            "description" => __( "Enter Your Contact Post Id.", "sb" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer Creative Progress Bar   SHORTCODE
------------------------------------------------------------------------- */     


/*-------------------------------------------------------------------------
 START Visual Composer Corporate Progress Bar  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'corporate_progress_with_visual' );

function corporate_progress_with_visual() {
   vc_map( array(
      "name" => __( "SB Corporate Prrogress Bar", "sb" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_corporate_text_progress  ", // name of the shortcode. 
      "class" => "",
      "category" => __( "SB Shortcodes", "sb"), // in which tab it will appeared? there are several tabs: content, social etc.
       // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
       // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
      "params" => array(

        array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Title", "sb" ),
            "param_name" => "title",
            "value" => __( "Let the numbers speak", "sb" ),
            "description" => __( "Enter Your Progress Title.", "sb" )
         ),

        array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Description", "sb" ),
            "param_name" => "des",
            "value" => __( "We don’t want you to think that we just say empty words", "sb" ),
            "description" => __( "Enter Your Progress Description.", "sb" )
         ),

        array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Background Image", "sb" ),
            "param_name" => "bg_image",
            "value" => __( "corprat-bg-1.png", "sb" ),
            "description" => __( "Enter Your Background Image.", "sb" )
         ),


         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Contact Post Id", "sb" ),
            "param_name" => "post_id",
            "value" => __( "321", "sb" ),
            "description" => __( "Enter Your Contact Post Id.", "sb" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer Corporate Progress Bar   SHORTCODE
------------------------------------------------------------------------- */     



/*-------------------------------------------------------------------------
 START Visual Composer SB WELCOME  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'sb_welcome_with_visual' );

function sb_welcome_with_visual() {
   vc_map( array(
      "name" => __( "SB Welcome Block", "sb" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_welcome_block_shortcode   ", // name of the shortcode. 
      "class" => "",
      "category" => __( "SB Shortcodes", "sb"), // in which tab it will appeared? there are several tabs: content, social etc.
       // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
       // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
      "params" => array(

        array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Primary Title", "sb" ),
            "param_name" => "primary_title",
            "value" => __( "Welcome", "sb" ),
            "description" => __( "Enter Your Welcome block primary Title.", "sb" )
         ),

        array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Sub Title", "sb" ),
            "param_name" => "sub_title",
            "value" => __( "am Bob Franklin and I will write for you", "sb" ),
            "description" => __( "Enter Your Welcome block Sub Title.", "sb" )
         ),

        array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Description", "sb" ),
            "param_name" => "welcome_des",
            "value" => __( "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Proin nibh augue, suscipit a, scelerisque sed, lacinia in, mi. Cras vel lorem. Etiam pellentesque aliquet tellus. Phasellus pharetra nulla ac diam.", "sb" ),
            "description" => __( "Enter Your Description.", "sb" )
         ),

        array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Background Image", "sb" ),
            "param_name" => "bg_img",
            "value" => __( "", "sb" ),
            "description" => __( "Enter Your Background Image.", "sb" )
         ),

        array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Signeture Image", "sb" ),
            "param_name" => "sign_img",
            "value" => __( "sign.png", "sb" ),
            "description" => __( "Enter Your Signeture Image name from img folder.", "sb" )
         ),


         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Button Name", "sb" ),
            "param_name" => "btn_name",
            "value" => __( "Continue", "sb" ),
            "description" => __( "Enter The Button Name.", "sb" )
         ),

         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Button Link", "sb" ),
            "param_name" => "btn_link",
            "value" => __( "www.google.com", "sb" ),
            "description" => __( "Enter The Button Link.", "sb" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer SB WELCOME   SHORTCODE
------------------------------------------------------------------------- */     


/*-------------------------------------------------------------------------
 START Visual Composer SB Pricing  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'sb_pricing_with_visual' );

function sb_pricing_with_visual() {
   vc_map( array(
      "name" => __( "SB Pricing", "sb" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_corporate_pricing    ", // name of the shortcode. 
      "class" => "",
      "category" => __( "SB Shortcodes", "sb"), // in which tab it will appeared? there are several tabs: content, social etc.
       // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
       // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
      "params" => array(

        array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Title", "sb" ),
            "param_name" => "title",
            "value" => __( "Our Pricing", "sb" ),
            "description" => __( "Enter Your Pricing Title.", "sb" )
         ),

        array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Description", "sb" ),
            "param_name" => "des",
            "value" => __( "Choose your plan", "sb" ),
            "description" => __( "Enter Your Description.", "sb" )
         ),

        array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Contact Post Id", "sb" ),
            "param_name" => "post_id",
            "value" => __( "323", "sb" ),
            "description" => __( "Enter Your Contact Post Id.", "sb" )
         ),
      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer SB Pricing   SHORTCODE
------------------------------------------------------------------------- */     


/*-------------------------------------------------------------------------
 START Visual Composer SB Title  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'sb_title_with_visual' );

function sb_title_with_visual() {
   vc_map( array(
      "name" => __( "SB Title", "sb" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_title_block_shortcode    ", // name of the shortcode. 
      "class" => "",
      "category" => __( "SB Shortcodes", "sb"), // in which tab it will appeared? there are several tabs: content, social etc.
       // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
       // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
      "params" => array(

        array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Title", "sb" ),
            "param_name" => "title",
            "value" => __( "Slider", "sb" ),
            "description" => __( "Enter Your Title.", "sb" )
         ),
        
      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer SB Title SHORTCODE
------------------------------------------------------------------------- */ 


/*-------------------------------------------------------------------------
 START Visual Composer Creative Mobile Block  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'creative_mobile_with_visual' );

function creative_mobile_with_visual() {
   vc_map( array(
      "name" => __( "SB Creative Mobile Block", "sb" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_mobile_block_shortcode ", // name of the shortcode. 
      "class" => "",
      "category" => __( "SB Shortcodes", "sb"), // in which tab it will appeared? there are several tabs: content, social etc.
       // 'admin_enqueue_js' => array(get_template_directory_uri().'/vc_extend/bartag.js'),
       // 'admin_enqueue_css' => array(get_template_directory_uri().'/vc_extend/bartag.css'),
      "params" => array(

         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Background Image", "sb" ),
            "param_name" => "bg_img",
            "value" => __( "demo-bg.png", "sb" ),
            "description" => __( "Enter Your background image name from img folder.", "sb" )
         ),

         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Logo Mobile Image", "sb" ),
            "param_name" => "mobile_img",
            "value" => __( "mobile-img.png", "sb" ),
            "description" => __( "Enter Your Logo image form img folder.", "sb" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer Creative Mobile Block SHORTCODE
------------------------------------------------------------------------- */     

    



/*--------------------------------------------------------------------------
| 																			|																			|
|		 [END MERIN'S Medico Visual Composer Shortcode] 			|
|																			|																			|
------------------------------------------------------------------------- */


/* ------------------------------------------------------------------------------------------------------------------------------------------
                                                      Medico
-------------------------------------------------------------------------------------------------------------------------------------------- */
/*-------------------------------------------------------------------------
 START Visual Composer CONSTRUCTION PAge Banner  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'sb_page_banner_with_visual' );

function sb_page_banner_with_visual() {
   vc_map( array(
      "name" => __( "Medico Page Top Banner", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_page_front_banner", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Page Front Banner Title to show", "simplebuilder" ),
            "param_name" => "title",
            "value" => __( "", "simplebuilder" ),
            "description" => __( "Page Front Banner  Title to show.", "simplebuilder" )
         ),
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Page Front Banner Background Image to show", "simplebuilder" ),
            "param_name" => "bg_img",
            "value" => __( "", "simplebuilder" ),
            "description" => __( "Page Front Banner Background Image to show.", "simplebuilder" )
         ),
      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer CONSTRUCTION Page Banner  SHORTCODE
------------------------------------------------------------------------- */


/*-------------------------------------------------------------------------
 START Visual Composer CONSTRUCTION Our Recent Work  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'sb_portfolio_visual' );

function sb_portfolio_visual() {
   vc_map( array(
      "name" => __( "Medico Portfolio", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "SB_portfolio", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(
      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer CONSTRUCTION Our Recent Work  SHORTCODE
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
 Start Visual Composer Construction Our Team SHORTCODE
------------------------------------------------------------------------- */

add_action( 'vc_before_init', 'construction_our_team_visual' );

function construction_our_team_visual() {
   vc_map( array(
      "name" => __( "Medico Team Shortcode", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_our_team", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Team member to show", "simplebuilder" ),
            "param_name" => "no_of_partner_show",
            "value" => __( "", "chameleon" ),
            "description" => __( "Number of core team member.", "simplebuilder" )
         ),
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Core Team Banner title to show", "simplebuilder" ),
            "param_name" => "title",
            "value" => __( "", "chameleon" ),
            "description" => __( "Core Team Banner title.", "simplebuilder" )
         ),
      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer Construction Our Team SHORTCODE
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
 Start Visual Composer Construction Our Team SHORTCODE
------------------------------------------------------------------------- */

add_action( 'vc_before_init', 'construction_our_team_design_two_visual' );

function construction_our_team_design_two_visual() {
   vc_map( array(
      "name" => __( "Medico Team Shortcode (Design two)", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_our_team_two", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Team member to show", "simplebuilder" ),
            "param_name" => "no_of_partner_show",
            "value" => __( "", "chameleon" ),
            "description" => __( "Number of core team member.", "simplebuilder" )
         ),
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Core Team Banner title to show", "simplebuilder" ),
            "param_name" => "title",
            "value" => __( "", "chameleon" ),
            "description" => __( "Core Team Banner title.", "simplebuilder" )
         ),
      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer Construction Our Team SHORTCODE
------------------------------------------------------------------------- */
/*-------------------------------------------------------------------------
 Start Visual Composer Construction Our Team SHORTCODE 3
------------------------------------------------------------------------- */

add_action( 'vc_before_init', 'construction_our_team_design_three_visual' );

function construction_our_team_design_three_visual() {
   vc_map( array(
      "name" => __( "Medico Team Shortcode (Design three)", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_our_team_three", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Team member to show", "simplebuilder" ),
            "param_name" => "no_of_partner_show",
            "value" => __( "", "chameleon" ),
            "description" => __( "Number of core team member.", "simplebuilder" )
         ),
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Core Team Banner title to show", "simplebuilder" ),
            "param_name" => "title",
            "value" => __( "", "chameleon" ),
            "description" => __( "Core Team Banner title.", "simplebuilder" )
         ),
      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer Construction Our Team SHORTCODE 3
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
 Start Visual Composer Construction Our Team SHORTCODE 3
------------------------------------------------------------------------- */

add_action( 'vc_before_init', 'construction_our_team_design_four_visual' );

function construction_our_team_design_four_visual() {
   vc_map( array(
      "name" => __( "Medico Team Shortcode (Design four)", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_our_team_four", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Team member to show", "simplebuilder" ),
            "param_name" => "no_of_partner_show",
            "value" => __( "", "chameleon" ),
            "description" => __( "Number of core team member.", "simplebuilder" )
         ),
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Core Team Banner title to show", "simplebuilder" ),
            "param_name" => "title",
            "value" => __( "", "chameleon" ),
            "description" => __( "Core Team Banner title.", "simplebuilder" )
         ),
      )
   ) );
}

/*-------------------------------------------------------------------------
 End Visual Composer Construction Our Team SHORTCODE 3
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
 Start Visual Composer Construction Testimonial Footer Banner  SHORTCODE
------------------------------------------------------------------------- */

add_action( 'vc_before_init', 'simple_builder_footer_banner_visual' );

function simple_builder_footer_banner_visual() {
   vc_map( array(
      "name" => __( "Medico Footer Banner Shortcode", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_testimonial_banner", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Banner Description to show", "simplebuilder" ),
            "param_name" => "banner_des",
            "value" => __( "", "simplebuilder" ),
            "description" => __( "Banner Description.", "simplebuilder" )
         ),
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Testimonial Footer Banner name & compnay to show", "simplebuilder" ),
            "param_name" => "name",
            "value" => __( "", "simplebuilder" ),
            "description" => __( "Testimonial Footer Banner name.", "simplebuilder" )
         ),
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Testimonial Footer Banner name & compnay to show", "simplebuilder" ),
            "param_name" => "title",
            "value" => __( "", "simplebuilder" ),
            "description" => __( "Testimonial Footer Banner title.", "simplebuilder" )
         ),
      )
   ) );
}

/*-------------------------------------------------------------------------
 End Visual Composer Construction Testimonial Footer Banner  SHORTCODE
------------------------------------------------------------------------- */
/*-------------------------------------------------------------------------
 START Visual Composer CONSTRUCTION Blockquotes Testimonial  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'simple_builder_with_visual' );

function simple_builder_with_visual() {
   vc_map( array(
      "name" => __( "Medico Testimonial (Blockquotes)", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_testimonial", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "active",
            "heading" => __( "Testimonial to show", "simplebuilder" ),
            "param_name" => "no_of_testimonial_show",
            "value" => __( "3", "simplebuilder" ),
            "description" => __( "No of Testimonial to show.", "simplebuilder" )
         ),

      )
   ) );
}

/*-------------------------------------------------------------------------
 End Visual Composer CONSTRUCTION Blockquotes Testimonial  SHORTCODE
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
 START Visual Composer UOU-BLOCK-5C SECTION SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'sb_uou_block_5c_section_with_visual' );

function sb_uou_block_5c_section_with_visual() {
   vc_map( array(
      "name" => __( "Medico UOU-BLOCK-5C Section", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_uou_block_5c_testimonial_section", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(

          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "How Many Testimonial You Want To Show", "simplebuilder" ),
            "param_name" => "no_of_testimonial_show",
            "value" => __( "3", "simplebuilder" ),
            "description" => __( "Give a number.", "simplebuilder" )
         ),

      )
   ) );
}
/*-------------------------------------------------------------------------
 End Visual Composer UOU-BLOCK-5C SECTION SHORTCODE
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
 START Visual Composer CONSTRUCTION TESTIMONIAL (SERVICE) SECTION SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'simple_builder_service_testimonial_with_visual' );

function simple_builder_service_testimonial_with_visual() {
   vc_map( array(
      "name" => __( "Medico Service Testimonial", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_service_testimonial", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Service Testimonial to show", "simplebuilder" ),
            "param_name" => "no_service_testimonial",
            "value" => __( "", "simplebuilder" ),
            "description" => __( "No of Service Testimonial to show.", "simplebuilder" )
         ),
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "active",
            "heading" => __( "Service Testimonial Title to show", "simplebuilder" ),
            "param_name" => "title",
            "value" => __( "", "simplebuilder" ),
            "description" => __( "No of Service Testimonial to show.", "simplebuilder" )
         ),
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "active",
            "heading" => __( "Service Testimonial Title to show", "simplebuilder" ),
            "param_name" => "sub_title",
            "value" => __( "", "simplebuilder" ),
            "description" => __( "No of Service Testimonial to show.", "simplebuilder" )
         ),
      )
   ) );
}

/*-------------------------------------------------------------------------
 End Visual Composer CONSTRUCTION TESTIMONIAL (SERVICE) SECTION SHORTCODE
------------------------------------------------------------------------- */
/*-------------------------------------------------------------------------
 START Visual Composer UOU BLOCK 7A RIGHT SLIDER SECTION SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'uou_block_7a_right_slider_section_with_visual' );

function uou_block_7a_right_slider_section_with_visual() {
   vc_map( array(
      "name" => __( "SB UOU-BLOCK-7A RIGHT Slider Section", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "chameleone_uou_block_7a_right_slider", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(

          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Give the name of the icon image", "simplebuilder" ),
            "param_name" => "badge_img",
            "value" => __( "about-company.png", "simplebuilder" ),
            "description" => __( "Give a name.", "simplebuilder" )
         ),

           array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Give a link for the button", "simplebuilder" ),
            "param_name" => "link",
            "value" => __( "www.example.com", "simplebuilder" ),
            "description" => __( "Give a link.", "simplebuilder" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer UOU BLOCK 7A RIGHT SLIDER SECTION SHORTCODE
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
 START Visual Composer UOU BLOCK 7A Secondary LEFT SLIDER SECTION SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'uou_block_7a_secondary_left_slider_section_with_visual' );

function uou_block_7a_secondary_left_slider_section_with_visual() {
   vc_map( array(
      "name" => __( "SB UOU-BLOCK-7A SECONDARY LEFT Slider Section", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "chameleone_uou_block_7a_secondary_left_slider", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(

          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Give the name of the icon image", "simplebuilder" ),
            "param_name" => "badge_img",
            "value" => __( "about-company.png", "simplebuilder" ),
            "description" => __( "Give a name.", "simplebuilder" )
         ),

           array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Give a link for the button", "simplebuilder" ),
            "param_name" => "link",
            "value" => __( "www.example.com", "simplebuilder" ),
            "description" => __( "Give a link.", "simplebuilder" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer UOU BLOCK 7A Secondary LEFT SLIDER SECTION SHORTCODE
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
 START Visual Composer UOU BLOCK 7A Secondary LEFT SLIDER SECTION SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'uou_block_7a_left_slider_section_with_visual' );

function uou_block_7a_left_slider_section_with_visual() {
   vc_map( array(
      "name" => __( "SB UOU-BLOCK-7A LEFT Slider Section", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "chameleone_uou_block_7a_left_slider", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(

          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Give the name of the icon image", "simplebuilder" ),
            "param_name" => "badge_img",
            "value" => __( "about-company.png", "simplebuilder" ),
            "description" => __( "Give a name.", "simplebuilder" )
         ),

           array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Give a link for the button", "simplebuilder" ),
            "param_name" => "link",
            "value" => __( "www.example.com", "simplebuilder" ),
            "description" => __( "Give a link.", "simplebuilder" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer UOU BLOCK 7A Secondary LEFT SLIDER SECTION SHORTCODE
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
 START Visual Composer UOU BLOCK 7A Secondary RIGHT SLIDER SECTION SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'uou_block_7a_secondary_right_slider_section_with_visual' );

function uou_block_7a_secondary_right_slider_section_with_visual() {
   vc_map( array(
      "name" => __( "SB UOU-BLOCK-7A SECONDARY RIGHT Slider Section", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "chameleone_uou_block_7a_secondary_right_slider", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(

          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Give the name of the icon image", "simplebuilder" ),
            "param_name" => "badge_img",
            "value" => __( "about-company.png", "simplebuilder" ),
            "description" => __( "Give a name.", "simplebuilder" )
         ),

           array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Give a link for the button", "simplebuilder" ),
            "param_name" => "link",
            "value" => __( "www.example.com", "simplebuilder" ),
            "description" => __( "Give a link.", "simplebuilder" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer UOU BLOCK 7A Secondary RIGHT SLIDER SECTION SHORTCODE
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
 START Visual Composer UOU BLOCK 7B Recent Blog Post SECTION SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'uou_block_7b_section_with_visual' );

function uou_block_7b_section_with_visual() {
   vc_map( array(
      "name" => __( "Medico Recent Blog Post Section", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_blog_post_7b_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(

          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Number of post you want to show", "simplebuilder" ),
            "param_name" => "no_of_post_to_show",
            "value" => __( "3", "chameleon" ),
            "description" => __( "Give a number.", "simplebuilder" )
         ),

      )
   ) );
}
/*-------------------------------------------------------------------------
 End Visual Composer UOU BLOCK 7B Recent Blog Post SECTION SHORTCODE
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
 START Visual Composer UOU BLOCK 7B Secondary Recent Blog Post SECTION SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'uou_block_7b_secondary_section_with_visual' );

function uou_block_7b_secondary_section_with_visual() {
   vc_map( array(
      "name" => __( "Medico Secondary Recent Blog Post Section", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_blog_post_7b_secondary_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(

          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Number of post you want to show", "simplebuilder" ),
            "param_name" => "no_of_post_to_show",
            "value" => __( "3", "simplebuilder" ),
            "description" => __( "Give a number.", "simplebuilder" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer UOU BLOCK 7B Secondary Recent Blog Post SECTION SHORTCODE
------------------------------------------------------------------------- */

add_action( 'vc_before_init', 'simple_builder_recent_blog_visual' );

function simple_builder_recent_blog_visual() {
   vc_map( array(
      "name" => __( "Medico Recent Blog Post Shortcode", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_recent_posts", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(
      )
   ) );
}

add_action( 'vc_before_init', 'simple_builder_recent_blog_visual_two' );

function simple_builder_recent_blog_visual_two() {
   vc_map( array(
      "name" => __( "Medico Recent Blog Post Shortcode Two", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_recent_posts_two", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(
      )
   ) );
}

add_action( 'vc_before_init', 'simple_builder_recent_blog_visual_three' );

function simple_builder_recent_blog_visual_three() {
   vc_map( array(
      "name" => __( "Medico Recent Blog Post Shortcode Three", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_blog_post_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(
      )
   ) );
}

add_action( 'vc_before_init', 'simple_builder_recent_blog_visual_four' );

function simple_builder_recent_blog_visual_four() {
   vc_map( array(
      "name" => __( "Medico Recent Blog Post Shortcode without Imag", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_blog_post_7e_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(
      )
   ) );
}

/*-------------------------------------------------------------------------
 START Visual Composer UOU BLOCK 7B Secondary Recent Blog Post SECTION SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'sb_message_buttone_with_visual' );

function sb_message_buttone_with_visual() {
   vc_map( array(
      "name" => __( "Medico Message & Button Section", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_message_button", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(

          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Message you want to show", "simplebuilder" ),
            "param_name" => "message",
            "description" => __( "Give a number.", "simplebuilder" )
         ),

          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Link One want to show", "simplebuilder" ),
            "param_name" => "link1",
            "description" => __( "Give a Link.", "simplebuilder" )
         ),
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Link Two you want to show", "simplebuilder" ),
            "param_name" => "link2",
            "description" => __( "Give a Link.", "simplebuilder" )
         ),
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Button Name One you want to show", "simplebuilder" ),
            "param_name" => "button_des1",
            "description" => __( "Give a Name.", "simplebuilder" )
         ),
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Button Name Two you want to show", "simplebuilder" ),
            "param_name" => "button_des2",
            "description" => __( "Give a Name.", "simplebuilder" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer UOU BLOCK 7B Secondary Recent Blog Post SECTION SHORTCODE
------------------------------------------------------------------------- */
/*-------------------------------------------------------------------------
 START Visual Composer Construction Tons of Feature SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'sb_tons_of_feature_with_visual' );

function sb_tons_of_feature_with_visual() {
   vc_map( array(
      "name" => __( "Construction Ton's of Feature", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_tof_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(
      )
   ) );
}

/*-------------------------------------------------------------------------
 End Visual Composer Construction Tons of Feature SHORTCODE
------------------------------------------------------------------------- */


/*-------------------------------------------------------------------------
 Start Visual Composer Construction Header Slider  SHORTCODE
------------------------------------------------------------------------- */

add_action( 'vc_before_init', 'sb_image_home_visual' );

function sb_image_home_visual() {
   vc_map( array(
      "name" => __( "Medico Home Image Shortcode", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_home_image_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(
      )
   ) );
}

/*-------------------------------------------------------------------------
 End Visual Composer Construction Header Slider  SHORTCODE
------------------------------------------------------------------------- */


/*-------------------------------------------------------------------------
												HOME TWO ****************************************
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'sb_message_button_white_with_visual' );

function sb_message_button_white_with_visual() {
   vc_map( array(
      "name" => __( "Medico Message & Button Section (Corporate)", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_white_message_button", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(

          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Message you want to show", "simplebuilder" ),
            "param_name" => "message",
            "description" => __( "Give a number.", "simplebuilder" )
         ),

          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Link One want to show", "simplebuilder" ),
            "param_name" => "link1",
            "description" => __( "Give a number.", "simplebuilder" )
         ),
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Link Two you want to show", "simplebuilder" ),
            "param_name" => "link2",
            "description" => __( "Give a number.", "simplebuilder" )
         ),
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Button Description want to show", "simplebuilder" ),
            "param_name" => "button_des1",
            "description" => __( "Button Description.", "simplebuilder" )
         ),
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Button Description want to show", "simplebuilder" ),
            "param_name" => "button_des2",
            "description" => __( "Button Description", "simplebuilder" )
         ),
      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer UOU BLOCK 7B Secondary Recent Blog Post SECTION SHORTCODE
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
 START Visual Composer Construction Tons of Feature SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'sb_corporate_tof_with_visual' );

function sb_corporate_tof_with_visual() {
   vc_map( array(
      "name" => __( "Medico Corporate Shortcode", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_tof_corporate_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "active",
            "heading" => __( "Testimonial to show", "simplebuilder" ),
            "param_name" => "no_of_info_show",
            "value" => __( "4", "simplebuilder" ),
            "description" => __( "No of Testimonial to show.", "simplebuilder" )
         ),
      )
   ) );
}

/*-------------------------------------------------------------------------
 End Visual Composer Construction Tons of Feature SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'sb_message_button_white_border_with_visual' );

function sb_message_button_white_border_with_visual() {
   vc_map( array(
      "name" => __( "Medico Message & Button Section with Border (Corporate)", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_white_message_button_border", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(

          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Message you want to show", "simplebuilder" ),
            "param_name" => "message",
            "description" => __( "Give a number.", "simplebuilder" )
         ),

          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Link One want to show", "simplebuilder" ),
            "param_name" => "link1",
            "description" => __( "Give a number.", "simplebuilder" )
         ),
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Link Two you want to show", "simplebuilder" ),
            "param_name" => "link2",
            "description" => __( "Give a number.", "simplebuilder" )
         ),
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Button Description want to show", "simplebuilder" ),
            "param_name" => "button_des1",
            "description" => __( "Button Description.", "simplebuilder" )
         ),
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Button Description want to show", "simplebuilder" ),
            "param_name" => "button_des2",
            "description" => __( "Button Description", "simplebuilder" )
         ),
      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer UOU BLOCK 7B Secondary Recent Blog Post SECTION SHORTCODE
------------------------------------------------------------------------- */

/*------------------------------------------------------------------------- **************************************** ****************************************
												HOME TWO ****************************************
-------------------------------------------------------------------------  **************************************** **************************************** */
add_action( 'vc_before_init', 'sb_message_button_copywrite_with_visual' );

function sb_message_button_copywrite_with_visual() {
   vc_map( array(
      "name" => __( "Medico Message & Button Section (Copy Write)", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_message_button_copywrite", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(

          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Message you want to show", "simplebuilder" ),
            "param_name" => "message",
            "description" => __( "Give a number.", "simplebuilder" )
         ),

          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Link One want to show", "simplebuilder" ),
            "param_name" => "link1",
            "description" => __( "Give a link.", "simplebuilder" )
         ),
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Link Two you want to show", "simplebuilder" ),
            "param_name" => "link2",
            "description" => __( "Give a link.", "simplebuilder" )
         ),
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Button Description want to show", "simplebuilder" ),
            "param_name" => "button_des1",
            "description" => __( "Button Description.", "simplebuilder" )
         ),
          array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "",
            "heading" => __( "Button Description want to show", "simplebuilder" ),
            "param_name" => "button_des2",
            "description" => __( "Button Description", "simplebuilder" )
         ),
      )
   ) );
}


/*-------------------------------------------------------------------------
 End Visual Composer UOU BLOCK 7B Secondary Recent Blog Post SECTION SHORTCODE
------------------------------------------------------------------------- */

/*-------------------------------------------------------------------------
 START Visual Composer CONSTRUCTION Blockquotes Testimonial  SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'simple_builder_copywriter_with_visual' );

function simple_builder_copywriter_with_visual() {
   vc_map( array(
      "name" => __( "Medico CopyWriter Testimonial (Blockquotes)", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_copywriter_testimonial_section", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "active",
            "heading" => __( "Testimonial to show", "simplebuilder" ),
            "param_name" => "no_of_testimonial_show",
            "value" => __( "3", "simplebuilder" ),
            "description" => __( "No of Testimonial to show.", "simplebuilder" )
         ),
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "active",
            "heading" => __( "Testimonial Background Image to show", "simplebuilder" ),
            "param_name" => "bg_img",
            "value" => __( "copywrite-block-img3.png", "simplebuilder" ),
            "description" => __( "Testimonial Background Image to show.", "simplebuilder" )
         ),

      )
   ) );
}

/*-------------------------------------------------------------------------
 End Visual Composer CONSTRUCTION Blockquotes Testimonial  SHORTCODE
------------------------------------------------------------------------- */

add_action( 'vc_before_init', 'simple_builder_copywriter_twitter_with_visual' );

function simple_builder_copywriter_twitter_with_visual() {
   vc_map( array(
      "name" => __( "Medico CopyWriter Testimonial (Twitter)", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_copywriter_testimonial_section_twitter", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "active",
            "heading" => __( "Testimonial to show", "simplebuilder" ),
            "param_name" => "no_of_testimonial_show",
            "value" => __( "3", "simplebuilder" ),
            "description" => __( "No of Testimonial to show.", "simplebuilder" )
         ),
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "active",
            "heading" => __( "Testimonial Background Image to show", "simplebuilder" ),
            "param_name" => "bg_img",
            "value" => __( "copywrite-block-img3.png", "simplebuilder" ),
            "description" => __( "Testimonial Background Image to show.", "simplebuilder" )
         ),

      )
   ) );
}

/*-------------------------------------------------------------------------
 End Visual Composer TWITTER Blockquotes Testimonial  SHORTCODE
------------------------------------------------------------------------- */
add_action( 'vc_before_init', 'simple_builder_copywriter_counter_with_visual' );

function simple_builder_copywriter_counter_with_visual() {
   vc_map( array(
      "name" => __( "Medico CopyWriter Company Info", "simplebuilder" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_copywriter_counter_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "simplebuilder"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "active",
            "heading" => __( "Testimonial to show", "simplebuilder" ),
            "param_name" => "no_of_info_show",
            "value" => __( "4", "simplebuilder" ),
            "description" => __( "No of Testimonial to show.", "simplebuilder" )
         ),
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "active",
            "heading" => __( "Testimonial Background Image to show", "simplebuilder" ),
            "param_name" => "bg_img",
            "value" => __( "copywrite-block-img2.png", "simplebuilder" ),
            "description" => __( "Testimonial Background Image to show.", "simplebuilder" )
         ),

      )
   ) );
}


/*-------------------------------------------------------------------------
 START Visual Composer Construction Tons of Feature SHORTCODE
------------------------------------------------------------------------- */


add_action( 'vc_before_init', 'construction_service_with_visual' );

function construction_service_with_visual() {
   vc_map( array(
      "name" => __( "Medico Service Shortcode", "chameleon" ), //This name will be shown in the visual composer pop up.
      "base" => "sb_tof_shortcode", // name of the shortcode. 
      "class" => "",
      "category" => __( "Medico Shortcodes", "chameleon"), // in which tab it will appeared? there are several tabs: content, social etc.
      "params" => array(
         array(
            "type" => "textfield",
            "holder" => "div",
            "class" => "active",
            "heading" => __( "Testimonial to show", "simplebuilder" ),
            "param_name" => "no_of_info_show",
            "value" => __( "4", "simplebuilder" ),
            "description" => __( "No of Testimonial to show.", "simplebuilder" )
         ),
      )
   ) );
}

/*-------------------------------------------------------------------------
 End Visual Composer Construction Tons of Feature SHORTCODE
------------------------------------------------------------------------- */