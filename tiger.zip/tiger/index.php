<?php  

	get_template_part('templates/blog/content','blogChoose');

?>