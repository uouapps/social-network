<?php
update_option('uou_tigerp_signup-template', 'signup-style-2'); 
update_option('uou_tigerp_profile-template', 'style-1' ); 
update_option('uou_tigerp_profile-public', 'style-2' ); 
update_option('uou_tigerp_post_approved', 'yes' ); 
update_option('_uou_tigerp_hide_admin_bar', 'yes' ); 


?>
