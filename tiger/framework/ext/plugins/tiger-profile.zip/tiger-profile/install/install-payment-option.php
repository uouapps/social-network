<?php
update_option('uou_tigerp_payment_gateway', 'paypal-express' ); 
update_option('uou_tigerp_payment_terms', 'yes' ); 
update_option('uou_tigerp_price-table', 'style-1' ); 
update_option('_uou_tigerp_api_currency', 'USD' );
update_option('uou_tigerp_payment_terms_text', ' I have read & accept the <a href="#" target="_blank"> Terms & Conditions</a>' ); 


?>
