<meta name="viewport" content="width=device-width, initial-scale=1">
<title> <?php wp_title('|', true, 'right'); ?> </title>
<!-- Bootstrap -->

<?php
wp_enqueue_style('user-dir-style', tiger_CSS.'user-directory.css', array(), $ver = false, $media = 'all');

global $wpdb;		
		
		?>
	<div id="main-wrapper">
		<div id="header">
					<div class="header-search-bar">
						<div class="container">
							<form  action="<?php echo the_permalink(); ?>" method="post" >
								<div class="basic-form clearfix">
									<a href="#" class="toggle"></a>

									<div class="hsb-input-1">
										<input type="text" id="keyword" name="keyword" class="form-control" placeholder="<?php esc_html_e('Keyword','tiger'); ?>">
									</div>

									<div class="hsb-container">
										<div class="hsb-input-2">
											<input type="text" id="location" name="location" class="form-control" placeholder="<?php esc_html_e('Location','tiger'); ?>">
										</div>

										<div class="hsb-select">
											<input type="text" id="profession" name="profession" class="form-control" placeholder="<?php esc_html_e('Profession','tiger'); ?>">

										</div>
									</div>

									<div class="hsb-submit">
										<input type="submit" class="btn btn-default btn-block" value="<?php esc_html_e('Search Professionals','tiger'); ?>">
									</div>
								</div>


							</form>
						</div>
						<div class="advanced-form">

							<div class="container">
								<div class="row">
									<label class="col-md-3 filter-result"><?php esc_html_e('Filter Results','tiger'); ?></label>

									<div class="col-md-9">
									</div>
								</div>
								<div class="row">
									<label class="col-md-3"><?php esc_html_e('Distance (in kilometers)','tiger'); ?>:</label>

									<div class="col-md-9">
										<div class="range-slider">
											<div class="slider" data-min="1" data-max="200" data-current="100"></div>
											<div class="last-value"><span><?php esc_html_e('100','tiger'); ?></span><?php esc_html_e('km','tiger'); ?> </div>
										</div>
									</div>
								</div>

								<div class="row">
									<label class="col-md-3"><?php esc_html_e('Rating','tiger'); ?>:</label>

									<div class="col-md-9">
										<div class="range-slider">
											<div class="slider" data-min="1" data-max="100" data-current="20"></div>
											<div class="last-value">&gt; <span>20</span> %</div>
										</div>
									</div>
								</div>

								<!--
								<div class="row">
									<label class="col-md-3"><?php esc_html_e('Industry','tiger'); ?>:</label>

									<div class="col-md-9">
										<select class="form-control">
											<option value="">Select Industry</option>
											<option value="">Option 1</option>
											<option value="">Option 2</option>
											<option value="">Option 3</option>
											<option value="">Option 4</option>
											<option value="">Option 5</option>
										</select>
									</div>
								</div>
								-->
							</div>
						</div>
					</div> <!-- end .header-search-bar -->
				</div>

		  <!-- Members -->
    <section class="pro-mem">
      <div class="container pb30">
        <h3><?php esc_html_e('Professionals','tiger'); ?>  </h3>
        <div class="row">
			 <?php
						$search_user='';
						if(isset($_REQUEST['keyword'])){
							 $search_user = $_REQUEST['keyword'];			
						}

				        if(isset($atts['per_page'])){
							 $no=$atts['per_page'];
						}else{
							$no=12;
						}

						$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
						if($paged==1){
						  $offset=0;
						}else {
						   $offset= ($paged-1)*$no;
						}
				        $args = array();
				        $args['number']=$no;
				        $args['offset']=$offset;
				        $args['orderby']='registered';
				        $args['order']='DESC';
				        //$args['search']='12';
				        //$args['search_columns']=array( 'user_login', 'user_email' );
				       
						 if($search_user!=''){
							$args['search']='*'.$search_user.'*';
						}



						$reg_page_user='';

						if(isset($atts['role'])){
							 $args['role']=$atts['role'];
						}
				        $user_query = new WP_User_Query( $args );

				        // User Loop
				        if ( ! empty( $user_query->results ) ) {
				        	foreach ( $user_query->results as $user ) {

								if (isset($user->wp_capabilities['administrator'])!=1 ){

								$iv_profile_pic_url=get_user_meta($user->ID, 'iv_profile_pic_url',true);
								$reg_page_u=$reg_page_user.'?&id='.$user->user_login; //$reg_page ;
								$reg_page_user='';
								$user_type= get_user_meta($user->ID,'iv_member_type',true);
								if($iv_profile_pic_url==''){
								 $iv_profile_pic_url=wp_uou_tigerp_URLPATH.'assets/images/Blank-Profile.jpg';
								}
								if($user_type=='corporate'){
									$iv_redirect_user = get_option( '_iv_corporate_profile_public_page');
								    $reg_page_user= get_permalink( $iv_redirect_user) ;
								}else{

									$iv_redirect_user = get_option( '_iv_personal_profile_public_page');
								    $reg_page_user= get_permalink( $iv_redirect_user) ;
								}
								?>
								<div class="col-sm-3">
								   <div class="uou-block-6a uer-directory-single">
									   <a href="<?php echo $reg_page_user.'?&id='.$user->user_login; ?>">
								   		<div class="uer-image" style="background: url('<?php echo $iv_profile_pic_url; ?>') center center no-repeat; background-size: cover;">
								   			<!-- <img src="<?php echo $iv_profile_pic_url; ?>" alt=""> -->
								   		</div>
								   		</a>

								   	<div class="user-details">
								   		<a href="<?php echo $reg_page_user.'?&id='.$user->user_login; ?>"><h6><?php echo get_user_meta($user->ID,'profile_name',true); ?> &nbsp;<span><?php echo get_user_meta($user->ID,'designation',true);   ?>&nbsp;</span></h6></a>
								   		<p><i class="fa fa-map-marker"></i> <?php echo get_user_meta($user->ID,'address',true); ?>&nbsp;</p>
								   	</div>

									</div>
									<!-- end .uou-block-6a -->
								</div>


							<?php

							}
						}
					}

			?>
        </div>
      </div>
    </section>
    		<div class="text-center">
				<?php
					$total_user = $user_query->total_users;  
					$total_pages=ceil($total_user/$no);						
					echo '<div id="pagination" class="pagination">';  
							
						echo paginate_links( array(
							'base' =>  '%_%'.'?&keyword='.$search_user, // the base URL, including query arg						
							'format' => '?&paged=%#%', // this defines the query parameter that will be used, in this case "p"
							'prev_text' => __('&laquo; Previous','chilepro'), // text for previous page
							'next_text' => __('Next &raquo;','chilepro'), // text for next page
							'total' => $total_pages, // the total number of pages we have
							'current' => $paged, // the current page
							'end_size' => 1,
							'mid_size' => 5,	
						));					
					echo '</div></div>';  	
					?>
					</div>
				


	</div>
