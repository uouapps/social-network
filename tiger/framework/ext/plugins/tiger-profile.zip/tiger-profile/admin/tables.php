<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
   exit;
}

/**
 * @file
 *
 * Tables Generator 
 */
if (!class_exists('wp_admin_table')) {
   class wp_admin_table   { 

   }
}
	
