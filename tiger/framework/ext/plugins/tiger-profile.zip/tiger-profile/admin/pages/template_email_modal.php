 <?php
 
$image_path= $_GET['upath'];
	
 ?>
<div class="modal-header">
	<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
	<h2 class="modal-title">Email Template Sample</h2>
</div>
								<div class="modal-body">	
									<div class="row">
												<div class="col-md-6 "> 
													<p class="pull-left">
															<h4> Admin Email Template Green</h4>
															<img src="<?php echo $image_path; ?>admin/files/images/template-screen-pic/email-template-green.png" alt="iv contact form created" class="col-md-12 "/>	  
													</p>
												</div>
												<div class="col-md-6 "> 
														<p class="pull-left">
															<h4> Admin Email Template Green</h4>
															<img src="<?php echo $image_path; ?>admin/files/images/template-screen-pic/email-template-green2.png" alt="iv contact form created" class="col-md-12 "/>	 
														 </p>
												</div>												
										
									</div>
									<div class="row">
												<div class="col-md-6 "> 
													<p class="pull-left">
															<h4> Admin Email Template Black & White</h4>
															<img src="<?php echo $image_path; ?>admin/files/images/template-screen-pic/email-template-black-while.png" alt="iv contact form created" class="col-md-12 "/>	  
													</p>
												</div>
												<div class="col-md-6 "> 
														<p class="pull-left">
															<h4> Admin Email Template Green</h4>
															<img src="<?php echo $image_path; ?>admin/files/images/template-screen-pic/email-template-black-while.png" alt="iv contact form created" class="col-md-12 "/>	 
														 </p>
												</div>												
										
									</div>
									<div class="row">
												<div class="col-md-6 "> 
													<p class="pull-left">
															<h4> Admin Email Template Textile</h4>
															<img src="<?php echo $image_path; ?>admin/files/images/template-screen-pic/email-template-textile.png" alt="iv contact form created" class="col-md-12 "/>	  
													</p>
												</div>
												<div class="col-md-6 "> 
														<p class="pull-left">
															<h4> Admin Email Template Green</h4>
															<img src="<?php echo $image_path; ?>admin/files/images/template-screen-pic/email-template-textile.png" alt="iv contact form created" class="col-md-12 "/>	 
														 </p>
												</div>												
										
									</div>
										
								</div>
<div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
									
</div>
