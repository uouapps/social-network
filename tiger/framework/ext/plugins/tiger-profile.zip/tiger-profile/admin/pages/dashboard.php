<div id="uou_tigerp-layout">
  <?php include("sidebar.php"); ?>
  <div class="ui grid stackable">
    <div class="row">
      <div class="sixteen wide column">
      <h2 class="ui header">
          <i class="dashboard icon purple large"></i>
          <div class="content">
            <?php echo __('uou_tigerp Affiliate Dashboard','uou_tigerp'); ?>
            <div class="sub header"><?php echo __('Your Dashboard, Summary, Status, Shortcuts to modules','uou_tigerp'); ?></div>
          </div>
        </h2>                
      </div>      
    </div>
  </div>
</div><!-- End #uou_tigerp-layout -->